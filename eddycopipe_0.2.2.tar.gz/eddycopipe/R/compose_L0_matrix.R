#' @title Build out the site L0 DP matrix
#' @description  Analyzes what DP's we have at the site you input
#' @param site character four letter site code
#' @export
#' @examples
#' compose_L0_matrix(site = "NIWO")
compose_L0_matrix = function(site = NULL, matrix = NULL){
  if(is.null(site)==TRUE){
    stop("Please specify site, four letter code")
  }

  # Required Libraries
  library(stringr)
  library(aws.s3)
  library(aws.signature)
  library(ytBangerz)
  library(dplyr)

  ei_bucket = "neon-eddy-inquiry"

  # Get all the L0 streams for site
  eddy_l0_matrix = eddycopipe::neon_gcs_get_rds(object = "lookup/EnterTheL0Matrix.rds", bucket = ei_bucket)
  eddy_l0_matrix[] <- lapply(eddy_l0_matrix, as.character)

  if(is.null(matrix) == TRUE){
    raw_site_streams <- ytBangerz::getSiteStreams(site = site, l0.matrix = eddy_l0_matrix)
  } else {
    raw_site_streams <- ytBangerz::getSiteStreams(site = site, l0.matrix = matrix)
  }

  site_info_ytB = length(ytBangerz::siteInfo$SiteCode)

  cooking_site_streams <- base::as.data.frame(raw_site_streams)
  names(cooking_site_streams) <- "streams"

  clean_site_streams = cooking_site_streams %>%
    dplyr::mutate(DPcrispy = base::substr(streams,15,33)) %>%
    dplyr::mutate(DPJoin = base::substr(streams,15,45))

  return(clean_site_streams)
}
