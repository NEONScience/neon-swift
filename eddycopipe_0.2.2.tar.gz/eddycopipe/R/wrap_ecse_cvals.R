#' @title Wrapper to pull a day's ecse cvals
#' @description  This function pairs with pull_ecse_cvals to pull data from Presto and save it to S3
#' @param presto_creds Character string; your presto credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @param sites chacter, list of sites you want to pull, defaults to all tis sites
#' @export
#' @examples
#' wrap_ecse_cvals(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
wrap_ecse_cvals = function(presto_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify pull_date: Sys.Date()-1")
  } else {
    # Format date...
    pull_date = as.Date(pull_date, origin = "1970-01-01", format = "%Y-%m-%d")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)
  library(here)

  ei_bucket = "neon-eddy-inquiry"

  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")

  # Sensor Names, This list is used to limit streams to only DPID's I have named in this SensorNames Lookup table
  sensor_name = eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket)

  wrap_pull_ecse_cvals = function(site, start, stop, sensor_name = sensor_name){

    Li840.dpids = c(
      "DP0.00107.001.01951.700.000.000", # ECSE Vali MFC
      "DP0.00106.001.01951.700.000.000", # Li-840 Samp MFC
      "DP0.00105.001.02316.700.000.000", # Li-840 Co2
      "DP0.00105.001.02348.700.000.000", # Li-840 H2o
      "DP0.00105.001.02350.700.000.000", # Li-840 Cell Pressure
      "DP0.00105.001.02349.700.000.000", # Li-840 Cell Temperature
      "DP0.00102.001.02316.700.000.000", # G2131i Co2 fwmole
      "DP0.00114.001.02361.700.000.000", # G2131 Validation Valve
      "DP0.00114.001.02364.700.000.000", # Li840 Validation Valve
      "DP0.00114.001.02362.700.000.000", # Li840 Vent Valve
      "DP0.00113.001.02361.703.000.000", # ECSE Low
      "DP0.00113.001.02362.703.000.000", # ECSE Med
      "DP0.00113.001.02364.703.000.000", # ECSE High
      "DP0.00113.001.02365.703.000.000", # ECSE Archive
      "DP0.00113.001.02366.703.000.000"  # ECSE Co2 Zero
    )
    G2131.dpids = c(
      "DP0.00107.001.01951.700.000.000", # ECSE Vali MFC
      "DP0.00102.001.02316.700.000.000", # G2131i Co2 fwmole
      "DP0.00102.001.02317.700.000.000", # G2131i 12Co2 wet
      "DP0.00102.001.02319.700.000.000", # G2121i 13Co2 wet
      "DP0.00105.001.02316.700.000.000", # Li-840 Co2
      "DP0.00114.001.02361.700.000.000", # G2131 Validation Valve
      "DP0.00114.001.02364.700.000.000", # Li840 Validation Valve
      "DP0.00113.001.02361.703.000.000", # ECSE Low
      "DP0.00113.001.02362.703.000.000", # ECSE Med
      "DP0.00113.001.02364.703.000.000", # ECSE High
      "DP0.00113.001.02365.703.000.000", # ECSE Archive
      "DP0.00113.001.02366.703.000.000"  # ECSE Co2 Zero
    )
    L2130.dpids = c(
      "DP0.00107.001.01951.700.000.000", # ECSE Vali MFC
      "DP0.00103.001.02369.700.000.000", # L2130i d18OWater
      "DP0.00103.001.02370.700.000.000", # L2130i d2HWater
      "DP0.00103.001.02339.700.000.000", # L2130i h2o ppt
      "DP0.00113.001.02368.703.000.000"  # L2130i Zero Air Valve Status
    )

    # Get all the L0 streams for site
    site_streams = compose_L0_matrix(
      site = site
    )

    # If we're on the prod linux server (ie linux) we will pull the period data from local storage (very small files so no worries on excessive storage issues)
    system_os_type = Sys.info()['sysname']
    if(system_os_type == "Linux"){
      list.periods = data.table::data.table(files = list.files(path = "~/eddyInquiry/data/cval/ecse.cval.periods.data/", pattern = site, full.names = TRUE)) %>%
        tidyr::separate(col = files, into = c("1","2","3","4","5","6","7","8","9","10"), sep = "/", remove = FALSE) %>% dplyr::select(files, `10`) %>%
        tidyr::separate(col = `10`, into = c("site","num","start","stop"), sep = "_") %>% dplyr::select(files, start) %>%
        dplyr::filter(start == pull_date)

      if(nrow(list.periods) == 0){
        list.periods = eddycopipe::neon_gcs_get_rds(object = "s3.lookup/ecse.cval.periods.meta.RDS", bucket = ei_bucket) %>%
          dplyr::filter(StartDate == pull_date) %>%
          dplyr::filter(SiteID == site)
        system_os_type = "Windows"
      }

    } else if(system_os_type == "Windows"){
      # Read in all the cvals periods for site
      list.periods = eddycopipe::neon_gcs_get_rds(object = "s3.lookup/ecse.cval.periods.meta.RDS", bucket = ei_bucket) %>%
        dplyr::filter(StartDate == pull_date) %>%
        dplyr::filter(SiteID == site)
    } else {
      wrong_system = system_os_type
      stop(paste0("Sys.info()['sysname'] = ", wrong_system,", was not recognized [1]..."))
    }

    if(nrow(list.periods) > 0){

      ecse.period.dt = data.table::data.table()
      if(system_os_type == "Linux"){
        for(i in 1:length(list.periods$files)){
          data.in = readRDS(file = list.periods$files[i])
          ecse.period.dt = data.table::rbindlist(l = list(ecse.period.dt, data.in))
        }
      } else if(system_os_type == "Windows"){
        for(i in 1:length(list.periods$Key)){
          data.in = eddycopipe::neon_gcs_get_rds(object = list.periods$Key[i], bucket = ei_bucket)
          ecse.period.dt = data.table::rbindlist(l = list(ecse.period.dt, data.in))
        }
      } else {
        wrong_system = system_os_type
        stop(paste0("Sys.info()['sysname'] = ", wrong_system,", was not recognized [2]..."))
      }

      # Join the
      all.dpids = c(
        "DP0.00107.001.01951.700.000.000", # Li-840 Vali MFC
        "DP0.00106.001.01951.700.000.000", # Li-840 Samp MFC
        "DP0.00105.001.02316.700.000.000", # Li-840 Co2
        "DP0.00105.001.02348.700.000.000", # Li-840 H2o
        "DP0.00105.001.02350.700.000.000", # Li-840 Cell Pressure
        "DP0.00105.001.02349.700.000.000", # Li-840 CellTemperature
        "DP0.00102.001.02316.700.000.000", # G2131i Co2 fwmole
        "DP0.00102.001.02317.700.000.000", # G2131i 12Co2 wet
        "DP0.00102.001.02319.700.000.000", # G2121i 13Co2 dry
        "DP0.00102.001.02324.700.000.000", # G2131i d13Co2 (raw Isotopic values)
        "DP0.00103.001.02369.700.000.000", # L2130i d18OWater
        "DP0.00103.001.02370.700.000.000", # L2130i d2HWater
        "DP0.00103.001.02339.700.000.000", # L2130i h2o ppt
        "DP0.00113.001.02361.703.000.000", # Low
        "DP0.00113.001.02362.703.000.000", # Med
        "DP0.00113.001.02364.703.000.000", # High
        "DP0.00113.001.02365.703.000.000", # Archive
        "DP0.00113.001.02366.703.000.000", # Cow Zero
        "DP0.00113.001.02368.703.000.000"  # L2130i Zero Air Valve Status
      )

      # Limit Streams by EC related streams
      streams = site_streams %>%
        dplyr::filter(DPJoin %in% all.dpids)%>%
        dplyr::distinct()

      streams.li840 = streams %>%
        dplyr::filter(DPJoin %in% Li840.dpids)%>%
        dplyr::distinct()

      streams.g2131 = streams %>%
        dplyr::filter(DPJoin %in% G2131.dpids)%>%
        dplyr::distinct()

      streams.l2130 = streams %>%
        dplyr::filter(DPJoin %in% L2130.dpids)%>%
        dplyr::distinct()

      if(nrow(ecse.period.dt) > 0){

        try(
          pull_ecse_cvals(
            cval.file = ecse.period.dt,
            idDp      = streams,
            startTime = start,
            endTime   = stop,
            CredPsto  = presto_creds,
            lookup    = sensor_name
          )
        )
      } else {
        message(paste0(Sys.time(),": ",i, " has no cval data for date(s): ", start, " - ",stop))
      }
    } else {
      message(paste0(Sys.time(),": ",i, " has no cval data for date(s): ", start, " - ",stop))
    }
  }

  start = Sys.time()
  for(i in siteList$SiteID){
    start1 = Sys.time()
    wrap_pull_ecse_cvals(
      site  = i,
      start = pull_date,
      stop  = pull_date + 1,
      sensor_name = sensor_name
    )
    end1 = Sys.time()
    message(paste0(Sys.time(),": ", i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
  }
  end = Sys.time()
  message(paste0(Sys.time(),": ecse calvals pull in ", round(difftime(end,start,units = "min"),2), " minutes "))
}
