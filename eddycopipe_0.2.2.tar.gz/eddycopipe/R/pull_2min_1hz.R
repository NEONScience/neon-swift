#' @title Pull all 1hz 2min eddyInquiry Data
#' @description  Presto Pull for 2 minute data points
#' @param idDp string containing full data product ID (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param dateBgn date; start of data pull
#' @param dateEnd date; end of data pull
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param everyMinute numeric; you want data every 2 min, 2. Every 5 min, 5. etc
#' @param compression specify compression for files saved to S3
#' @export
#' @examples
#' pull_2min_1hz()
pull_2min_1hz = function(idDp, dateBgn, dateEnd, CredPsto = NULL, sensor_names = NULL, everyMinute = 2, compression = 50) {

  # Required Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(tidyr)
  library(here)

  # Check that Date Range is only 1 day, if != 1, do not run!
  if(as.Date(dateEnd) - as.Date(dateBgn) < 507){

    # Determine the site
    site = unique(substr(idDp,10,13))

    # Build and test connection
    con = wrap_build_test_presto_connection(CredPsto = CredPsto)

    # Stream formatting:
    idDpChar=sapply(idDp, function(x) paste0("",x,"")) %>%
      paste0(collapse=",") %>%
      as.factor() %>%
      paste0(collapse=",")

    # Sql query
    sql = glue::glue_sql("SELECT
                            meas_strm_name, readout_time, readout_val_double
                           FROM
                            readouts
                           WHERE
                            site = {site} and
                            meas_strm_name IN ({idDpChar}) and
                            ds between {dateBgn} and {dateEnd} and
                            MINUTE(readout_time) % {everyMinute} = 0 and SECOND(readout_time) = 0
                           ",
                           .con = con
                           )%>%
        # The stuff below is some magic to format the string of streams juuust right
        gsub(pattern = "NEON",replacement = "'NEON") %>% #
        gsub(pattern = "0,", replacement = "0',") %>%
        gsub(pattern = "1,", replacement = "1',") %>%
        gsub(pattern = "2,", replacement = "2',") %>%
        gsub(pattern = "3,", replacement = "3',") %>%
        gsub(pattern = "''", replacement = "'") %>%
        gsub(pattern = '""', replacement = '"') %>%
        gsub(pattern = '"approx', replacement = "approx") %>%
        gsub(pattern = '0.95),"', replacement = "0.95),")

      start = Sys.time()
      # Send the Query
      res = DBI::dbSendQuery(con, sql)
      message(paste0(Sys.time(), ": 14%:  ",site, " from ", dateBgn, " to ", dateEnd))
      # Actually grab the data from the query
      mrg.rpt = DBI::dbFetch(res,-1)

      base::message(paste0(Sys.time(), ": 21%:  Pull finished..."))
      # Disconnect from the DB like a good neighbor
      DBI::dbDisconnect(con)
      base::message(paste0(Sys.time(), ": 28%:  Disconnected from Presto..."))

      # Time calculations
      end = Sys.time()
      elapsed = difftime(end, start, units = "secs")
      message(paste0(Sys.time(), ": 37%:  Pull lasted: ",round(elapsed,3)," seconds..."))

      # If there is data in the pull tidy the data a little, and then save it appropriately
      if(nrow(mrg.rpt) > 0){

        mrg.rpt = data.table::as.data.table(mrg.rpt) %>%
          dplyr::mutate(DPID = base::substr(meas_strm_name, start = 15, stop = 100)) %>% # Create a mutual column to join the Sensor Names lookup table to
          dplyr::mutate(DPID = base::trimws(DPID, which = "both")) %>%
          dplyr::mutate(SiteID = site)

        # Join the lookup table and raw 2 minute data, giving all the streams human readible names
        mrg.rpt.out = dplyr::left_join(x = mrg.rpt, y = sensor_names, by = "DPID")
        rm(mrg.rpt)

        # Actual removal of 20 hz data
        startD = Sys.time()
        mrg.rpt.distinct = mrg.rpt.out  %>%
          dplyr::mutate(readout_time = lubridate::ymd_hms(readout_time)) %>%
          dplyr::distinct(readout_time,strm_name, .keep_all = TRUE) %>%
          dplyr::select(SiteID,DPID,strm_name,readout_time,readout_val_double)

        endD = Sys.time()

        dDiff = round( difftime(endD,startD, units = "secs"), 2)
        message(paste0(Sys.time(), ": 42%:  Distinction took: ", dDiff, " seconds... Total rows removed: ", nrow(mrg.rpt.out) - nrow(mrg.rpt.distinct)))
        rm(mrg.rpt.out)
        # Get a list of all the unique data streams we just pulled
        listOfStreamNames = as.data.frame(sort(unique(mrg.rpt.distinct$strm_name)))
        names(listOfStreamNames) = "strm_name"

        # Create lists for file saves!
        ei.g2131          = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "G2131")        == TRUE)
        ei.ec.temps       = listOfStreamNames %>% dplyr::filter(strm_name %in% c("ecte_mfc_sample_tempC", "ecte_mfc_valid_tempC", "ecse_comet_tempHut", "ecse_comet_H2OMixRatio", "ecse_mfc_sample_tempC", "ecse_mfc_valid_tempC", "HMP155_temp", "HMP155_temp_sp3"))
        ei.li7200         = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "Li7200")       == TRUE)
        ei.ecte.csat3     = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "CSAT3")        == TRUE)
        ei.ecte.HMP155    = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "HMP155")       == TRUE)
        ei.li840          = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "840")          == TRUE)
        ei.l2130          = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "L2130")        == TRUE)
        ei.mfm            = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "MFM_FlowRate") == TRUE)
        ei.mfm.pressures  = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "_Pressure")    == TRUE & strm_name != "ECSE_SampleMFC_Pressure")
        ei.ecse.mfc       = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "SampleMFC")    == TRUE)
        ei.ecte.amrs      = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "AMRS")         == TRUE)

        # Filter and Save out all 2min data :)
        ### G2131 S3 Filter and Save
        if(nrow(ei.g2131) > 0){

          g2131.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "G2131") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_G2131.fst", dataTable = g2131.data, site = site, dateBgn = dateBgn, percentage = "48", compression = compression)
          rm(g2131.data)

        } else {
          message(paste0(Sys.time(), ": 48%:  NOT saving G2131 Data..."))
        }
        ### EC Temperatures S3 Filter and Save
        if(nrow(ei.ec.temps) > 0){
          ec.temps.data = mrg.rpt.distinct %>% dplyr::filter(strm_name %in% c("ecte_mfc_sample_tempC", "ecte_mfc_valid_tempC", "ecse_comet_tempHut", "ecse_comet_H2OMixRatio", "ecse_mfc_sample_tempC", "ecse_mfc_valid_tempC", "HMP155_temp", "HMP155_temp_sp3"))

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_ec.temps.fst", dataTable = ec.temps.data, site = site, dateBgn = dateBgn, percentage = "52", compression = compression)
          rm(ec.temps.data)

        } else {
          message(paste0(Sys.time(), ": 52%:  NOT saving EC Temperatures Data..."))
        }
        ### Li7200 S3 Filter and Save
        if(nrow(ei.li7200) > 0){

          li7200.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "Li7200") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_Li7200.fst", dataTable = li7200.data, site = site, dateBgn = dateBgn, percentage = "56", compression = compression)
          rm(li7200.data)

        } else {
          message(paste0(Sys.time(), ": 56%:  NOT saving Li7200 Data..."))
        }
        # CSAT3
        if(nrow(ei.ecte.csat3) > 0){
          # Function to convert binary to integer
          ecte.csat3.data = mrg.rpt.distinct %>%
            dplyr::filter(stringr::str_detect(strm_name, pattern = "CSAT3") == TRUE) %>%
            reshape2::dcast(readout_time ~ strm_name, value.var = "readout_val_double") %>%
            dplyr::mutate(CSAT3_WindVector = sqrt((CSAT3_x*CSAT3_x)+sqrt(CSAT3_y*CSAT3_y)+sqrt(CSAT3_z*CSAT3_z))) %>%
            dplyr::select(readout_time,CSAT3_diag,CSAT3_SpdSnd,CSAT3_WindVector,CSAT3_x,CSAT3_y,CSAT3_z) %>%
            dplyr::mutate(SiteID = site)

          # Reassign NAs to NA
          ecte.csat3.data$CSAT3_diag[ecte.csat3.data$CSAT3_diag == "NaN"]   = NA
          ecte.csat3.data$CSAT3_diag[ecte.csat3.data$CSAT3_diag == ""]   = NA
          ecte.csat3.data$CSAT3_diag = as.integer(ecte.csat3.data$CSAT3_diag)
          ecte.csat3.data$CSAT3_code = lapply(ecte.csat3.data$CSAT3_diag, number2binary, 16)
          ecte.csat3.data$CSAT3_code_d = base::substr(ecte.csat3.data$CSAT3_code,start = 3, stop = 12)

          ecte.csat3.data.wide = ecte.csat3.data %>%
            tidyr::separate(col = "CSAT3_code_d", into = c("SpdSndAgreement","PoorSignalLock","AmplitudeHigh","AmplitudeLow"), sep = ",") %>%
            dplyr::select(-CSAT3_code) %>%
            dplyr::mutate(dplyr::across(.cols = c(SpdSndAgreement,PoorSignalLock,AmplitudeHigh,AmplitudeLow),.fns = as.numeric)) %>%
            dplyr::mutate(CodeSum = as.factor(SpdSndAgreement + PoorSignalLock + AmplitudeHigh + AmplitudeLow)) %>%
            dplyr::mutate(SpdSndAgreement = ifelse(is.na(CSAT3_diag) == TRUE, NA, SpdSndAgreement )) %>%
            dplyr::mutate(PoorSignalLock = ifelse(is.na(CSAT3_diag) == TRUE, NA, PoorSignalLock )) %>%
            dplyr::mutate(AmplitudeHigh = ifelse(is.na(CSAT3_diag) == TRUE, NA, AmplitudeHigh )) %>%
            dplyr::mutate(AmplitudeLow = ifelse(is.na(CSAT3_diag) == TRUE, NA, AmplitudeLow ))

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_CSAT3.fst", dataTable = ecte.csat3.data.wide, site = site, dateBgn = dateBgn, percentage = "60", compression = compression)
          rm(ecte.csat3.data.wide)

        } else {
          message(paste0(Sys.time(), ": 60%:  NOT saving CSAT3 Data..."))
        }
        # HMP155
        if(nrow(ei.ecte.HMP155) > 0){
          ecte.HMP155 = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "HMP155") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_HMP155.fst", dataTable = ecte.HMP155, site = site, dateBgn = dateBgn, percentage = "64", compression = compression)
          rm(ecte.HMP155)

        } else {
          message(paste0(Sys.time(), ": 64%:  NOT saving HMP155 Data..."))
        }
        # Li840
        if(nrow(ei.li840) > 0){
          li840.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "Li840") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_Li840.fst", dataTable = li840.data, site = site, dateBgn = dateBgn, percentage = "68", compression = compression)
          rm(li840.data)

        } else {
          message(paste0(Sys.time(), ": 68%:  NOT saving Li840 Data..."))
        }
        # l2130
        if(nrow(ei.l2130) > 0){
          l2130.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "L2130") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_L2130.fst", dataTable = l2130.data, site = site, dateBgn = dateBgn, percentage = "72", compression = compression)
          rm(l2130.data)

        } else {
          message(paste0(Sys.time(), ": 72%:  NOT saving L2130 Data..."))
        }

        # ECSE MFM
        if(nrow(ei.mfm) > 0){
          mfm.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "MFM_FlowRate") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_ecse.mfm.fst", dataTable = mfm.data, site = site, dateBgn = dateBgn, percentage = "76", compression = compression)
          rm(mfm.data)

        } else {
          message(paste0(Sys.time(), ": 76%:  NOT saving ECSE_MFM Data..."))
        }

        # Inlet and MFM Pressures
        if(nrow(ei.mfm.pressures) > 0){
          mfm.pressures.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "_Pressure") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_ECSE.MFM.Pressures.fst", dataTable = mfm.pressures.data, site = site, dateBgn = dateBgn, percentage = "80", compression = compression)
          rm(mfm.pressures.data)

        } else {
          message(paste0(Sys.time(), ": 80%:  NOT saving ECSE_MFM Data..."))
        }

        if(nrow(ei.ecse.mfc) > 0){
          ecse.mfc.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "SampleMFC") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_ecse.sample.mfc.fst", dataTable = ecse.mfc.data, site = site, dateBgn = dateBgn, percentage = "84", compression = compression)
          rm(ecse.mfc.data)

        } else {
          message(paste0(Sys.time(), ": 84%:  NOT saving SampleMFC Data..."))
        }

        if(nrow(ei.ecte.amrs)>0){
          ecte.amrs.data = mrg.rpt.distinct %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "AMRS") == TRUE)

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_amrs.fst", dataTable = ecte.amrs.data, site = site, dateBgn = dateBgn, percentage = "91", compression = compression)
          rm(ecte.amrs.data)

        } else {
          message(paste0(Sys.time(), ": 91%:  NOT saving AMRS Data..."))
        }
      } else {
        message(paste0(Sys.time(), ": No data in pull..."))
      }
  } else {
    message(paste0("The Date Range is greater than 11!!! Date Range:", as.Date(dateEnd) - as.Date(dateBgn)))
  }
}
