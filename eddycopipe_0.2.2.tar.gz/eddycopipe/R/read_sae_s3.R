#' @title Read and quickly stack sae data in the Cloud
#' @description A function to quickly read ETL'd data from NEON's published HDF5 files.
#' @param siteid char - four letter site code of site to read from. "CPER"
#' @param term char - eddy4R term and timing to read. "co2Turb_01m"
#' @param start date/char - start date of published data to pull
#' @param end date/char - end date of published data to pull
#' @param dp_level char - data product level of data to pull. "dp01" (we could probably get ride of this)
#' @param data_type char - type of data to pull from hdf5. "data" or "qfqm"
#' @param non_nan_data logical - remove data with zero samples?
#' @param end character or date; end date for your query, format = YYYY-MM-DD
#' @return Returns a data.table with all the data found or an empty table if no data is found
#' @export
#' @examples
#' read_sae_s3(
#'
#' )
read_sae_s3 = function(siteid = NULL, term = NULL, start = NULL, end = NULL, dp_level = "dp01", data_type = "data", non_nan_data = FALSE){

  # Basic function Logic
  if(is.null(siteid) == TRUE){
    stop("Specify siteid")
  }
  if(is.null(term) == TRUE){
    stop("Specify term")
  }
  if(is.null(start) == TRUE){
    stop("Specify start")
  }
  if(is.null(end) == TRUE){
    stop("Specify end")
  }
  if(length(siteid) != 1){
    stop("Only specify one site at a time")
  }

  allowed_terms = c("amrs_01m", "amrs_30m", "co2StorVali_30m", "co2Stor_02m", "co2Stor_30m", "co2TurbVali_01m", "co2Turb_01m", "co2Turb_30m", "h2oStor_02m","h2oStor_30m", "h2oTurb_01m", "h2oTurb_30m", "isoCo2Vali_30m", "isoCo2_09m", "isoCo2_30m", "isoH2oVali_30m", "isoH2o_09m", "isoH2o_30m","presBaro_01m", "presBaro_30m", "radiNet_01m", "radiNet_30m", "soni_01m", "soni_30m", "tempAirLvl_01m", "tempAirLvl_30m", "tempAirTop_01m","tempAirTop_30m")

  if(sum(!term %in% allowed_terms) != 0){
    stop(paste0("Term is not in allowed terms: ", paste0(term, collapse = ", "), "\n Allowed terms: ", paste0(allowed_terms, collapse = ", ")))
  }

  if(length(term) > 4){
    stop("Please only select 4 or less terms to read")
  }

  # Required Libraries
  library(dplyr)
  library(data.table)

  # S3 bucket
  ei_bucket = "neon-eddy-inquiry"

  # Convert dates into dates
  start = as.Date(start, origin = "1970-01-01")
  end = as.Date(end, origin = "1970-01-01")

  # Create date_range
  date_range = seq.Date(start, end, by = "1 day")

  if(data_type == "data"){
    # Check acceptable terms (could be made into a simple look up table eventually for even more speed)
    check_data_start_time = Sys.time()
    any_data_available = data.table::data.table()

    # Loop to grab all the available data
    for(input_date in date_range){
      input_date = as.Date(input_date, origin = "1970-01-01")

      any_data_available_raw = eddycopipe::neon_gcs_list_objects(bucket = ei_bucket, prefix = paste0("sae/", dp_level, "/", data_type, "/", input_date, "/", siteid, "/"))
      any_data_available = data.table::rbindlist(l = list(any_data_available, any_data_available_raw))
    }

    check_data_end_time = Sys.time()
    check_time = round(difftime(check_data_end_time, check_data_start_time, units = "secs"), 2)
    message(paste0(Sys.time(), ": Checking if files are available took: ",  check_time, " seconds"))

    # If there is data available in the s3 bucket
    if(nrow(any_data_available) > 0) {

      # Filter the aws.s3 get bucket df to just terms user input
      acceptable_terms = any_data_available %>%
        dplyr::select(Key) %>%
        tidyr::separate(Key, into = c("sae", "dp01", "data", "date", "site", "file"), sep = "/", remove = FALSE) %>%
        dplyr::select(Key, file) %>%
        tidyr::separate(file, into = c("site", "date", "term", "timing"), sep = "_", remove = TRUE) %>%
        dplyr::mutate(timing = gsub(x = timing, pattern = ".RDS", replacement = "")) %>%
        tidyr::unite(acceptable_term, c("term", "timing"), sep = "_") %>%
        dplyr::filter(acceptable_term %in% term)

      # If there object to read, read and stack each one
      if(nrow(acceptable_terms) > 0){

        # Reading time
        read_data_start_time = Sys.time()

        # Read in files that exist
        data_out = data.table::data.table()

        # Read in each file that was found and stack it to data_out
        for(i in base::seq_along(acceptable_terms$Key)){

          # Decide if numSamp must be creater than 0
          if(non_nan_data == TRUE){

            # Read in data from S3
            data_in = eddycopipe::neon_gcs_get_rds(object = acceptable_terms$Key[i], bucket = ei_bucket) %>%
              dplyr::filter(numSamp > 0) %>%
              dplyr::select(-file_name)

          } else {

            # Read in data from S3
            data_in = eddycopipe::neon_gcs_get_rds(object = acceptable_terms$Key[i], bucket = ei_bucket) %>%
              dplyr::select(-file_name)

          }

          # Combine all the data together
          data_out = data.table::rbindlist(l = list(data_out, data_in))
          rm(data_in)
        }

        read_data_end_time = Sys.time()
        read_time = round(difftime(read_data_end_time, read_data_start_time, units = "secs"), 2)
        message(paste0(Sys.time(), ": Reading in available files took: ",  read_time, " seconds"))

      } else {
        data_out = data.table::data.table()
      }

    } else {
      message(paste0(Sys.time(), ": No data found during this time period"))
      data_out = data.table::data.table()
    }

  } else {
    stop("Only data is an allowed data_type argument at this time")
  }

  return(data_out)

}
