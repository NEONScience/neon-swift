#' @title Simplifies setting up environment before Presto pull
#' @description  Set's up write credentials and sites to pull
#' @param site character four letter site code
#' @export
#' @examples
#' compose_L0_matrix(site = "NIWO")
get_sites_and_set_creds = function(s3_creds = NULL, sites = NULL){

  if(is.null(s3_creds) == TRUE){
    stop("Specify S3 write creds")
  }

  ei_bucket = "research-eddy-inquiry"

  # S3 connection
  remove_s3_creds()
  add_s3_creds(bucket = ei_bucket, creds = s3_creds)

  all_sites = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket)

  tis_sites = all_sites %>%
    dplyr::filter(Type == "TIS")

  # Add MD01
  md01 = data.table::data.table(
    "Domain" = "D07",
    "SiteID" = "MD01",
    "Type"   = "MDP"
  )

  siteList = data.table::rbindlist(l = list(tis_sites, md01))

  if(is.null(sites) == FALSE){
    if(sites != "ALL"){
      siteList = siteList %>%
        dplyr::filter(SiteID %in% sites)
    }

    return(siteList)
  }




}
