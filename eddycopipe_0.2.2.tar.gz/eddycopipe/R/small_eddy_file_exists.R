#' @title small_eddy_file_exists
#' @description  This function pairs checks to see if the small eddy file exists in the cloud
#' @param object_to_check Character string; path to object in s3
#' @param bucket Character string; bucket of the object
#' @export
#' @examples
#' small_eddy_file_exists(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
# Check if file already exists, else do not pull
small_eddy_file_exists = function(object_to_check = NULL, bucket = "research-eddy-inquiry"){

  # libraries
  library(aws.s3)
  library(aws.signature)

  # Check if file exists
  does_small_eddy_file_already_exist = base::suppressMessages(aws.s3::object_exists(object = object_to_check, bucket = bucket))

  return(does_small_eddy_file_already_exist)
}
