##############################################################################################
#' @title GCS - Parse `.fst` files from the cloud
#'
#' @author Kevin Styers
#' @description This function is passed to the googleCloudStorageR::gcs_get_object argument `parseFunction` and assists in parsing `.fst` files saved in the cloud.
#'
#' @return NA
#'
#' @examples
#' # Upload some data as a `.fst` files
#' cloud_object <- googleCloudStorageR::gcs_get_object(object_name = "mtcars.fst", bucket = "neon-eddy-inquiry", parseFunction = gcs_parse_fst)
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-22)
#     original creation
##############################################################################################
neon_gcs_parse_fst = function(object){
  browser()
  # Required libraries
  library(httr)
  library(fst)
  # Establish connection to object
  con <- base::gzcon(base::rawConnection(httr::content(object)))
  # On function exit, close connection
  base::on.exit(base::close(con))


  tmp_file <- tempfile()
  fst_url <- object$url
  googleCloudStorageR::gcs_get


  object <- get_objectkey(object)

  tmp <- if (is.character(filename)) {
             file.path(tempdir(TRUE), filename)
         } else {
             tempfile(fileext = paste0(".", tools::file_ext(object)))
         }
  on.exit(unlink(tmp))
  if (is.null(opts)) {
      r <- save_object(bucket = bucket, object = object, file = tmp)
  } else {
      r <- do.call("save_object", c(list(bucket = bucket, object = object, file = tmp), opts))
  }
  return(read.fst(tmp, ...))





  ft <- fst::read_fst(tmp_file)




  # Read in the file
  fst::read_fst()
}
