#' @title Create L0 matrix style matrix for ytBangerz::getSiteStreams() function
#' @description Takes a rawly formated site product matrix from blizard and converts it to an L0 matrix style sheet.
#' @param s3_creds character string; research-eddy-inquiry write credentials
#' @param matrix_raw character, file path to raw blizzard output
#' @export
#' @examples
#' create_matrix_from_blizzard(s3_creds = NULL, matrix_raw = "~/file.csv")
create_matrix_from_blizzard = function(s3_creds = NULL, matrix_raw = NULL){

  if(is.null(s3_creds)==TRUE){
    stop("Please specify write creds for s3 bucket research-eddy-inquiry")
  }
  if(is.null(matrix_raw)==TRUE){
    stop("Please specify file path to raw blizzard site product matrix")
  }

  library(data.table)
  library(dplyr)
  library(reshape2)
  library(aws.s3)
  library(aws.signature)

  # Bucket
  ei_bucket = "research-eddy-inquiry"
  # Read Creds
  Sys.setenv(
    "AWS_ACCESS_KEY_ID"     = ei_bucket,
    "AWS_S3_ENDPOINT"       = "neonscience.org",
    "AWS_DEFAULT_REGION"    = "s3.data"
  )

  # Check files exists
  do_file_exist = base::file.exists(matrix_raw)

  if(do_file_exist == TRUE){

    matrix_raw_in = data.table::fread(matrix_raw) %>%
      dplyr::select(-V1, -NameDp, -Supplier)

    # Run Net Radiation Code
    if(matrix_raw_in$idDp[1] == "DP1.00023.001"){

      # Read in tower level meta data
      tower_ml_meta = aws.s3::s3read_using(FUN = data.table::fread, object = "lookup/tis.site.meta.csv", bucket = ei_bucket) %>%
        dplyr::select(SiteID, MLs)
      names(tower_ml_meta) = c("SiteID", "Top_Level")

      # Read in all site domain lookup
      all_site_meta = aws.s3::s3readRDS(object= "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket)

      # Melt Data frame for tidy wranglin'
      matrix_melt = matrix_raw_in %>%
        reshape2::melt(id.vars = "idDp", value.name = "exist") %>%
        dplyr::filter(variable != "MD00") %>%
        dplyr::filter(exist != 2) %>%
        dplyr::mutate(SiteID = variable) %>% dplyr::select(-variable, -exist, -idDp) %>%
        dplyr::distinct() %>%
        dplyr::left_join(y = tower_ml_meta, by = "SiteID") %>%
        dplyr::rowwise() %>%
        dplyr::mutate(base_ids = base::ifelse(test = is.na(Top_Level) == FALSE, yes = paste0("DP0.00023.001.01319.000.0", Top_Level, "0.000"), no = "DP0.00023.001.01319.200.000.000")) %>%
        dplyr::select(base_ids, SiteID) %>%
        dplyr::left_join(y = all_site_meta, by = "SiteID")

      # Make base_ids for soil plots
      matrix_soil = matrix_melt %>%
        dplyr::select(-base_ids) %>%
        dplyr::filter(Type == "TIS") %>%
        dplyr::mutate(base_ids = ifelse(test = SiteID != "PUUM", yes = paste0("DP0.00023.001.01319.003.000.000"), no = paste0("DP0.00023.001.01319.002.000.000"))) %>%
        dplyr::select(SiteID, base_ids) %>%
        dplyr::mutate(value = 1)

      # Finish of tower top and ais base_ids
      matrix_partial = matrix_melt %>%
        dplyr::select(SiteID, base_ids) %>%
        dplyr::mutate(value = 1)

      # Join them all together
      matrix_final = data.table::rbindlist(l = list(matrix_partial, matrix_soil)) %>%
        reshape2::dcast(base_ids ~ SiteID, fill = 0)

      if(is.character(s3_creds) == TRUE){
          Sys.setenv(
            "AWS_ACCESS_KEY_ID"     = ei_bucket,
            "AWS_SECRET_ACCESS_KEY" = s3_creds,
            "AWS_S3_ENDPOINT"       = "neonscience.org",
            "AWS_DEFAULT_REGION"    = "s3.data"
          )
        aws.s3::s3saveRDS(x = matrix_final, bucket = ei_bucket, object = "lookup/matrix_nr01_heater.RDS")
      }

    } else {
      stop(paste0("Logic for ",  matrix_raw_in$idDp[1], " not available."))
    }

  } else {
    stop(paste0("File not found, check your path: ", raw_matrix))
  }

  return(matrix_final)

}
