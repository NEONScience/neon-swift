#' @title Wrapper function to build and test the connnection to the Presto DB
#' @description  Uses the eddycopipe functions build_presto_connection then check_connection_to_presto to verify we can connect. If we cannot it will wait 5*n minutes in n seperate attempts
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param fail NULL; for testing purposes, if you want to test the connection failure set this to TRUE
#' @export
#' @examples
#' wrap_build_test_presto_connection(CredPsto = "myusername;mypassword", destroy = NULL)
wrap_build_test_presto_connection = function(n = 3, CredPsto = NULL, fail = NULL){
  # Logic argument testing
  if(is.null(CredPsto) == TRUE){
    stop("Specify CredPsto: 'myusername;mypassword'")
  }
  if(is.numeric(n) == FALSE){
    stop("Please specify n, the number of 5 minutes invervals to wait while testing presto connection")
  }

  con = build_presto_connection(CredPsto = CredPsto, destroy = fail)

  connection_valid = check_connection_to_presto(CredPsto = CredPsto, conn = con)

  try = 0
  while(connection_valid == FALSE & try != n){
    try = try + 1
    message(paste0(Sys.time(), ": Attempt #", try , ", sleeping for 5 minutes..."))
    Sys.sleep(5*60) # Sleep for 5 minutes and try again
    con = build_presto_connection(CredPsto = CredPsto, destroy = fail)
    message(paste0(Sys.time(), ": Attempt #", try , ", trying connection again..."))
    connection_valid = check_connection_to_presto(CredPsto = CredPsto, conn = con)
  }

  return(con)

}
