#' @title Unsets all S3 Environmental Credentials
#' @description Unsets credentials for: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_S3_ENDPOINT, AWS_DEFAULT_REGION
#' @param quite logical, Should the function message out what it is doing?
#' @export
#' @examples
#' remove_s3_creds()
remove_s3_creds = function(quite = TRUE){
  if(quite == FALSE){message(paste0(Sys.time(), ": Clearing S3 Credentials"))}
  Sys.unsetenv("AWS_ACCESS_KEY_ID")
  Sys.unsetenv("AWS_SECRET_ACCESS_KEY")
  Sys.unsetenv("AWS_S3_ENDPOINT")
  Sys.unsetenv("AWS_DEFAULT_REGION")

}
