#' @title Read data from the nei_bucket S3 bucket
#' @description This function handles the mundane and repeated S3 pulls and condenses the logic down into a simple function
#' @param dataType character; specifies what data type you'd like to pull. Options include: "2min", "CnC", "cval", "cval.stats", "spanGas".
#' @param siteID character; specify the site you'd like to pull data from. "STER"
#' @param startDate character; specify the start date of the data you'd like to pull: "2020-02-09"
#' @param endDate character; specify the last date you'd like to pull: "2020-03-09"
#' @param sensor character; depending on the data type selected, filter down what sensor you'd like to pull. If you select something that's not available the function will let ya know.
#' @param silent logical; do you want the function to spit out progress of the pull along the way? Good for when you're first working with the function, but if you're running large reporting the details are less useful: TRUE / FALSE.
#' @export
#'
#' @examples
#' neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-2, endDate = Sys.Date(), sensor = "HMP155", silent = FALSE)

neon_read_eddy_inquiry = function(
  dataType = NULL,
  siteID = NULL,
  startDate = NULL,
  endDate = NULL,
  sensor = NULL,
  silent = FALSE
){

  # Set Seed, required to create the .Random.seed variable
  set.seed(42)

  # Dependencies
  require(dplyr)
  require(data.table)
  require(fst)
  require(googleCloudStorageR)

  # Set environment up for S3 connection
  nei_bucket = "neon-eddy-inquiry"


  # If test fails let the user know something is up
  if(TRUE){

    # Function variables
    allowed.datatypes = c("2min", "CnC", "cval", "cval.stats", "spanGas", "wet_dep")
    allowed.2min = c("amrs","HMP155","CSAT3","G2131","Li7200","Li840","ecse.mfm", "ecse.mfm.pressures","ecse.sample.mfc","ec.temps","ecse.voltage","Li840.valves","L2130", "Li7200.valves")
    allowed.cval = c("L2130i", "G2131i", "Li7200", "Li840A")
    allowed.SiteID = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = nei_bucket)$SiteID

    if(dataType == "meta"){
      if(sensor == "cval"){
        base::return(eddycopipe::neon_gcs_get_rds(object = "s3.lookup/s3.cval.lookup.RDS", bucket = nei_bucket))
      }
      if(sensor == "covid"){
        base::return(eddycopipe::neon_gcs_get_rds(object = "lookup/site.covid.status.RDS", bucket = nei_bucket))
      }
      if(sensor == "spanGas"){
        base::return(eddycopipe::neon_gcs_get_fst(object = "lookup/spanGasConc.fst", bucket = nei_bucket))
      }
    } else {

      # Check if any of the REQUIRED fields are not specified
      if(is.null(dataType) == FALSE & is.null(siteID) == FALSE & is.null(startDate) == FALSE & is.null(endDate) == FALSE){

        # Check if the startDate and endDate is formatted correctly, else send them an error message
        if(grepl("([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", startDate) == TRUE & grepl("([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", endDate) == TRUE){

          # Check if size is approved site list, else send em to the error message
          if(siteID %in% allowed.SiteID){

            # Datatype = 2min
            if(dataType == "2min"){
              # Check if sensor is an allowed 2min sensor
              if(sensor %in% allowed.2min){

                if(sensor == "ecse.mfm.pressures"){sensor = "ECSE.MFM.Pressures"}

                twomin.starttime = Sys.time()
                if(silent == FALSE){ base::message(paste0("Pull configured correctly: ", siteID, " ", dataType," ", sensor, " data from ", startDate, " to ", endDate)) }

                s3.2min.meta = eddycopipe::neon_get_s3_lookup(object = "s3.lookup/s3.2min.meta.RDS", bucket = nei_bucket)

                list.s3.2min = s3.2min.meta %>%
                  dplyr::filter(SiteID == siteID) %>%
                  dplyr::filter(Sensor == sensor) %>%
                  dplyr::filter(Date >= startDate & Date <= endDate) %>%
                  dplyr::mutate(Size = ifelse(test = stringr::str_detect(string = Size, pattern = "Kb") == TRUE, yes = as.numeric(gsub("[^0-9.-]", "", Size)), no =
                                       ifelse(test = stringr::str_detect(string = Size, pattern = "Mb") == TRUE, yes = 1000 * as.numeric(gsub("[^0-9.-]", "", Size)), no =
                                       ifelse(test = stringr::str_detect(string = Size, pattern = "Gb") == TRUE, yes = 1000^2 * as.numeric(gsub("[^0-9.-]", "", Size)), no =
                                       ifelse(test = stringr::str_detect(string = Size, pattern = "Tb") == TRUE, yes = 1000^3 * as.numeric(gsub("[^0-9.-]", "", Size)), no = NA))))) %>%
                  dplyr::mutate(Size = 0.001 * Size) %>% # Convert to MB
                  dplyr::filter(Size > 0.005)

                size.pull = round(sum(as.numeric(list.s3.2min$Size))/8000000, 2)
                if(silent == FALSE){ message(paste0("Downloading ", nrow(list.s3.2min), " files - ", size.pull, " MB")) }
                pull.join = data.table::data.table()

                if(length(list.s3.2min$Key) > 0){

                  amrs.join.starttime = Sys.time()

                  if(silent == FALSE){ pb = txtProgressBar(0, length(list.s3.2min$Key), style = 3) }

                  for(file in 1:length(list.s3.2min$Key)){

                    if(silent == FALSE){ setTxtProgressBar(pb, file) }
                    pull.file = eddycopipe::neon_gcs_get_fst(bucket = nei_bucket, object = list.s3.2min$Key[file])

                    pull.join = data.table::rbindlist(l = list(pull.join, pull.file))
                  }
                } else {
                  if(silent == FALSE){ message(paste0("No data found for pull: ", siteID, " ", dataType," ", sensor, " data from ", startDate, " to ", endDate)) }
                }
                # Collect and present time stats
                twomin.endtime = Sys.time()
                twomin.pull.time = round(difftime(twomin.endtime, twomin.starttime, units = "secs"),2)
                if(silent == FALSE){ message("\nPull Lasted: ", twomin.pull.time, " seconds...") }
                # Return data
                return(pull.join)
              } else {
                message("ERROR: sensor selected is incorrect. Please select one from: ", paste0(allowed.2min, collapse = ", "))
              }
            }

            # Datatype is CnC
            if(dataType == "CnC"){
              cnc.starttime = Sys.time()
              if(silent == FALSE){ base::message(paste0("Pull configured correctly: ", dataType," ", siteID, " data from ", startDate, " to ", endDate)) }

              s3.cnc.meta = eddycopipe::neon_get_s3_lookup(object = "s3.lookup/s3.cnc.meta.RDS", bucket = nei_bucket) %>%
                dplyr::filter(Site == siteID)

              pull.file = eddycopipe::neon_gcs_get_fst(bucket = nei_bucket, object = s3.cnc.meta$Key[1]) %>%
                dplyr::filter(date >= startDate & date <= endDate)

              # Collect and present time stats
              cnc.endtime = Sys.time()
              cnc.pull.time = round(difftime(cnc.endtime, cnc.starttime, units = "secs"),2)
              if(silent == FALSE){ message("\nPull Lasted: ", cnc.pull.time, " seconds...") }
              # Return data
              return(pull.file)
            }
            # Datatype is spanGas
            if(dataType == "spanGas"){
              spanGas.starttime = Sys.time()
              if(silent == FALSE){ base::message(paste0("Pull configured correctly: ", dataType," ", siteID, " data from ", startDate, " to ", endDate)) }

              s3.spanGas.meta = eddycopipe::neon_get_s3_lookup(object = "s3.lookup/s3.spanGas.meta.RDS", bucket = nei_bucket)

              list.s3.spanGas = s3.spanGas.meta %>%
                dplyr::filter(Site == siteID) %>%
                dplyr::filter(Date >= startDate & Date <= endDate)

              size.pull = round(sum(as.numeric(list.s3.spanGas$Size))/8000000, 6)

              if(silent == FALSE){ message(paste0("Downloading ", nrow(list.s3.spanGas), " files - ", size.pull, " MB")) }

              pull.join = data.table::data.table()

              if(length(list.s3.spanGas$Key) > 0){

                spanGas.join.starttime = Sys.time()
                if(silent == FALSE){ pb = txtProgressBar(0, length(list.s3.spanGas$Key), style = 3) }

                for(file in 1:length(list.s3.spanGas$Key)){
                  if(silent == FALSE){ setTxtProgressBar(pb, file) }

                  pull.file = eddycopipe::neon_gcs_get_fst(bucket = nei_bucket, object = list.s3.spanGas$Key[file])

                  pull.join = data.table::rbindlist(l = list(pull.join, pull.file))
                }
                # Join time statistics
                spanGas.join.endtime = Sys.time()
                spanGas.join.time = round(difftime(spanGas.join.endtime, spanGas.join.starttime, units = "secs"),2)
                if(silent == FALSE){  message("\nJoin Lasted: ", spanGas.join.time, " seconds...") }
                # Span Gas lookup table DPID - Cyl Name
                spanGas.name.lookup = eddycopipe::neon_gcs_get_rds(object = "lookup/span_gas_dpid_lookup.RDS", bucket = nei_bucket)
                # Clean / Name the data streams
                pull.join = pull.join %>%
                  dplyr::mutate(DPID = substr(meas_strm_name, 15, 2000)) %>%
                  dplyr::select(-meas_strm_name) %>%
                  dplyr::mutate(minVal   = round(minVal/6.895, 2)) %>%
                  dplyr::mutate(meanVal  = round(meanVal/6.895, 2)) %>%
                  dplyr::mutate(maxVal   = round(maxVal/6.895, 2)) %>%
                  dplyr::mutate(stDevVal = round(stDevVal/6.895, 2)) %>%
                  dplyr::left_join(spanGas.name.lookup, by = "DPID") %>%
                  dplyr::mutate(Date = StartTime) %>%
                  dplyr::select(SiteID, Date, strm_name, meanVal, minVal, maxVal, stDevVal)

              } else {
                if(silent == FALSE){ message(paste0("No data found for pull: ", siteID, " ", dataType," ", sensor, " data from ", startDate, " to ", endDate)) }
              }
              # Collect and present time stats
              spanGas.endtime = Sys.time()
              spanGas.pull.time = round(difftime(spanGas.endtime, spanGas.starttime, units = "secs"),2)
              if(silent == FALSE){ message("\nPull Lasted: ", spanGas.pull.time, " seconds...") }
              # Return data
              return(pull.join)
            }

            # Datatype is spanGas
            if(dataType == "wet_dep"){
              wet_dep.starttime = Sys.time()
              if(silent == FALSE){ base::message(paste0("Pull configured correctly: ", dataType," ", siteID, " data from ", startDate, " to ", endDate)) }

              s3.wet_dep.meta = eddycopipe::neon_get_s3_lookup(object = "s3.lookup/s3_meta_wet_dep.RDS", bucket = nei_bucket)

              list.s3.wet_dep = s3.wet_dep.meta %>%
                dplyr::filter(SiteID == siteID) %>%
                dplyr::filter(Date >= startDate & Date <= endDate)

              size.pull = round(sum(as.numeric(list.s3.wet_dep$Size))/8000000, 6)

              if(silent == FALSE){ message(paste0("Downloading ", nrow(list.s3.wet_dep), " files - ", size.pull, " MB")) }

              pull.join = data.table::data.table()

              if(length(list.s3.wet_dep$Key) > 0){

                spanGas.join.starttime = Sys.time()
                if(silent == FALSE){ pb = txtProgressBar(0, length(list.s3.wet_dep$Key), style = 3) }

                for(file in 1:length(list.s3.wet_dep$Key)){
                  if(silent == FALSE){ setTxtProgressBar(pb, file) }

                  pull.file = eddycopipe::neon_gcs_get_fst(bucket = nei_bucket, object = list.s3.wet_dep$Key[file])

                  pull.join = data.table::rbindlist(l = list(pull.join, pull.file))
                }
                # Join time statistics
                wet_dep.endtime = Sys.time()
                wet_dep.time = round(difftime(wet_dep.endtime, wet_dep.starttime, units = "secs"),2)
                if(silent == FALSE){  message("\nJoin Lasted: ", wet_dep.time, " seconds...") }

              } else {
                if(silent == FALSE){ message(paste0("No data found for pull: ", siteID, " ", dataType," ", sensor, " data from ", startDate, " to ", endDate)) }
              }
              # Collect and present time stats
              wet_dep.endtime = Sys.time()
              wet_dep.pull.time = round(difftime(wet_dep.endtime, wet_dep.starttime, units = "secs"),2)
              if(silent == FALSE){ message("\nPull Lasted: ", wet_dep.pull.time, " seconds...") }
              # Return data
              return(pull.join)
            }

            # Datatype is cval
            if(dataType == "cval"){
              if(is.null(sensor) == FALSE){
                if(sensor %in% allowed.cval){
                  cval.starttime = Sys.time()
                  if(silent == FALSE){ base::message(paste0("Pull configured correctly: ", dataType," ", siteID, " data from ", startDate, " to ", endDate)) }

                  s3.cval.meta = eddycopipe::neon_get_s3_lookup(object = "s3.lookup/s3.cval.lookup.RDS", bucket = nei_bucket)

                  list.s3.cval = s3.cval.meta %>%
                    dplyr::filter(Site == siteID) %>%
                    dplyr::filter(Sensor == sensor) %>%
                    dplyr::filter(StartDateTime >= startDate & EndDateTime <= endDate) %>%
                    dplyr::arrange(StartDateTime) %>%
                    dplyr::mutate(prev_time = lag(StartDateTime))  %>%
                    dplyr::mutate(diffTime = round(difftime(StartDateTime, prev_time, units = "mins"),0)) %>%
                    dplyr::filter(diffTime > 360 | is.na(diffTime) == TRUE)

                  # browser()

                  size.pull = round(sum(as.numeric(list.s3.cval$Size))/8000000, 3)

                  if(silent == FALSE){ message(paste0("Downloading ", nrow(list.s3.cval), " files - ", size.pull, " MB")) }

                  pull.join = data.table::data.table()
                  rand.seed = as.data.table(.Random.seed) %>%
                    dplyr::filter(as.integer(`.Random.seed`) > 0)
                  if(length(list.s3.cval$Key) > 0){

                    cval.join.starttime = Sys.time()
                    if(silent == FALSE){ pb = txtProgressBar(0, length(list.s3.cval$Key), style = 3) }

                    for(file in 1:length(list.s3.cval$Key)){
                      if(silent == FALSE){ setTxtProgressBar(pb, file) }

                      pull.file = eddycopipe::neon_gcs_get_fst(bucket = nei_bucket, object = list.s3.cval$Key[file])

                      pull.file$uid = paste0(as.Date(list.s3.cval$StartDateTime[file]), "_",
                                              base::substr(rand.seed$.Random.seed[[file]], start = 1, stop = 4))

                      pull.join = data.table::rbindlist(l = list(pull.join, pull.file))
                    }
                  } else {
                    if(silent == FALSE){ message(paste0("No data found for pull: ", siteID, " ", dataType," ", sensor, " data from ", startDate, " to ", endDate)) }
                  }
                  # Collect and present time stats
                  cval.endtime = Sys.time()
                  cval.pull.time = round(difftime(cval.endtime, cval.starttime, units = "secs"),2)
                  if(silent == FALSE){ message("\nPull Lasted: ", cval.pull.time, " seconds...") }
                  # Return data
                  return(pull.join)
                }  else {
                  message(
                    paste0(
                      "ERROR: Please select a cval sensor: ", sensor,
                      "\n Allowed sensor's: ", paste0(allowed.cval, collapse = ", ")
                    )
                  )
                }
                # Check cval sensor, if sensor was even selected
              } else {
                message(
                  paste0(
                    "ERROR: Please select a cval sensor: ", sensor,
                    "\n Allowed sensor's: ", paste0(allowed.cval, collapse = ", ")
                  )
                )
              }
              # Check dataType, if dataType is not correct
            }

            if(dataType == "cval.stats"){
              if(is.null(sensor) == FALSE){
                if(sensor %in% allowed.cval){
                  # browser()

                  cval.starttime = Sys.time()
                  if(silent == FALSE){ base::message(paste0("Pull configured correctly: ", dataType," ", siteID, " data from ", startDate, " to ", endDate)) }

                  s3.cval.stats.meta = eddycopipe::neon_get_s3_lookup(object = "s3.lookup/s3.cval.stats.lookup.RDS", bucket = nei_bucket)

                  list.s3.cval.stats = s3.cval.stats.meta %>%
                    dplyr::filter(Site == siteID) %>%
                    dplyr::filter(Sensor == sensor) %>%
                    dplyr::filter(StartDateTime >= startDate & EndDateTime <= endDate)

                  size.pull = round(sum(as.numeric(list.s3.cval.stats$Size))/8000000, 3)

                  if(silent == FALSE){ message(paste0("Downloading ", nrow(list.s3.cval.stats), " files - ", size.pull, " MB")) }

                  pull.join = data.table::data.table()
                  rand.seed = as.data.table(.Random.seed) %>%
                    dplyr::filter(as.integer(`.Random.seed`) > 0)
                  if(length(list.s3.cval.stats$Key) > 0){

                    cval.join.starttime = Sys.time()
                    if(silent == FALSE){ pb = txtProgressBar(0, length(list.s3.cval.stats$Key), style = 3) }

                    for(file in 1:length(list.s3.cval.stats$Key)){
                      if(silent == FALSE){ setTxtProgressBar(pb, file) }

                      pull.file = eddycopipe::neon_gcs_get_rds(bucket = nei_bucket, object = list.s3.cval.stats$Key[file])

                      pull.file$uid = paste0(as.Date(list.s3.cval.stats$StartDateTime[file]), "_",
                                              base::substr(rand.seed$.Random.seed[[file]], start = 1, stop = 4))

                      pull.join = data.table::rbindlist(l = list(pull.join, pull.file))
                    }
                  } else {
                    if(silent == FALSE){ message(paste0("No data found for pull: ", siteID, " ", dataType," ", sensor, " data from ", startDate, " to ", endDate)) }
                  }
                  # Collect and present time stats
                  cval.endtime = Sys.time()
                  cval.pull.time = round(difftime(cval.endtime, cval.starttime, units = "secs"),2)
                  if(silent == FALSE){ message("\nPull Lasted: ", cval.pull.time, " seconds...") }
                  # Return data
                  return(pull.join)
                } else {
                  message(
                    paste0(
                      "ERROR: Please select a cval sensor: ", sensor,
                      "\n Allowed sensor's: ", paste0(allowed.cval, collapse = ", ")
                    )
                  )
                }
                # Check cval sensor, if sensor was even selected
              } else {
                message(
                  paste0(
                    "ERROR: Please select a cval sensor: ", sensor,
                    "\n Allowed sensor's: ", paste0(allowed.cval, collapse = ", ")
                  )
                )
              }


            } else {
              message(
                paste0(
                  "ERROR: Please enter an approved dataType: ", dataType,
                  "\n Allowed dataType's: ", paste0(allowed.datatypes, collapse = ", ")
                )
              )
            }
            # Check siteID, if siteID is not in approved list...
          } else {
            base::message(
              base::paste0(
                "The entered SiteID is not from the approved list for your dataType, \n SiteID = ", siteID
              )
            )
          }
          # Check dates, if date is not properly formated, provide this error.
        } else {
          base::message(
            base::paste0(
              "One of the input dates is formatted incorrectly. (YYYY-MM-DD) \n",
              "startDate: \t", startDate,"\n",
              "endDate: \t",    endDate,  "\n"
            ))
        }
        # Check if any REQUIRED variables are not specified
      } else {
        base::message(
          base::paste0(
            "ERROR: one of your input variable is NULL...",
            "\n dataType  =\t", dataType,
            "\n SiteID    =\t", siteID,
            "\n startDate =\t", startDate,
            "\n endDate   =\t", endDate
          ))
      }
    }
  } else {
    stop("Connection to research-eddy-inquiry aws bucket fail! Check your VPN!")
  }
}
