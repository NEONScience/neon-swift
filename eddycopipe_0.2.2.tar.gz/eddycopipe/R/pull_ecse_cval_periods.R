#' @title Base function to pull all ecse cval periods.
#' @description  This function pulls ecte cval period data based upon validation valves status.
#' @param idDp string containing full data product ID for the valve needed (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param dateBgn date; start of data pull
#' @param dateEnd date; end of data pull
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param sensor_names lookup table containing all the sensor names and their dpids
#' @export
#' @examples
#' pull_ecse_cval_periods()
pull_ecse_cval_periods = function(idDp, dateBgn, dateEnd, CredPsto = NULL, sensor_names = NULL) {

  # Required Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(aws.s3)
  library(aws.signature)
  library(tidyr)
  library(here)

  # Check that Date Range is only 1 day, if != 1, do not run!
  if(as.Date(dateEnd) - as.Date(dateBgn) <= 90){

    idDp = base::as.vector(idDp$streams)

    site = unique(substr(idDp,10,13))

    con = wrap_build_test_presto_connection(CredPsto = CredPsto)

    # Stream formatting:
    valveChar = sapply(idDp, function(x) paste0("",x,"")) %>% paste0(collapse=",") %>% as.factor() %>% paste0(collapse=",")

    # Actual SQL query sent to Presto
    sql = glue::glue_sql("SELECT
                             meas_strm_name,
                             readout_time,
                             readout_val_double
                           FROM
                             readouts
                           WHERE
                             site = {site} and
                             meas_strm_name IN ({valveChar}) and
                             readout_val_double = 1 and
                             ds between {dateBgn} and {dateEnd}
                           ",
                           .con = con
                           ) %>%
        gsub(pattern = "NEON",replacement = "'NEON") %>%
        gsub(pattern = "0,", replacement = "0',") %>%
        gsub(pattern = "1,", replacement = "1',") %>%
        gsub(pattern = "2,", replacement = "2',") %>%
        gsub(pattern = "3,", replacement = "3',") %>%
        gsub(pattern = "''", replacement = "'") %>%
        gsub(pattern = '""', replacement = '"') %>%
        gsub(pattern = '"approx', replacement = "approx") %>%
        gsub(pattern = '0.95),"', replacement = "0.95),")

      start=Sys.time()
      res = DBI::dbSendQuery(con, sql)
      mrg_rpt= DBI::dbFetch(res,-1)
      DBI::dbDisconnect(con)

      # Join lookup table and summarize data
      # G2131-i Validations Periods
      daily_ecse_cval_period_1 = mrg_rpt %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name,15,33)) %>%
        dplyr::left_join(y = sensor_names, by = "DPID") %>%
        dplyr::filter(strm_name == "G2131_Validation_Valve") %>%
        dplyr::group_by(strm_name) %>%
        dplyr::arrange(strm_name, readout_time) %>%
        dplyr::mutate(diff = round(readout_time - lag(readout_time),1))   %>% # G2131 : max 10s diff
        dplyr::mutate(start_time = ifelse(is.na(diff) == "TRUE", yes = "TRUE",         # Li840
                         no = ifelse(diff > 360, yes = "TRUE", no = ""))) %>%
        dplyr::mutate(end = lead(start_time)) %>%
        dplyr::mutate(end = ifelse(is.na(end) == "TRUE", yes = "TRUE", no = end)) %>%
        dplyr::filter(start_time == "TRUE" | end == "TRUE") %>%
        dplyr::mutate(endTime = ifelse(end == "TRUE", readout_time, NA))   %>%
        dplyr::mutate(endTime = lead(endTime))   %>%
        dplyr::mutate(endTime = as.POSIXct(endTime, origin = "1970-01-01 00:00:00", tz = "UTC")) %>%
        dplyr::filter(start_time == "TRUE") %>%
        dplyr::mutate(cval.time.seconds = round(difftime(endTime,readout_time, units = "secs"),0)) %>%
        dplyr::mutate(startTime = readout_time) %>%
        dplyr::mutate(siteID = site) %>%
        dplyr::select(siteID, strm_name, startTime, endTime, cval.time.seconds) %>%
        dplyr::mutate(cval_name = "G2131i Daily Validation")%>%
        dplyr::filter(as.Date(startTime, origin = "1970-01-01", format = "%Y-%m-%d") < dateEnd) # We must filter out any validations that start after the initial pull date, this ensure's we don't duplicate cvals
      # Li840 Validations Periods
      daily_ecse_cval_period_2 = mrg_rpt %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name,15,33)) %>%
        dplyr::left_join(y = sensor_names, by = "DPID") %>%
        dplyr::filter(strm_name == "Li840_Validation_Valve") %>%
        dplyr::group_by(strm_name) %>%
        dplyr::arrange(strm_name, readout_time) %>%
        dplyr::mutate(diff = round(readout_time - lag(readout_time),1))   %>% # G2131 : max 10s diff
        dplyr::mutate(start_time = ifelse(is.na(diff) == "TRUE", yes = "TRUE",         # Li840
                                          no = ifelse(diff > 360, yes = "TRUE", no = ""))) %>%
        dplyr::mutate(end = lead(start_time)) %>%
        dplyr::mutate(end = ifelse(is.na(end) == "TRUE", yes = "TRUE", no = end)) %>%
        dplyr::filter(start_time == "TRUE" | end == "TRUE") %>%
        dplyr::mutate(endTime = ifelse(end == "TRUE", readout_time, NA))   %>%
        dplyr::mutate(endTime = lead(endTime))   %>%
        dplyr::mutate(endTime = as.POSIXct(endTime, origin = "1970-01-01 00:00:00", tz = "UTC")) %>%
        dplyr::filter(start_time == "TRUE") %>%
        dplyr::mutate(cval.time.seconds = round(difftime(endTime,readout_time, units = "secs"),0)) %>%
        dplyr::mutate(startTime = readout_time) %>%
        dplyr::mutate(siteID = site) %>%
        dplyr::select(siteID, strm_name, startTime, endTime, cval.time.seconds) %>%
        dplyr::filter(cval.time.seconds >= 295) %>% # Limits pull to only situations where a "Full" zeroing occured.
        dplyr::mutate(endTime = endTime + 1180 + 900) %>% # Add 1180 for full CVAl then Add 900 for fifteen minutes after cval to see leak check
        dplyr::mutate(startTime = startTime - 295) %>%
        dplyr::mutate(cval_name = ifelse(test = strm_name == "Li840_Validation_Valve" & cval.time.seconds < 800,
                                         yes = "Li840A Daily Validation",
                             no = ifelse(test = strm_name == "Li840_Validation_Valve" & cval.time.seconds > 800,
                                         yes = "Li840A Calibration and Validation", no = NA))) %>%
        dplyr::filter(as.Date(startTime, origin = "1970-01-01", format = "%Y-%m-%d") < dateEnd) # We must filter out any validations that start after the initial pull date, this ensure's we don't duplicate cvals
      # L2130-i Validations Periods
      daily_ecse_cval_period_3 = mrg_rpt %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name,15,33)) %>%
        dplyr::left_join(y = sensor_names, by = "DPID") %>%
        dplyr::filter(strm_name == "L2130_Validation_Valve") %>%
        dplyr::group_by(strm_name) %>%
        dplyr::arrange(strm_name, readout_time) %>%
        dplyr::mutate(diff = round(readout_time - lag(readout_time),1))  %>% # G2131 : max 10s diff
        dplyr::mutate(start_time = ifelse(is.na(diff) == "TRUE", yes = "TRUE",         # Li840
                         no = ifelse(diff > 1000, yes = "TRUE", no = ""))) %>%
        dplyr::mutate(end = lead(start_time)) %>%
        dplyr::mutate(end = ifelse(is.na(end) == "TRUE", yes = "TRUE", no = end)) %>%
        dplyr::filter(start_time == "TRUE" | end == "TRUE") %>%
        dplyr::mutate(endTime = ifelse(end == "TRUE", readout_time, NA)) %>%
        dplyr::mutate(endTime = lead(endTime)) %>%
        dplyr::filter(start_time == "TRUE") %>%
        dplyr::mutate(endTime = as.POSIXct(endTime, origin = "1970-01-01 00:00:00", tz = "UTC")) %>%
        dplyr::mutate(cval.time.seconds = round(difftime(endTime,readout_time, units = "secs"),0)) %>%
        dplyr::mutate(startTime = readout_time) %>%
        dplyr::mutate(siteID = site)  %>%
        dplyr::select(siteID, strm_name, startTime, endTime, cval.time.seconds) %>%
        dplyr::mutate(cval_name = ifelse(test = cval.time.seconds < 10000, yes = "L2130i Daily Validation", no = "L2130i LHD/Annual Calibrations"))%>%
        dplyr::filter(as.Date(startTime, origin = "1970-01-01", format = "%Y-%m-%d") < dateEnd) # We must filter out any validations that start after the initial pull date, this ensure's we don't duplicate cvals

      daily_ecse_cval_period = data.table::rbindlist(l = list(daily_ecse_cval_period_1, daily_ecse_cval_period_2, daily_ecse_cval_period_3))
      # Free up RAM
      rm(mrg_rpt, daily_ecse_cval_period_1, daily_ecse_cval_period_2, daily_ecse_cval_period_3)

      numberOfCvals = nrow(daily_ecse_cval_period)

      if(nrow(daily_ecse_cval_period) > 0){

        s3_object_name = paste0("cval/ecse.cval.periods.data/", site, "_", numberOfCvals, "_", dateBgn, "_", dateEnd, ".RDS")
        eddycopipe::wrap_neon_gcs_upload(x = daily_ecse_cval_period, object = s3_object_name, bucket = "neon-eddy-inquiry")
        s3_object_exists = eddycopipe::neon_gcs_object_exists(object_name = s3_object_name, bucket = "neon-eddy-inquiry")
        if(s3_object_exists == TRUE){ message(paste0(Sys.time(), ": Saved ", s3_object_name, "..."))} else { stop(paste0(s3_object_name, " data failed to save properly")) }

        # Save locally for fast pulls, files are relatively small so this is okay :)]
        # Older and wiser kstyers: This, turns out was not okay
        # if(Sys.info()['sysname'] == "Windows"){message("Windowwws!")}
        # if(Sys.info()['sysname'] == "Linux"){
        #   local_object_name =  paste0("~/eddyInquiry/data/", s3_object_name)
        #   base:::saveRDS(object = daily_ecse_cval_period, file = local_object_name)
        # }

      }
  } else {
    message(paste0(Sys.time(), ": Date range is greater than 1 month, please reduce...\nDate range: ", as.Date(dateEnd)-as.Date(dateBgn)))
  }
}
