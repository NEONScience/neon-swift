#' @title Check what sae data is available in S3
#' @description This function using `check_sae_data_avail()` checks all the dates inbetween the `startdate` and `endate`. The default is to check dp_level of "DP4"
#' @param startdate date; YYYY-MM-DD start date of the ranage of dates you want to query.
#' @param enddate date; YYYY-MM-DD last date of the ranage of dates you want to query.
#' @param plot logical, do you want plot showing you a visual reference of the available data
#' @param dp_level string, probably always leave this as "DP4"
#' @export
#' @examples
#'  query_avail_sae_data(startdate = base::Sys.Date() - 30, enddate = base::Sys.Date(), plot = FALSE, dp_level = "DP4")
query_avail_sae_data = function(startdate = base::Sys.Date() - 30, enddate = base::Sys.Date(), plot = FALSE, dp_level = "DP4"){
  # Required libraries
  base::library(data.table)
  base::library(dplyr)

  # List of dates to query based upon user inputs
  query_dates = base::seq.Date(from = startdate, to = enddate, by = 1)

  # Message user something reassuring
  message(paste0("Checking neon-sae-file availability from ", startdate, " to ", enddate, "..."))

  # Create a progress bar
  pb = utils::txtProgressBar(0, length(query_dates), style = 3)

  # Create a data.table to join to
  data_out = data.table::data.table()

  # For loop to check each date's data availability
  for(i in base::seq_along(query_dates)){

    utils::setTxtProgressBar(pb, i)

    list_of_sites_with_data = base::unique(check_sae_data_avail(query_date = query_dates[i], data_product_level = dp_level, return_data = TRUE, quiet = TRUE)[[2]]$site)

    if(base::is.null(list_of_sites_with_data) == TRUE){
      data_in = data.table::data.table(date = query_dates[i], sites = "", total = 0)
    }
    if(base::is.null(list_of_sites_with_data) == FALSE){
      data_in = data.table::data.table("date" = query_dates[i], "sites" = (list_of_sites_with_data), total = base::length(list_of_sites_with_data))
    }
    data_out = data.table::rbindlist(l = base::list(data_out, data_in))
  }

  if(plot == TRUE){
    base::library(ggplot2)
    plot_out = ggplot(data = data_out %>% dplyr::distinct(date, total), aes(x = date, y = total)) +
      geom_col() +
      geom_hline(yintercept = 47, linetype = "dashed") +
      geom_vline(xintercept = enddate, show.legend = TRUE) +
      scale_y_continuous(breaks = c(0,5,10,15,20,25,30,35,40,45,47))+
      scale_x_date(breaks = scales::pretty_breaks(n = 6)) +
      labs(title = paste0("Number of sites available in the neon-sae-files S3 Bucket"),
           subtitle = paste0(startdate, " to ", enddate ),
           caption = "Vertical line is the enddate, you specified",
           y = "", x = "")

    data_out = list(data_out, plot_out)
  }
  return(data_out)
}
