##############################################################################################
#' @title GCS - Read `.rds` files directly from the cloud
#'
#' @author Kevin Styers
#' @description This function wraps googleCloudStorageR::gcs_get_object to download the file, read it in, delete the file from memory, then return the values
#'
#' @param object the name of the object (or the path) in the cloud to read
#' @param bucket the name of the bucket
#'
#' @return the .rds table in the cloud
#'
#' @examples
#' neon_gcs_get_rds(object_name = "mtcars.rds")
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-03-02)
#     original creation
##############################################################################################
neon_gcs_get_rds = function(object = NULL, bucket = NULL){

  # Logic
  if(is.null(object) | is.null(bucket)){
    stop(paste0(Sys.time(), ": args not specified, please specify both object and bucket"))
  }

  # Libraries
  library(fst)
  library(googleCloudStorageR)

  # Check if object exists
  object_exists = eddycopipe::neon_gcs_object_exists(bucket = bucket, object_name = object)

  if(object_exists){
    rds_file = googleCloudStorageR::gcs_get_object(object_name = object, bucket = bucket, parseFunction = eddycopipe::neon_gcs_parse_rds)
  } else {
    rds_file = data.table::data.table()
  }

  return(rds_file)

}
