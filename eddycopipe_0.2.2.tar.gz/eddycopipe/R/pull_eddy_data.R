#' @title Pull Specific Stream from Expanded EddyCo
#' @description This function pulls and stacks data based upon user inputs and returns a single data.table with all the data that was found. STILL IN DEV
#' @param siteid character; NEON Site ID, ie BARR
#' @param start character or date; start date for your query, format = YYYY-MM-DD
#' @param end character or date; end date for your query, format = YYYY-MM-DD
#' @param dp_ver character; DP4 or IP4 or IP0 (currently only tested/works with DP4)
#' @param code_ver character; latest, there are new code version and it's unclear which is which, so we will just grab what ever is latest
#' @param data_type character; specify what type of data to pull from hdf5, data, qfqm, etc (only tested/works with data)
#' @param type character; specify if you want basic or expanded
#' @param avg_interval charater; specify the averaging interval to pull from: 01m, 02m, 09m, 30m (only tested/works with 30m)
#' @param dp character or list of characters; specify what dp's to pull from: "co2Stor" or c("co2Stor", h2oTurb)
#' @param dp_level character, what level data product to pull from: "dp01" or "dp04" (only tested/works with dp01)
#' @param s3_creds character, your s3 write creds for research-eddy-inquiry
#' @return Returns a data.table with all the data found or an empty table if no data is found
#' @export
#' @examples
#' pull_eddy_data(
#'   siteid       = "CPER",
#'   start        = Sys.Date()-10,
#'   end          = Sys.Date()-8,
#'   dp_ver       = "DP4",
#'   type         = "basic",
#'   avg_interval = "30m",
#'   dp           = dps,
#'   dp_level     = "dp01",
#'   data_type    = "data",
#'   over_write   = FALSE,
#'   s3_creds     = readRDS("my_secret_s3_write_key.RDS")
#' )
#'
pull_eddy_data = function(
  siteid       = NULL,
  start        = NULL,
  end          = NULL,
  dp_ver       = "DP4",
  code_ver     = "latest",
  data_type    = "data",
  type         = "expanded",
  avg_interval = "30m",
  dp           = "co2Stor",
  dp_level     = "dp01",
  over_write   = FALSE
  ){

  # Create inverse %in%
  `%not%` = Negate(`%in%`)

  # Function logic to catch any mis-specified arguments
  if(is.null(siteid) == TRUE){
    stop("Please specify siteid")
  }
  # Cant save data in package without causing issues on install into 4.0
  # if(siteid %not% eddycopipe::site_list$SiteID){
  #   stop("Site must be in approved list; site_list$SiteID, only TIS sites are available.")
  # }

  # Convert these args to dates~
  start = base::as.Date(start, origin = "1970-01-01")
  end   = base::as.Date(end  , origin = "1970-01-01")

  if(as.numeric(end - start) < 0){
    stop("Your start and end date result in a negative value, make sure your start date is before your end date")
  }
  if(dp_ver %not% c("DP4")){
    stop("dp_ver not allowed: ", dp_ver)
  }
  if(code_ver %not% c("latest")){
    stop("dp_ver not allowed: ", code_ver)
  }
  if(data_type %not% c("data")){
    stop("data_type not allowed: ", data_type)
  }
  if(type %not% c("expanded", "basic")){
    stop("type not allowed: ", type)
  }
  if(avg_interval %not% c("30m")){
    stop(base::paste0("avg_interval must be: 30m"))
  }
  if(sum(dp %not% c("co2Stor", "h2oStor", "isoCo2", "isoH2o", "co2Turb", "h2oTurb", "soni", "amrs",  "presBaro", "radiNet", "tempAirLvl", "tempAirTop", "co2StorVali", "co2TurbVali", "isoCo2Vali", "isoH2oVali")) != 0){
    stop(base::paste0('dp must be one of the following or a list: c("co2Stor", "isoCo2", "soni", "co2Turb", "h2oTurb", "presBaro", "radiNet", "tempAirLvl", "tempAirTop")'))
  }
  if(dp_level %not% c("dp01")){
    stop(base::paste0("dp_level must be: dp01"))
  }
  if(over_write %not% c(TRUE, FALSE)){
    stop(base::paste0("over_write must be a logical: TRUE or FALSE"))
  }



  # If a function is not name-spaced, it is either a baseR function or an eddycopipe function
  # TODO What to do about different version levels
  # Required libraries
  library(rhdf5)
  library(aws.s3)
  library(aws.signature)
  library(data.table)
  library(dplyr)
  library(tidyr)
  library(utils)
  library(R.utils)

  # Set read creds
  ei_bucket = "research-eddy-inquiry"
  add_s3_creds(bucket = ei_bucket)
  # Check if site is core or not (isoH2o)
  site_meta = aws.s3::s3read_using(FUN = data.table::fread, object = "lookup/tis.site.meta.csv", bucket = ei_bucket) %>%
    dplyr::filter(SiteID == siteid)
  # Remove creds
  remove_s3_creds()
  # If site is not core, then remove isoH2o streams
  if(site_meta$L2130[1] != 1){
    dp = dp[-grep(x = dp, pattern = "isoH2o")]
  }

  # Begin timer
  start_time = Sys.time()

  # Create a range of dates between start and end
  date_range = base::seq.Date(start, end, by = "1 day")

  # Empty table to join to
  data_available = data.table::data.table()

  # Check if data is available for each date in the query
  for(i in date_range){
    # Convert to date (sigh)
    i = base::as.Date(i, origin = "1970-01-01")
    # Check if site is available for download
    site_available_check = check_sae_data_avail(query_date = i, data_product_level = dp_ver, return_data = TRUE)[[2]]
    # Check if there is any data available
    if(nrow(site_available_check) > 0){
      # Filter to basic or expanded files
      site_available = site_available_check %>%
        dplyr::filter(site == siteid) %>%
        dplyr::filter(stringr::str_detect(string = Key, pattern = type) == TRUE) %>%
        dplyr::filter(stringr::str_detect(string = Key, pattern = paste0(base::substr(i, 0, 7), ".basic.")) == FALSE) # Filter out monthly files
    } else {
      # If no data is available provide an empty table
      site_available = data.table::data.table()
    }
    # Combine the joining table to the site_available table
    data_available = data.table::rbindlist(l = list(data_available, site_available))
  }

  # If we can find data, proceed, otherwise warn user that nothing was found
  if(nrow(data_available) > 0){
    # Establish temp_dir to save zips to
    the_temp_dir = base::tempdir()
    # Empty table to join to
    data_out_final = data.table::data.table()
    # Filter to data we either want to overwrite or do not yet exist
    if(over_write == FALSE){
      # Blank table to join to
      data_available_to_write = data.table::data.table()

      # Sequence through all the keys and check if they exist
      for(y in seq_along(data_available$Key)){
        # Filter to just the key in the loop, and check if the file exists
        data_available_to_write_y = data_available %>%
          dplyr::filter(Key == data_available$Key[y])
        # Create date variable in the loop
        date_y = base::substr(data_available$Key[y], 22, 31)

        # Sequence through the dp checking t see if there are any files missing
        for(r in base::seq_along(dp)){

          # Hard code, but alas!
          term_intervals = data.table::data.table(
            "term" = c("amrs", "amrs", "co2StorVali", "co2Stor", "co2Stor", "co2TurbVali", "co2Turb", "co2Turb", "h2oStor", "h2oStor",
                       "h2oTurb", "h2oTurb", "isoCo2Vali", "isoCo2", "isoCo2", "isoH2oVali", "isoH2o", "isoH2o", "presBaro", "presBaro",
                       "radiNet", "radiNet", "soni", "soni", "tempAirLvl", "tempAirLvl", "tempAirTop", "tempAirTop"),
            "interval" = c("01m", "30m", "30m", "02m", "30m", "01m", "01m", "30m", "02m", "30m", "01m",
                           "30m", "30m", "09m", "30m", "30m", "09m", "30m", "01m", "30m", "01m", "30m",
                           "01m", "30m", "01m", "30m", "01m", "30m")
          ) %>%
            dplyr::filter(term == dp[r])

          data_available_to_write_y_r_m = data.table::data.table()

          for(m in seq_along(term_intervals$interval)){
             data_available_to_write_y_r = data_available_to_write_y %>%
            # Create file_name
            dplyr::mutate(file_name_check = base::paste0("sae/", dp_level, "/data/", date_y, "/", siteid, "/", siteid, "_", date_y, "_", dp[r], "_", term_intervals$interval[m], ".RDS")) %>%
            # Check if file exists
            dplyr::mutate(does_eddy_file_already_exist = small_eddy_file_exists(object_to_check = file_name_check)) %>%
            dplyr::filter(does_eddy_file_already_exist == FALSE) %>%
            # dplyr::select(-file_name_check) %>%
            dplyr::distinct()
            # Join to blank/join table

            data_available_to_write_y_r_m = data.table::rbindlist(l = list(data_available_to_write_y_r_m, data_available_to_write_y_r))

          }

          data_available_to_write = data.table::rbindlist(l = list(data_available_to_write_y_r_m, data_available_to_write_y_r)) # This is returned when over_write == FALSE

        }

      }

    } else {

      # If over_write is set to TRUE, then it does not matter if the file exists, pull and save regardless.
      data_available_to_write = data_available %>%
        dplyr::mutate(does_eddy_file_already_exist = FALSE)
    }

    # Clear any dupes hiding out
    data_available_to_write = data_available_to_write %>% dplyr::distinct()

    # Filter to code version
    if(code_ver == "latest" & type == "expanded"){

      # TODO Code version is in the file
      start_of_code_ver = 44 + nchar(type) + 2
      end_of_code_ver = start_of_code_ver + 14

      data_available_to_write = data_available_to_write %>%
        dplyr::mutate(grab_code_ver = lubridate::ymd_hms(base::substr(x = data_available_to_write$file, start = start_of_code_ver, stop = end_of_code_ver))) %>%
        dplyr::group_by(date) %>%
        dplyr::filter(grab_code_ver == max(grab_code_ver))

    }

    # Empty table to join to
    data_all = data.table::data.table()
    # For each
    for(i in base::seq_along(data_available_to_write$Key)){
      # Specify what the file should be named when downloaded
      if(Sys.info()[1] == "Windows"){
        slashes = "\\"
      } else if(Sys.info()[1] == "Linux"){
        slashes = "/"
      } else {
        stop("System OS not recognized")
      }
      # Create zip file name for downloading
      file_name_h5_gz = base::paste0(the_temp_dir, slashes, base::substr(data_available_to_write$Key[i], 38, 1000))

      download_start = Sys.time()
      # Download the file
      if(base::file.exists(file_name_h5_gz) == FALSE){ # Check if the file has already been downloaded
        message(base::paste0(Sys.time(), ": Downloading and unzipping ", base::substr(data_available_to_write$Key[i], 38, 1000)))
        # Download the file
        utils::download.file(
          url = base::paste0("https://neon-sae-files.s3.data.neonscience.org/", data_available_to_write$Key[i]),
          destfile = file_name_h5_gz,
          quiet = TRUE
        )
      }

      # Create unzipped file name
      file_name_h5 = base::gsub(x = file_name_h5_gz, pattern = ".gz", replacement = "")
      if(base::file.exists(file_name_h5) == FALSE){ # Check if the file's already been unzipped
        # Unzip the file
        R.utils::gunzip(file_name_h5_gz)
      }

      # List all the data available in the file we downloaded
      saved_file_ls = rhdf5::h5ls(file = file_name_h5, datasetinfo = FALSE) %>%
        dplyr::select(-otype, -dclass, -dim)

      message(paste0(Sys.time(), ": Downloaded and unzipped in ", round(difftime(Sys.time(), download_start, units = "secs"), 2), " seconds"))
      r_process_start = Sys.time()
      # Loop through all the dp's input
      for(j in base::seq_along(dp)){
        # TODO if we start to care about soil sensors logic will go here, as the /000_ filters them out.
        # Look for terms we want to plot

        if(dp[j] == "co2StorVali"){

          # Specify terms for co2Vali (ecse irga)
          vali_terms = c(
            paste0("/", siteid, "/dp01/data/co2Stor/co2Arch_30m"),
            paste0("/", siteid, "/dp01/data/co2Stor/co2Arch_30m"),
            paste0("/", siteid, "/dp01/data/co2Stor/co2Low_30m"),
            paste0("/", siteid, "/dp01/data/co2Stor/co2Med_30m"),
            paste0("/", siteid, "/dp01/data/co2Stor/co2High_30m")
          )

          # Create terms_to_read
          terms_to_read = saved_file_ls %>%
            dplyr::filter(group %in% vali_terms) %>%
            tidyr::unite(col = h5_path, c(group, name), sep = "/", remove = TRUE)

        } else if(dp[j] == "co2TurbVali"){

          # Specify terms to read
          terms_to_read = saved_file_ls %>%
            dplyr::filter(name == "rtioMoleDryCo2Vali") %>%
            tidyr::unite(col = h5_path, c(group, name), sep = "/", remove = TRUE)


        } else if(dp[j] == "isoCo2Vali"){

          # Specify terms for isoCo2Vali (ecse co2 picarro)
          vali_terms = c(
            paste0("/", siteid, "/dp01/data/isoCo2/co2Arch_30m"),
            paste0("/", siteid, "/dp01/data/isoCo2/co2Low_30m"),
            paste0("/", siteid, "/dp01/data/isoCo2/co2Med_30m"),
            paste0("/", siteid, "/dp01/data/isoCo2/co2High_30m")
          )

          # Create terms_to_read
          terms_to_read = saved_file_ls %>%
            dplyr::filter(group %in% vali_terms) %>%
            tidyr::unite(col = h5_path, c(group, name), sep = "/", remove = TRUE)


        } else if(dp[j] == "isoH2oVali"){

          # Specify terms for isoCo2Vali (ecse co2 picarro)
          vali_terms = c(
            paste0("/", siteid, "/dp01/data/isoH2o/h2oLow_30m"),
            paste0("/", siteid, "/dp01/data/isoH2o/h2oMed_30m"),
            paste0("/", siteid, "/dp01/data/isoH2o/h2oHigh_30m")
          )

          # Create terms_to_read
          terms_to_read = saved_file_ls %>%
            dplyr::filter(group %in% vali_terms) %>%
            tidyr::unite(col = h5_path, c(group, name), sep = "/", remove = TRUE)

        } else if(dp[j] == "soil"){

        } else {

          # Create terms_to_read
          terms_to_read = saved_file_ls %>%
            dplyr::filter(stringr::str_detect(string = group, pattern = base::paste0(dp_level, "/", data_type, "/", dp[j], "/000_")) == TRUE) %>%
            dplyr::mutate(group = base::substr(x = group,2,1000)) %>%
            tidyr::separate(col = group, into = c("site", "dp_level", "data_type", "term", "level_timing"), sep = "/", remove = FALSE) %>% dplyr::select(group, level_timing, name) %>%
            tidyr::separate(col = level_timing, remove = TRUE, sep = "_", into = c("del", "ml", "timing")) %>% dplyr::select(group, name, timing) %>%
            tidyr::unite(col = h5_path, c(group, name), sep = "/", remove = TRUE)

        }

        # Empty table to join to
        data_out = data.table::data.table()
        for(i in base::seq_along(terms_to_read$h5_path)){
          # To find units now or later, that is the question
          # units = rhdf5::h5readAttributes(file = file_name_h5, name = terms_to_read$h5_path[i])

          if(dp[j] == "presBaro"){
            data_in = rhdf5::h5read(file = file_name_h5, name = terms_to_read$h5_path[i]) %>%
              dplyr::select(-index) %>%
              dplyr::mutate(full_path = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(timeBgn = lubridate::ymd_hms(timeBgn)) %>%
              dplyr::mutate(timeEnd = lubridate::ymd_hms(timeEnd)) %>%
              dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
              dplyr::mutate(mean    = as.numeric(mean)) %>%
              dplyr::mutate(min     = NA) %>%
              dplyr::mutate(max     = NA) %>%
              dplyr::mutate(vari    = NA) %>%
              dplyr::mutate(numSamp = NA) %>%
              dplyr::select(full_path, date, timeBgn, timeEnd, mean, min, max, vari, numSamp) %>%
              # dplyr::mutate(full_path = base::substr(full_path, 2, 1000)) %>%
              tidyr::separate(col = full_path, into = c("SiteID", "Data_Product_Level", "Data_Type", "Data_Product", "Measurement_Level", "Stream"), sep = "/", remove = TRUE) %>%
              tidyr::separate(col = Measurement_Level, sep = "_", into = c("rm", "Measurement_Level", "Averaging_Interval"), remove = TRUE) %>% dplyr::select(-rm) %>%
              dplyr::mutate(Measurement_Level = as.numeric(base::gsub(pattern = "0", replacement = "", x = Measurement_Level))) %>%
              dplyr::mutate(Data_Product = dp[j])
          } else if(dp[j] == "radiNet"){
            data_in = rhdf5::h5read(file = file_name_h5, name = terms_to_read$h5_path[i]) %>%
              dplyr::select(-index) %>%
              dplyr::mutate(full_path = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(timeBgn = lubridate::ymd_hms(timeBgn)) %>%
              dplyr::mutate(timeEnd = lubridate::ymd_hms(timeEnd)) %>%
              dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
              dplyr::mutate(mean    = as.numeric(mean)) %>%
              dplyr::mutate(min     = as.numeric(min)) %>%
              dplyr::mutate(max     = as.numeric(max)) %>%
              dplyr::mutate(vari    = as.numeric(vari)) %>%
              dplyr::mutate(numSamp = as.numeric(numSamp)) %>%
              dplyr::select(full_path, date, timeBgn, timeEnd, mean, min, max, vari, numSamp) %>%
              # dplyr::mutate(full_path = base::substr(full_path, 2, 1000)) %>%
              tidyr::separate(col = full_path, into = c("SiteID", "Data_Product_Level", "Data_Type", "Data_Product", "Measurement_Level", "Stream"), sep = "/", remove = TRUE) %>%
              tidyr::separate(col = Measurement_Level, sep = "_", into = c("rm", "Measurement_Level", "Averaging_Interval"), remove = TRUE) %>% dplyr::select(-rm) %>%
              dplyr::mutate(Measurement_Level = as.numeric(base::gsub(pattern = "0", replacement = "", x = Measurement_Level))) %>%
              dplyr::mutate(Data_Product = dp[j])

          } else if(dp[j] == "co2StorVali" | dp[j] == "isoCo2Vali" | dp[j] == "isoH2oVali"){

            data_in = rhdf5::h5read(file = file_name_h5, name = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(full_path = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(timeBgn = lubridate::ymd_hms(timeBgn)) %>%
              dplyr::mutate(timeEnd = lubridate::ymd_hms(timeEnd)) %>%
              dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
              dplyr::mutate(mean    = as.numeric(mean)) %>%
              dplyr::mutate(min     = as.numeric(min)) %>%
              dplyr::mutate(max     = as.numeric(max)) %>%
              dplyr::mutate(vari    = as.numeric(vari)) %>%
              dplyr::mutate(numSamp = as.numeric(numSamp)) %>%
              dplyr::select(full_path, date, timeBgn, timeEnd, mean, min, max, vari, numSamp) %>%
              dplyr::mutate(full_path = base::substr(full_path, 2, 1000)) %>%
              tidyr::separate(col = full_path, into = c("SiteID", "Data_Product_Level", "Data_Type", "Data_Product", "Measurement_Level", "Stream"), sep = "/", remove = TRUE) %>%
              tidyr::separate(col = Measurement_Level, sep = "_", into = c("Measurement_Level", "Averaging_Interval"), remove = TRUE) %>%
              dplyr::mutate(Data_Product = dp[j])

          } else if(dp[j] == "co2TurbVali"){

            # For ecte valis, we have a very different data set, we will save HERE instead of joining to the main data set as joining them is not very feasible
            units = rhdf5::h5readAttributes(file = file_name_h5, name = terms_to_read$h5_path[i])

            data_in = rhdf5::h5read(file = file_name_h5, name = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(full_path = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(timeBgn = lubridate::ymd_hms(timeBgn)) %>%
              dplyr::mutate(timeEnd = lubridate::ymd_hms(timeEnd)) %>%
              dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
              dplyr::mutate(mean    = as.numeric(mean)) %>%
              dplyr::mutate(min     = as.numeric(min)) %>%
              dplyr::mutate(max     = as.numeric(max)) %>%
              dplyr::mutate(vari    = as.numeric(vari)) %>%
              dplyr::mutate(numSamp = as.numeric(numSamp))

            # Earlier versions of code have to be handled differently...
            if("meanCor" %in% names(data_in)){

              data_in = data_in %>%
                dplyr::select(full_path, date, timeBgn, timeEnd, refe, meanCor, mean, min, max, vari, numSamp) %>%
                dplyr::mutate(full_path = base::substr(full_path, 2, 1000)) %>%
                tidyr::separate(col = full_path, into = c("SiteID", "Data_Product_Level", "Data_Type", "Data_Product", "Measurement_Level", "Stream"), sep = "/", remove = TRUE) %>%
                tidyr::separate(col = Measurement_Level, sep = "_", into = c("rm", "Measurement_Level", "Averaging_Interval"), remove = TRUE) %>% dplyr::select(-rm) %>%
                dplyr::mutate(Measurement_Level = as.numeric(base::gsub(pattern = "0", replacement = "", x = Measurement_Level))) %>%
                dplyr::mutate(Data_Product = dp[j]) %>%
                dplyr::filter(is.nan(numSamp) == FALSE) # This removes nan archive data

              cval_meta_list = list(c(units, data_in_rtioMoleDryCo2Refe = data_in$refe, data_in_meanCor = data_in$meanCor))

              data_in = data_in %>%
                dplyr::mutate(Averaging_Interval = cval_meta_list) %>%
                dplyr::select(-refe, -meanCor)

            } else {

              data_in = data_in %>%
                dplyr::select(full_path, date, timeBgn, timeEnd, rtioMoleDryCo2Refe, mean, min, max, vari, numSamp) %>%
                dplyr::mutate(full_path = base::substr(full_path, 2, 1000)) %>%
                tidyr::separate(col = full_path, into = c("SiteID", "Data_Product_Level", "Data_Type", "Data_Product", "Measurement_Level", "Stream"), sep = "/", remove = TRUE) %>%
                tidyr::separate(col = Measurement_Level, sep = "_", into = c("rm", "Measurement_Level", "Averaging_Interval"), remove = TRUE) %>% dplyr::select(-rm) %>%
                dplyr::mutate(Measurement_Level = as.numeric(base::gsub(pattern = "0", replacement = "", x = Measurement_Level))) %>%
                dplyr::mutate(Data_Product = dp[j]) %>%
                dplyr::filter(is.nan(numSamp) == FALSE) # This removes nan archive data

              cval_meta_list = list(c(units,data_in_rtioMoleDryCo2Refe = data_in$rtioMoleDryCo2Refe))

              data_in = data_in %>%
                dplyr::mutate(Averaging_Interval = cval_meta_list) %>%
                dplyr::select(-rtioMoleDryCo2Refe)
            }

          } else {

            # Read in the data and clean it up for our purposes
            data_in = rhdf5::h5read(file = file_name_h5, name = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(full_path = terms_to_read$h5_path[i]) %>%
              dplyr::mutate(timeBgn = lubridate::ymd_hms(timeBgn)) %>%
              dplyr::mutate(timeEnd = lubridate::ymd_hms(timeEnd)) %>%
              dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
              dplyr::mutate(mean    = as.numeric(mean)) %>%
              dplyr::mutate(min     = as.numeric(min)) %>%
              dplyr::mutate(max     = as.numeric(max)) %>%
              dplyr::mutate(vari    = as.numeric(vari)) %>%
              dplyr::mutate(numSamp = as.numeric(numSamp)) %>%
              dplyr::select(full_path, date, timeBgn, timeEnd, mean, min, max, vari, numSamp) %>%
              # dplyr::mutate(full_path = base::substr(full_path, 2, 1000)) %>%
              tidyr::separate(col = full_path, into = c("SiteID", "Data_Product_Level", "Data_Type", "Data_Product", "Measurement_Level", "Stream"), sep = "/", remove = TRUE) %>%
              tidyr::separate(col = Measurement_Level, sep = "_", into = c("rm", "Measurement_Level", "Averaging_Interval"), remove = TRUE) %>% dplyr::select(-rm) %>%
              dplyr::mutate(Measurement_Level = as.numeric(base::gsub(pattern = "0", replacement = "", x = Measurement_Level))) %>%
              dplyr::mutate(Data_Product = dp[j])
          }
          # Join together
          data_out = data.table::rbindlist(l = list(data_out, data_in)) %>%
            dplyr::distinct()
        }
        # Join all variable in # This join happens when there's more than one dp
        data_all = data.table::rbindlist(l = list(data_all, data_out))
      }

      message(paste0(Sys.time(), ": R processing took ", round(difftime(Sys.time(), r_process_start, units = "secs"), 2), " seconds"))

      # Remove files
      if(file.exists(file_name_h5)){
        base::file.remove(file_name_h5)
      }
    }
  } else {
    message(base::paste0(Sys.time(), ": no sae files found in bucket for: ", siteid, " ", paste(date_range, collapse = ", ")))
    data_all = NULL
  }

  # End timeer
  end_time = Sys.time()
  message(paste0(Sys.time(),": Total pull time: ", round(difftime(time1 = end_time, time2 = start_time, units = "secs"),2), " seconds"))

  # Return the data
  return(data_all)
}
