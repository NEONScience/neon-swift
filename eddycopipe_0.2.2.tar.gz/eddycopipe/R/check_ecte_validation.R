#' @title Check ecte validation slopes
#' @description tdb
#' @param query_date string, date of validation you'd liike to check, format: YYYY-MM-DD
#' @export
#' @examples
#'  tbd
check_ecte_validation = function(query_date = NULL, siteID = NULL, s3_creds = NULL){

  eddycopipe::remove_s3_creds()

  # Check args are proper
  if(is.null(query_date) == TRUE){
    stop("Please specify date... ie. '2021-02-09'")
  }
  if(is.null(siteID) == TRUE){
    stop("Please specify site... ie. 'CPER' ")
  }
  if(is.null(s3_creds) == TRUE){
    stop("Please s3 write creds to research-eddy-inquiry... ")
  }

  # Location to download and unzip files for reading in
  if(Sys.info()["sysname"] == "Windows" & Sys.info()["user"] == "kstyers"){
    save_dir = "C:/Users/kstyers/AppData/Local/Temp/"
  } else if(Sys.info()["sysname"] == "Linux"){
    save_dir = "/tmp/tmp_alert_data/"
    if(dir.exists(save_dir) == FALSE){
      dir.create(save_dir)
    }
  } else {
    stop("If you are using windows, you can not run this funtion. Otherwise you'll have to debug :)")
  }

  # Required Libraries
  base::library(R.utils,       warn.conflicts = FALSE, quietly = TRUE)
  base::library(utils,         warn.conflicts = FALSE, quietly = TRUE)
  base::library(aws.s3,        warn.conflicts = FALSE, quietly = TRUE)
  base::library(aws.signature, warn.conflicts = FALSE, quietly = TRUE)
  base::library(dplyr,         warn.conflicts = FALSE, quietly = TRUE)
  base::library(tidyr,         warn.conflicts = FALSE, quietly = TRUE)
  base::library(data.table,    warn.conflicts = FALSE, quietly = TRUE)
  # if (!requireNamespace("BiocManager", quietly = TRUE))
  #   install.packages("BiocManager")
  #
  # BiocManager::install("rhdf5")
  base::library(rhdf5,        warn.conflicts = FALSE, quietly = TRUE)
  base::library(lubridate,    warn.conflicts = FALSE, quietly = TRUE)

  # grab lookup for parsing domain id
  ei_s3_bucket = "research-eddy-inquiry"
  eddycopipe::add_s3_creds(bucket = ei_s3_bucket)
  lookup = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_s3_bucket)
  eddycopipe::remove_s3_creds()

  # Create domain variable
  domain_dt = lookup %>%
    dplyr::filter(SiteID == siteID)
  domain = domain_dt$Domain

  # Check for data availability given the date entered
  data_available = eddycopipe::check_sae_data_avail(query_date = query_date, data_product_level = "IP4", return_data = TRUE)

  keys_available = data_available[[2]]

  if(nrow(keys_available) > 0){
    site_data_available = keys_available %>%
      dplyr::filter(site == siteID)

    if(nrow(site_data_available) > 0){
      site_ecte_exp_available = site_data_available %>%
        dplyr::filter(file == paste0("NEON.", domain,".", siteID, ".IP4.00200.001.ecte.", query_date,".expanded.h5.gz"))

      if(nrow(site_ecte_exp_available) == 1){

        # Check if the file has already been downloaded
        file_name.h5.gz = paste0(save_dir, base::substr(site_ecte_exp_available$Key[1], 38, 100)) # Create file name
        if(base::file.exists(file_name.h5.gz) == FALSE){
          # Download expanded file to temp dir
          utils::download.file(url = paste0("https://neon-sae-files.s3.data.neonscience.org/", site_ecte_exp_available$Key[1]),
                               destfile = file_name.h5.gz, quiet = TRUE)
        }

        # Check if the file's already been unzipped
        file_name.h5 = base::gsub(x = file_name.h5.gz, pattern = ".gz", replacement = "") # Create file name
        if(base::file.exists(file_name.h5) == FALSE){
          # Unzip the file
          R.utils::gunzip(file_name.h5.gz)
        }

        # List all the data available in the file we downloaded
        saved_file.ls = rhdf5::h5ls(file = file_name.h5, datasetinfo = FALSE)

        # Filter the list of available data to just the streams we need
        vali_streams_to_save = saved_file.ls %>%
          dplyr::filter(name %in% "rtioMoleDryCo2Vali") %>%
          tidyr::unite(col = "h5_path", c("group", "name"), sep = "/")

        units = rhdf5::h5readAttributes(file = file_name.h5, name = vali_streams_to_save$h5_path[1])
        # Grab the data
        vali_in = rhdf5::h5read(file = file_name.h5, name = vali_streams_to_save$h5_path[1]) %>%
          dplyr::mutate(full_path = vali_streams_to_save$h5_path[1]) %>%
          dplyr::mutate(timeBgn = lubridate::ymd_hms(timeBgn)) %>%
          dplyr::mutate(timeEnd = lubridate::ymd_hms(timeEnd)) %>%
          dplyr::filter(is.nan(mean) == FALSE)

        # check if vali_in data is na or not
        vali_in_nrow = nrow(vali_in)
        vali_na_sum  = sum(is.na(vali_in$mean))

        # Create basic data frame for missing file
        if(vali_na_sum == 0){

          # Examine the vali_in file and output usable data
          if(nrow(vali_in) != 0){

            # Create list of all vali's if it's 1 in a day or 74, we will create asses each on inside of the list
            vali_list = list()

            # Check if there are multiple vali's potentially in the file
            vali_in_difftime = vali_in %>%
              dplyr::arrange(timeBgn) %>%
              dplyr::mutate(sample_time = as.numeric(difftime(timeBgn, lag(timeBgn), units = "secs")))
            number_of_large_time_diffs = sum(vali_in_difftime$sample_time > 30*60, na.rm = TRUE)

            # Create a dataframe of just likely validation start times
            start_times_for_valis = vali_in_difftime %>%
              dplyr::filter(sample_time > 30*60 | is.na(sample_time) == TRUE)

            # For each row (ie start) filter it out and add it to a list
            for(i in 1:nrow(start_times_for_valis)){
              # Filter to just the i'th validation in the file
              vali_mult_i = vali_in %>%
                dplyr::filter(timeBgn >= start_times_for_valis$timeBgn[i] & timeBgn < start_times_for_valis$timeBgn[i] + 30*60)
              # Add each i to a list
              vali_list[[length(vali_list) + 1]] <- vali_mult_i
            }

            # Sequence through each validation we put into vali_list
            dfVali_out = data.table::data.table()
            for(i in seq_along(vali_list)){
              # pull out the i-th dataframe
              vali_i = vali_list[[i]]

              # Determine how many rows are present
              vali_rows = nrow(vali_i)
              # Determine how many unique reference gasses there are
              uni_refes = length(unique(vali_i$refe))

              # Ideal situation; 4 rows and 4 span gas refes
              if(vali_rows == 4 & uni_refes == 4){
                vali_out = vali_i %>%
                  dplyr::mutate(status_text = "") %>%
                  dplyr::mutate(status_code = 8191)

                # Less ideal situation; there are the same number of rows as there are unique refe gases
              } else if(vali_rows == uni_refes){

                # More than 4 reference gases
                if(uni_refes > 4){
                  vali_out = vali_i %>%
                    dplyr::group_by(refe) %>%
                    dplyr::filter(timeBgn == max(timeBgn, na.rm = TRUE)) %>%
                    dplyr::mutate(status_text = paste0("Additional Cylinders! Total Cylinders in file: ", uni_refes)) %>%
                    dplyr::mutate(status_code = 1)
                }
                # Less than 4 reference gases
                if(uni_refes < 4){
                  vali_out = vali_i %>%
                    dplyr::group_by(refe) %>%
                    dplyr::filter(timeBgn == max(timeBgn, na.rm = TRUE)) %>%
                    dplyr::mutate(status_text = paste0("Missing Cylinders! Total Cylinders in file: ", uni_refes)) %>%
                    dplyr::mutate(status_code = 2)
                }

              } else if(vali_rows != uni_refes){
                # Fix all that corrects for any situations where there are more rows than cylinders
                vali_fix = vali_i %>%
                  dplyr::group_by(refe) %>%
                  dplyr::filter(timeBgn == max(timeBgn, na.rm = TRUE)) %>%
                  dplyr::mutate(status_text = paste0("Extra rows in vali file. Total rows in file: ", vali_rows)) %>%
                  dplyr::mutate(status_code = 5)

                # Now we're going to perform the same checks we did before to see how the fixing went
                ## Determine how many rows are present
                vali_rows = nrow(vali_fix)
                ## Determine how many unique reference gasses there are
                uni_refes = length(unique(vali_fix$refe))

                if(vali_rows == 4 & uni_refes == 4){
                  # Update status code and text
                  vali_out = vali_fix %>%
                    dplyr::mutate(status_text = "Extra rows in vali file, fixed") %>%
                    dplyr::mutate(status_code = 51)

                } else {
                  # Update status code and text
                  vali_out = vali_fix %>%
                    dplyr::mutate(status_text = "Missing or extra cylinders") %>%
                    dplyr::mutate(status_code = 52)
                }

              }
              # Message the new file's status
              message(paste0(Sys.time(), ": ", query_date, " ", siteID, " (",i, "/", length(vali_list),") had ", uni_refes, " unique reference gases and ", vali_rows, " rows in the file and the status code was: ", vali_out$status_code[1]))

              # Now we're ready to output files with slopes and the like!

              if(nrow(vali_out) >= 2){

                co2_streams_to_save = saved_file.ls %>%
                  dplyr::filter(stringr::str_detect(string = name, pattern = "rtioMoleDryCo2") == TRUE) %>%
                  dplyr::filter(stringr::str_detect(string = group, pattern = "_30m") == TRUE) %>%
                  dplyr::filter(stringr::str_detect(string = group, pattern = "dp01/data/co2Turb") == TRUE) %>%
                  tidyr::unite(col = "h5_path", c("group", "name"), sep = "/")

                # Pull out and join the data we need from the h5 file
                data_out = data.table::data.table()
                for(streams in 1:nrow(co2_streams_to_save)){
                  # Grab the data
                  data_in = rhdf5::h5read(file = file_name.h5, name = co2_streams_to_save$h5_path[streams]) %>%
                    dplyr::mutate(full_path = co2_streams_to_save$h5_path[streams]) %>%
                    tidyr::separate(full_path, into = c("a","b","c","d","e","f","g"), sep = "/")

                  data_in_new = data.table::data.table("stream" = data_in$g[1], "value" = mean(data_in$mean, na.rm = TRUE))

                  data_out = data.table::rbindlist(l = list(data_out, data_in_new))
                }

                qf_data_file = rhdf5::h5read(file = file_name.h5, name = paste0("/", siteID, "/dp01/qfqm/"))

                qf_data_value = sum(qf_data_file$co2Turb[[2]]$rtioMoleDryCo2$qfFinl, na.rm = TRUE)

                qf_data_out = data.table::data.table("stream" = "qfFinlRtioMoleDryCo2", "value" = qf_data_value)

                data_out = data.table::rbindlist(l = list(data_out, qf_data_out))

                # Arrange reference gas (zero, low, mid, high) theoretically this will work everytime right??
                vali_out = vali_out %>%
                  dplyr::arrange(refe)

                # Pull out zero
                vali_zero_df = vali_out %>% dplyr::filter(refe < 300)
                vali_zero = vali_zero_df$mean[1]
                vali_zero_refe = vali_zero_df$refe[1]
                vali_zero_corr = vali_zero_df$meanCor[1]
                # Pull out low
                vali_low_df = vali_out %>% dplyr::filter(refe > 300 & refe < 400)
                vali_low = vali_low_df$mean[1]
                vali_low_refe = vali_low_df$refe[1]
                vali_low_corr = vali_low_df$meanCor[1]
                # Pull out mid
                vali_mid_df = vali_out %>% dplyr::filter(refe > 400 & refe < 500)
                vali_mid = vali_mid_df$mean[1]
                vali_mid_refe = vali_mid_df$refe[1]
                vali_mid_corr = vali_mid_df$meanCor[1]
                # Pull out high
                vali_high_df = vali_out %>% dplyr::filter(refe > 500)
                vali_high = vali_high_df$mean[1]
                vali_high_refe = vali_high_df$refe[1]
                vali_high_corr = vali_high_df$meanCor[1]

                # Create output dataframe
                dfVali <- data.frame(
                  Date         = query_date,
                  SiteID       = siteID,
                  status_text  = vali_out$status_text[1],
                  status_code  = vali_out$status_code[1],
                  timeBgn      = vali_out$timeBgn[1],
                  timeEnd      = vali_out$timeEnd[4],
                  valiOfst     = units$valiCoef[1],
                  valiSlp      = units$valiCoef[2],
                  valiOfstSe   = units$valiCoefSe[1],
                  valiSlpeSe   = units$valiCoefSe[2],
                  valiScal     = units$valiScal[1],
                  valiMeanArch = NA,
                  valiMeanZero = vali_zero,
                  valiMeanLow  = vali_low,
                  valiMeanMid  = vali_mid,
                  valiMeanHigh = vali_high,
                  valiRefeArch = NA,
                  valiRefeZero = vali_zero_refe,
                  valiRefeLow  = vali_low_refe,
                  valiRefeMid  = vali_mid_refe,
                  valiRefeHigh = vali_high_refe,
                  valiMeanZeroCorr = vali_zero_corr,
                  valiMeanLowCorr = vali_low_corr,
                  valiMeanMidCorr = vali_mid_corr,
                  valiMeanHighCorr = vali_high_corr,
                  rtioMoleDryCo2 = data_out$value[1],
                  rtioMoleDryCo2Cor = data_out$value[2],
                  rtioMoleDryCo2Raw  = data_out$value[3],
                  qfFinlRtioMoleDryCo2 = data_out$value[4]
                )
                # We used to have to calculate by hand, but a new version of the code means we no longer have to
                #   also, these would give different values than the values provided
                # ) %>%
                #   dplyr::mutate(valiMeanZeroCorr  = (valiMeanZero * valiSlp) + valiOfst) %>%
                #   dplyr::mutate(valiMeanLowCorr   = (valiMeanLow  * valiSlp) + valiOfst) %>%
                #   dplyr::mutate(valiMeanMidCorr   = (valiMeanMid  * valiSlp) + valiOfst) %>%
                #   dplyr::mutate(valiMeanHighCorr  = (valiMeanHigh * valiSlp) + valiOfst)


                # Create table for calculating the stats::lm()
                dfValiThrsh = data.table::data.table(
                  "corr" = c(
                    dfVali$valiMeanZeroCorr[1],
                    dfVali$valiMeanLowCorr[1],
                    dfVali$valiMeanMidCorr[1],
                    dfVali$valiMeanHighCorr[1]
                  ),
                  "refe" = c(
                    dfVali$valiRefeZero[1],
                    dfVali$valiRefeLow[1],
                    dfVali$valiRefeMid[1],
                    dfVali$valiRefeHigh[1]
                  )
                )

                # Check if the values were able to be corrected $ This will not catch every case...
                dfValiThrsh_na = sum(is.na(dfValiThrsh$corr))
                dfValiThrsh_row = nrow(dfValiThrsh)
                if(dfValiThrsh_na != dfValiThrsh_row){

                  # Calculate the slope
                  dfValiCorr_lm = stats::lm(dfValiThrsh$corr ~ dfValiThrsh$refe)
                  # Extrate the slope from the previous dataframe
                  slope = dfValiCorr_lm$coefficients[2]
                  intercept = dfValiCorr_lm$coefficients[1]

                  # Slope must be within 5% of 1.0
                  thresholds = 0.05

                  # Check Slope
                  dfVali = dfVali %>%
                    dplyr::mutate(calcSlope = slope) %>%
                    dplyr::mutate(calcIntercept = intercept) %>%
                    dplyr::mutate(thrshSlope = abs(1 - slope)) %>%
                    dplyr::mutate(thrshPass = ifelse(test = thrshSlope > thresholds & abs(calcIntercept) > 100, yes = FALSE, no = TRUE))

                } else {
                  dfVali <- data.frame(
                    Date                 = query_date,
                    SiteID               = siteID,
                    status_text          = "Too many NA reference gases to analyze: 3. Check cylinder's installed in Maximo",
                    status_code          = "96",
                    timeBgn              = as.POSIXct(x = "1970-01-01 00:00:00"),
                    timeEnd              = as.POSIXct(x = "1970-01-01 00:00:00"),
                    valiOfst             = NA,
                    valiSlp              = NA,
                    valiOfstSe           = NA,
                    valiSlpeSe           = NA,
                    valiScal             = NA,
                    valiMeanArch         = NA,
                    valiMeanZero         = NA,
                    valiMeanLow          = NA,
                    valiMeanMid          = NA,
                    valiMeanHigh         = NA,
                    valiRefeArch         = NA,
                    valiRefeZero         = NA,
                    valiRefeLow          = NA,
                    valiRefeMid          = NA,
                    valiRefeHigh         = NA,
                    rtioMoleDryCo2       = NA,
                    rtioMoleDryCo2Cor    = NA,
                    rtioMoleDryCo2Raw    = NA,
                    qfFinlRtioMoleDryCo2 = NA,
                    valiMeanZeroCorr     = NA,
                    valiMeanLowCorr      = NA,
                    valiMeanMidCorr      = NA,
                    valiMeanHighCorr     = NA,
                    calcSlope            = NA,
                    calcIntercept        = NA,
                    thrshSlope           = NA,
                    thrshPass            = NA
                  )
                }
              } else {
                if(nrow(vali_out) == 1){
                  dfVali <- data.frame(
                    Date                 = query_date,
                    SiteID               = siteID,
                    status_text          = "Too few reference gases to analyze: 1",
                    status_code          = "95",
                    timeBgn              = as.POSIXct(x = "1970-01-01 00:00:00"),
                    timeEnd              = as.POSIXct(x = "1970-01-01 00:00:00"),
                    valiOfst             = NA,
                    valiSlp              = NA,
                    valiOfstSe           = NA,
                    valiSlpeSe           = NA,
                    valiScal             = NA,
                    valiMeanArch         = NA,
                    valiMeanZero         = NA,
                    valiMeanLow          = NA,
                    valiMeanMid          = NA,
                    valiMeanHigh         = NA,
                    valiRefeArch         = NA,
                    valiRefeZero         = NA,
                    valiRefeLow          = NA,
                    valiRefeMid          = NA,
                    valiRefeHigh         = NA,
                    rtioMoleDryCo2       = NA,
                    rtioMoleDryCo2Cor    = NA,
                    rtioMoleDryCo2Raw    = NA,
                    qfFinlRtioMoleDryCo2 = NA,
                    valiMeanZeroCorr     = NA,
                    valiMeanLowCorr      = NA,
                    valiMeanMidCorr      = NA,
                    valiMeanHighCorr     = NA,
                    calcSlope            = NA,
                    calcIntercept        = NA,
                    thrshSlope           = NA,
                    thrshPass            = NA
                  )

                } else {
                  browser()
                }

              }

              dfVali_out = data.table::rbindlist(l = list(dfVali_out, dfVali))

            }

            # Delete zip and  unzipped files
            base::file.remove(file_name.h5)
            # Return final vali output file
            return(dfVali_out)

          } else {
            message(paste0(Sys.time(), ": ", query_date, " ", siteID, " (0/0) had 0 unique reference gases and 0 rows in the file and the status code was: 91"))
            base::file.remove(file_name.h5)
            rhdf5::h5closeAll()
            dfVali <- data.frame(
              Date                 = query_date,
              SiteID               = siteID,
              status_text          = "Validation file was empty",
              status_code          = "91",
              timeBgn              = as.POSIXct(x = "1970-01-01 00:00:00"),
              timeEnd              = as.POSIXct(x = "1970-01-01 00:00:00"),
              valiOfst             = NA,
              valiSlp              = NA,
              valiOfstSe           = NA,
              valiSlpeSe           = NA,
              valiScal             = NA,
              valiMeanArch         = NA,
              valiMeanZero         = NA,
              valiMeanLow          = NA,
              valiMeanMid          = NA,
              valiMeanHigh         = NA,
              valiRefeArch         = NA,
              valiRefeZero         = NA,
              valiRefeLow          = NA,
              valiRefeMid          = NA,
              valiRefeHigh         = NA,
              rtioMoleDryCo2       = NA,
              rtioMoleDryCo2Cor    = NA,
              rtioMoleDryCo2Raw    = NA,
              qfFinlRtioMoleDryCo2 = NA,
              valiMeanZeroCorr     = NA,
              valiMeanLowCorr      = NA,
              valiMeanMidCorr      = NA,
              valiMeanHighCorr     = NA,
              calcSlope            = NA,
              calcIntercept        = NA,
              thrshSlope           = NA,
              thrshPass            = NA
            )
            return(dfVali)
          }

        } else {
          message(paste0(Sys.time(), ": ", query_date, " ", siteID, " (0/0) had 0 unique reference gases and 0 rows in the file and the status code was: 92"))
          base::file.remove(file_name.h5)
          rhdf5::h5closeAll()
          dfVali <- data.frame(
            Date                 = query_date,
            SiteID               = siteID,
            status_text          = "Validation file was all NA",
            status_code          = "92",
            timeBgn              = as.POSIXct(x = "1970-01-01 00:00:00"),
            timeEnd              = as.POSIXct(x = "1970-01-01 00:00:00"),
            valiOfst             = NA,
            valiSlp              = NA,
            valiOfstSe           = NA,
            valiSlpeSe           = NA,
            valiScal             = NA,
            valiMeanArch         = NA,
            valiMeanZero         = NA,
            valiMeanLow          = NA,
            valiMeanMid          = NA,
            valiMeanHigh         = NA,
            valiRefeArch         = NA,
            valiRefeZero         = NA,
            valiRefeLow          = NA,
            valiRefeMid          = NA,
            valiRefeHigh         = NA,
            rtioMoleDryCo2       = NA,
            rtioMoleDryCo2Cor    = NA,
            rtioMoleDryCo2Raw    = NA,
            qfFinlRtioMoleDryCo2 = NA,
            valiMeanZeroCorr     = NA,
            valiMeanLowCorr      = NA,
            valiMeanMidCorr      = NA,
            valiMeanHighCorr     = NA,
            calcSlope            = NA,
            calcIntercept        = NA,
            thrshSlope           = NA,
            thrshPass            = NA
          )
          return(dfVali)
        }

      } else {
        message(paste0(Sys.time(), ": ", query_date, " ", siteID, " (0/0) had 0 unique reference gases and 0 rows in the file and the status code was: 93"))
        dfVali <- data.frame(
          Date                 = query_date,
          SiteID               = siteID,
          status_text          = "Expanded ecte files were not found",
          status_code          = "93",
          timeBgn              = as.POSIXct(x = "1970-01-01 00:00:00"),
          timeEnd              = as.POSIXct(x = "1970-01-01 00:00:00"),
          valiOfst             = NA,
          valiSlp              = NA,
          valiOfstSe           = NA,
          valiSlpeSe           = NA,
          valiScal             = NA,
          valiMeanArch         = NA,
          valiMeanZero         = NA,
          valiMeanLow          = NA,
          valiMeanMid          = NA,
          valiMeanHigh         = NA,
          valiRefeArch         = NA,
          valiRefeZero         = NA,
          valiRefeLow          = NA,
          valiRefeMid          = NA,
          valiRefeHigh         = NA,
          rtioMoleDryCo2       = NA,
          rtioMoleDryCo2Cor    = NA,
          rtioMoleDryCo2Raw    = NA,
          qfFinlRtioMoleDryCo2 = NA,
          valiMeanZeroCorr     = NA,
          valiMeanLowCorr      = NA,
          valiMeanMidCorr      = NA,
          valiMeanHighCorr     = NA,
          calcSlope            = NA,
          calcIntercept        = NA,
          thrshSlope           = NA,
          thrshPass            = NA
        )
        return(dfVali)
      }
    } else {
      message(paste0(Sys.time(), ": ", query_date, " ", siteID, " (0/0) had 0 unique reference gases and 0 rows in the file and the status code was: 94"))
      dfVali <- data.frame(
        Date                 = query_date,
        SiteID               = siteID,
        status_text          = "No data found at all",
        status_code          = "94",
        timeBgn              = as.POSIXct(x = "1970-01-01 00:00:00"),
        timeEnd              = as.POSIXct(x = "1970-01-01 00:00:00"),
        valiOfst             = NA,
        valiSlp              = NA,
        valiOfstSe           = NA,
        valiSlpeSe           = NA,
        valiScal             = NA,
        valiMeanArch         = NA,
        valiMeanZero         = NA,
        valiMeanLow          = NA,
        valiMeanMid          = NA,
        valiMeanHigh         = NA,
        valiRefeArch         = NA,
        valiRefeZero         = NA,
        valiRefeLow          = NA,
        valiRefeMid          = NA,
        valiRefeHigh         = NA,
        rtioMoleDryCo2       = NA,
        rtioMoleDryCo2Cor    = NA,
        rtioMoleDryCo2Raw    = NA,
        qfFinlRtioMoleDryCo2 = NA,
        valiMeanZeroCorr     = NA,
        valiMeanLowCorr      = NA,
        valiMeanMidCorr      = NA,
        valiMeanHighCorr     = NA,
        calcSlope            = NA,
        calcIntercept        = NA,
        thrshSlope           = NA,
        thrshPass            = NA
      )
      return(dfVali)
    }
  } else {
    message(Sys.time(), ": data was not found for any site!!!")
    return(data.table::data.table())
  }

  # Just in case there's any extra file lingering
  # Let's delete them

  file_left_over = base::list.files(path = "/tmp/tmp_alert_data/", full.names = TRUE)

  if(length(file_left_over) > 0){
    for(i in 1:seq_along(file_left_over)){
      base::file.remove(file_left_over[i])
    }

  }


}
