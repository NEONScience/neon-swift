##############################################################################################
#' @title GCS - Parse `.RDS` files from the cloud
#'
#' @author Kevin Styers
#' @description This function is passed to the googleCloudStorageR::gcs_get_object argument `parseFunction` and assists in parsing `.RDS` files saved in the cloud.
#'
#' @return NA
#'
#' @examples
#' # Upload some data as a `.fst` files
#' cloud_object <- googleCloudStorageR::gcs_get_object(object_name = "mtcars.RDS", bucket = "neon-eddy-inquiry", parseFunction = gcs_parse_rds)
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-22)
#     original creation
##############################################################################################
neon_gcs_parse_rds = function(object){
  # Required libraries
  library(httr)
  library(fst)
  # Establish connection to object
  con <- base::gzcon(base::rawConnection(httr::content(object)))
  # On function exit, close connection
  base::on.exit(base::close(con))
  # Read in the file
  readRDS(con)
}
