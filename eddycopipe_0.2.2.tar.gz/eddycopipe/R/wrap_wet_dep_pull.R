#' @title Wrapper to pull all wet dep prt data
#' @description  This function pairs with pull_wet_dep.R to pull data from Presto and save it to S3, not the most beautiful :/
#' @param presto_creds Character string; your preso credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' wrap_wet_dep_pull(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
wrap_wet_dep_pull = function(presto_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify pull_date: Sys.Date()-1")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)
  library(here)

  ei_bucket = "neon-eddy-inquiry"
  # wet dep sites
  sites = eddycopipe::neon_gcs_get_rds(object = "lookup/wet_dep_sites.RDS", bucket = ei_bucket)


  pull_min_ec_data = function(i, start, stop){

    # Get L0 matrix for site
    site_streams = compose_L0_matrix(
      site = i
    )

    # Sensor Names, This list is used to limit streams to only DPID's I have named in this SensorNames Lookup table
    sensorNameStreams =  eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket)

    # Filter Data to just essential EC Streams
    ecList    = c(
      "DP0.00013.001.01818", # Wet Dep PRT
      "DP0.00002.001.01325"  # Asperated air temp
    )

    # Limit Streams by EC related streams
    streams = site_streams %>%
      dplyr::filter(DPcrispy %in% ecList) %>%
      dplyr::distinct() %>%
      dplyr::mutate(horVer = as.numeric(base::substr(x = DPJoin, start = 25, stop = 27))) %>%
      dplyr::filter(horVer >= max(horVer - 10, na.rm = TRUE))  # filter to just the next top level and the wet dep or just the met station

    streams = base::as.vector(streams$streams)
    try(
      pull_wet_dep(
        idDp        = streams,
        dateBgn     = start,
        dateEnd     = stop,
        CredPsto    = presto_creds,
        everyMinute = 2,
        compression = 100
      )
    )
  }

  time_data <- base::system.time(
    for(i in sites){
      start1 <- Sys.time()
      base::try(
        pull_min_ec_data(i = i, start = pull_date, stop = pull_date + 1)
      )
      message(paste0(Sys.time(), ": 100%: Completed Pull"))
      end1 <- Sys.time()
      message(paste0(Sys.time(), ": ", i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
    }
  )
  message(paste0(Sys.time(), ": Completed Wet Dep Temp pull in: ", round(time_data[3]/60,1), " minutes"))
}
