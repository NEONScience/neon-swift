#' @title Check ecte validation slopes
#' @description tdb
#' @param query_date string, date of validation you'd liike to check, format: YYYY-MM-DD
#' @export
#' @examples
#'  tbd
check_li7200_valis = function(query_date = NULL, siteID = NULL){
  Sys.unsetenv("AWS_SECRET_ACCESS_KEY")
  Sys.unsetenv("AWS_S3_ENDPOINT")
  Sys.unsetenv("AWS_DEFAULT_REGION")
  # Check args are proper
  if(is.null(query_date) == TRUE){
    stop("Please specify date... ie. '2021-02-09'")
  }
  if(is.null(siteID) == TRUE){
    stop("Please specify site... ie. 'CPER' ")
  }

  # Required Libraries
  base::library(aws.s3)
  base::library(aws.signature)
  base::library(dplyr)
  base::library(data.table)
  base::library(rhdf5)

  # S3 Connection
  Sys.setenv("AWS_ACCESS_KEY_ID"     = "research-eddy-inquiry",
             "AWS_S3_ENDPOINT"       = "neonscience.org",
             "AWS_DEFAULT_REGION"    = "s3.data")

  # Determine domain from siteID
  site_metadata = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = "research-eddy-inquiry")

  domain_dt = site_metadata %>%
    dplyr::filter(SiteID == siteID)
  domain = domain_dt$Domain

  # Location to download and unzip files for reading in
  if(Sys.info()["sysname"] == "Windows" & Sys.info()["user"] == "kstyers"){
    save_dir = "C:/Users/kstyers/AppData/Local/Temp/"
  } else if(Sys.info()["sysname"] == "Linux"){
    save_dir = "/tmp/"
  } else {
    stop("If you are using windows, you can not run this funtion. Otherwise you'll have to debug :)")
  }

  # Check for data availability given the date entered
  base::source(here::here("R/check_sae_data_avail.R"))
  data_available = check_sae_data_avail(query_date = query_date, data_product_level = "IP4", return_data = TRUE)

  keys_available = data_available[[2]]

  if(nrow(keys_available) > 0){
    site_data_available = keys_available %>%
      dplyr::filter(site == siteID)

    if(nrow(site_data_available) > 0){
      site_ecte_exp_available = site_data_available %>%
        dplyr::filter(file == paste0("NEON.", domain,".", siteID, ".IP4.00200.001.ecte.", query_date,".expanded.h5.gz"))

      if(nrow(site_ecte_exp_available) == 1){
        # Check if the file has already been downloaded
        file_name.h5.gz = paste0(save_dir, base::substr(site_ecte_exp_available$Key[1], 38, 100)) # Create file name
        if(base::file.exists(file_name.h5.gz) == FALSE){
          # Download expanded file to temp dir
          utils::download.file(url = paste0("https://neon-sae-files.s3.data.neonscience.org/", site_ecte_exp_available$Key[1]), destfile = file_name.h5.gz)
        }

        # Check if the file's already been unzipped
        file_name.h5 = base::gsub(x = file_name.h5.gz, pattern = ".gz", replacement = "") # Create file name
        if(base::file.exists(file_name.h5) == FALSE){
          # Unzip the file
          R.utils::gunzip(file_name.h5.gz)
        }


        # rhdf5::h5read(file = file_name.h5, name = paste0("/HQTW/dp01/data/co2Turb/000_040_",interval,"m/", stream, "Atm"))
        # t = rhdf5::h5read(file = file_name.h5, name = paste0("/CPER/dp01/data/co2Turb/000_040_01m/rtioMoleDryCo2Vali/"))
        # t = rhdf5::h5read(file = file_name.h5, name = paste0("/CPER/dp01/data/co2Turb/000_040_01m/frt00Samp/"))
        # t = rhdf5::h5read(file = file_name.h5, name = paste0("/CPER/dp0p/data/mfcValiTurb/000_040/"))



        # browser()




      } else {
        message(paste0(siteID, "'s expanded ecte files not found"))
      }
    } else {
      message(paste0(siteID, "'s did not return any data"))
    }
  } else {
    message("Data was not found for any site!!!")
  }
  Sys.unsetenv("AWS_SECRET_ACCESS_KEY")
  Sys.unsetenv("AWS_S3_ENDPOINT")
  Sys.unsetenv("AWS_DEFAULT_REGION")
}

