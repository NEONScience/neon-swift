#' @title Clean Span Gas data
#' @description WARNING this is not pretty
#' @export
#' @examples
#' clean_span_gas_data()
clean_span_gas_data = function(){
  library(dplyr)
  library(data.table)
  library(fst)

  ei_bucket = "neon-eddy-inquiry"

  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")


  eddyco.blankdata = data.table::data.table()
  message(paste0(Sys.time(), ": Reading the pressure data"))
  for(i in siteList$SiteID){

    gasSiteList <- list.files("~/eddyInquiry/data/spanGas/", pattern = i, full.names = TRUE)
    if(length(gasSiteList) > 0){
          gasSiteIngest <- lapply(gasSiteList, read.fst)

    gasSiteData <- data.table::rbindlist(gasSiteIngest)


    # Look up table of DPIDs and real name
    sensorNameStreams <-  utils::read.csv("~/eddyInquiry/data/lookup/SensorNames.csv",stringsAsFactors = FALSE)
    gasSiteData$DPID <- base::substr(gasSiteData$meas_strm_name,15,45)
    gasSiteDataNamed <- dplyr::left_join(x = gasSiteData, y = sensorNameStreams, by = "DPID") %>%
      dplyr::select(SiteID,FinalTime,strm_name,minVal, meanVal, maxVal, stDevVal) %>% # Keep and clean the columns we need
      dplyr::mutate(minVal = minVal/6.895) %>%
      dplyr::mutate(meanVal = meanVal/6.895) %>%
      dplyr::mutate(maxVal = maxVal/6.895) %>%
      dplyr::mutate(stDevVal = stDevVal/6.895) %>%
      dplyr::mutate(FinalTime = as.Date(FinalTime, format = "%Y-%m-%d"))

    eddyco.blankdata = data.table::rbindlist(l = list(eddyco.blankdata, gasSiteDataNamed))

    }


  }

  message(paste0(Sys.time(), ": Cleaning the pressure data"))
  ## We need to match  up each sites cylinder to their asset tags for each date.. We will use the Cylinder conc data that has the asset tag data. create a uid, join etc...
  span.pressure.values = eddyco.blankdata %>%
    dplyr::mutate(Cylinder = strm_name) %>%
    dplyr::mutate(date = as.Date(FinalTime, format="%Y-%m-%d")) %>%
    dplyr::mutate(ecType = ifelse(test = stringr::str_detect(string = strm_name, pattern ="ECTE") == TRUE,
                                  yes = "Turb", no = "Stor")) %>%
    dplyr::mutate(cylType = ifelse(test = stringr::str_detect(string = strm_name, pattern ="Delivery") == FALSE,
                                   yes = "Overall Pressure", no = "Delivery Pressure")) %>%
    dplyr::select(SiteID, date, Cylinder, cylType, ecType, meanVal) %>%
    # we don't care about d pressure for this calculation
    dplyr::filter(cylType == "Overall Pressure") %>%
    dplyr::mutate(suid = paste0(date, "_", SiteID, "_", Cylinder))


  message(paste0(Sys.time(), ": Reading the conc data"))
  span.conc.values = eddycopipe::neon_gcs_get_fst(object = "lookup/spanGasConc.fst", bucket = "research-eddy-inquiry") %>%
    # We have to change the dangum names here D:
    dplyr::rowwise() %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECSE-Archive") == TRUE, yes = "ECSE Archive", no = NA)) %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECSE-HIGH") == TRUE, yes = "ECSE High", no = Cylinder)) %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECSE-LOW") == TRUE, yes = "ECSE Low", no = Cylinder)) %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECSE-MEDIUM") == TRUE, yes = "ECSE Int", no = Cylinder)) %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECTE-Archive") == TRUE, yes = "ECTE Archive", no = Cylinder)) %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECTE-HIGH") == TRUE, yes = "ECTE High", no = Cylinder)) %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECTE-LOW") == TRUE, yes = "ECTE Low", no = Cylinder)) %>%
    dplyr::mutate(Cylinder = ifelse(test = stringr::str_detect(string = name, pattern = "ECTE-MEDIUM") == TRUE, yes = "ECTE Int", no = Cylinder))

  message(paste0(Sys.time(), ": Cleaning the conc data"))
  span.asset.lookup = span.conc.values %>%
    dplyr::filter(date > "2019-01-08") %>%
    dplyr::mutate(suid = paste0(date, "_", siteID, "_", Cylinder)) %>%
    dplyr::select(suid, assetTag)

  message(paste0(Sys.time(), ": Merging the pressure and conc data"))
  span.pressure.assetTag = dplyr::left_join(x = span.pressure.values, y = span.asset.lookup, by = "suid") %>%
    dplyr::filter(cylType == "Overall Pressure") %>%
    dplyr::group_by(SiteID, Cylinder, assetTag) %>%
    dplyr::filter(meanVal < 3000 & meanVal > 0) %>%
    dplyr::mutate(meanDifferential = meanVal - lag(meanVal)) %>%
    dplyr::filter(is.na(assetTag) == FALSE) %>%
    dplyr::filter(is.na(meanDifferential) == FALSE)



  # Read in metadata
  sensorNameStreams <-  utils::read.csv("~/eddyInquiry/data/lookup/SensorNames.csv",stringsAsFactors = FALSE)
  # Combine all files
  all.gas.sites.data <- eddyco.blankdata %>%
    dplyr::mutate(Cylinder = strm_name) %>%
    dplyr::mutate(date = as.Date(FinalTime, format="%Y-%m-%d")) %>%
    dplyr::mutate(ecType = ifelse(test = stringr::str_detect(string = strm_name, pattern ="ECTE") == TRUE,
                                  yes = "Turb", no = "Stor")) %>%
    dplyr::mutate(cylType = ifelse(test = stringr::str_detect(string = strm_name, pattern ="Delivery") == FALSE,
                                   yes = "Overall Pressure", no = "Delivery Pressure")) %>%
    dplyr::select(SiteID, date, Cylinder, cylType, ecType, meanVal)

  options(scipen = 999) # Loss the Sci Notation

  message(paste0(Sys.time(), ": Saving data"))

  eddycopipe::wrap_neon_gcs_upload(x = all.gas.sites.data, bucket = ei_bucket, object = "spanGas/master/swft.span.gas.master.fst")
  eddycopipe::wrap_neon_gcs_upload(x = span.pressure.assetTag, bucket = ei_bucket, object = "spanGas/master/swft.span.gas.differntial.master.fst")

  SiteMetaData <- data.table::fread(here::here("data/lookup/flowRateLookup.csv")) %>%
    dplyr::select(dom, SiteID)
  names(SiteMetaData) <- c("DomainID","SiteID")

  totSpan <- all.gas.sites.data %>%
    dplyr::filter(stringr::str_detect(Cylinder, pattern = "Delivery") == FALSE)
  totSpanSorted <- totSpan[order(totSpan$SiteID, totSpan$Cylinder, totSpan$date),]

  avgLossTable <- totSpanSorted %>%
    dplyr::group_by(SiteID, Cylinder) %>%
    dplyr::filter(meanVal < 3000 & meanVal > -2) %>%
    dplyr::mutate(dailyDifferential = round(meanVal - lag(meanVal),2)) %>%
    dplyr::mutate(Average_Pressure_Loss = sum(dailyDifferential,na.rm = TRUE)/(as.numeric(difftime(max(date,na.rm = TRUE),min(date, na.rm = TRUE))))) %>% # create avg pressure loss from the mean of the differential
    dplyr::filter(date == max(date)) %>%                                            # give the Max date for plot
    dplyr::mutate(daysToEmpty = round(meanVal/abs(Average_Pressure_Loss),2)) %>%
    dplyr::mutate(daysToEmptyFullCylinder = round(1400/abs(Average_Pressure_Loss),2))%>%
    dplyr::mutate(daysTo150PSI = round((meanVal-150)/(abs(Average_Pressure_Loss)),2)) %>%
    dplyr::mutate(daysTo400PSI = round((meanVal-400)/(abs(Average_Pressure_Loss)),2)) %>%
    dplyr::select(SiteID,date,Cylinder,meanVal,Average_Pressure_Loss,daysTo150PSI,daysTo400PSI,daysToEmpty)

  avgLossTable <- dplyr::left_join(avgLossTable,SiteMetaData, by = "SiteID")  %>%
    dplyr::select(DomainID,SiteID,date,Cylinder,meanVal,Average_Pressure_Loss,daysTo150PSI,daysTo400PSI,daysToEmpty)

  avgLossTable$Cylinder <- as.factor(avgLossTable$Cylinder)

  covidData <- avgLossTable %>%
    dplyr::filter(daysTo400PSI > -5 &
                  daysTo400PSI < 100)

  names(avgLossTable) <- c("Domain ID","Site ID","Date","Cylinder Name","Current Pressure","Average Pressure Loss (14 Days)","Days Until Cylinder @ 150PSI","Days Until Cylinder @ 400PSI","Days Until Cylinder Empty")


}
