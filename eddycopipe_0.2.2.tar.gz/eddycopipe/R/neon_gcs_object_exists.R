##############################################################################################
#' @title GCS - Check if object exists
#'
#' @author Kevin Styers
#' @description This function uses googleCloudStorageR::gcs_list_objects with the prefix set to the object name
#'
#' @param bucket the name of the bucket
#' @param object_name the name of the object (or the path) in the cloud to read
#'
#' @return the .fst table in the cloud
#'
#' @examples
#' gcs_get_fst(object_name = "mtcars.fst")
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-22)
#     original creation
##############################################################################################
neon_gcs_object_exists = function(object_name = NULL, bucket = NULL){

  if(is.null(object_name) | is.null(bucket)){
    stop("Please specify both object_name and bucket")
  }

  object_exists = nrow(googleCloudStorageR::gcs_list_objects(bucket = bucket, prefix = object_name)) == 1

  return(object_exists)

}
