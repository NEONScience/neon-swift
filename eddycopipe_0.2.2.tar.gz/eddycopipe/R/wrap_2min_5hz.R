#' @title Wrapper to pull all 5hz 2min eddyInquiry Data
#' @description  This function pairs with pull_2min_5hz.R to pull data from Presto and save it to S3, not the most beautiful :/
#' @param presto_creds Character string; your preso credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' wrap_2min_5hz(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
wrap_2min_5hz = function(presto_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify s3_creds: 'Sys.Date()-1'")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)
  library(here)

  ei_bucket = "neon-eddy-inquiry"

  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
      dplyr::filter(Type == "TIS")

  pull_min_ec_li840_valves <- function(i, start, stop){

    site_streams = compose_L0_matrix(
      site = i
    )

    # Sensor Names, This list is used to limit streams to only DPID's I have named in this SensorNames Lookup table
    sensorNameStreams <- eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket) %>%
      dplyr::mutate(DPID = base::trimws(DPID, which = "both"))


    # Filter Data to just essential EC Streams
    ecList = c(
      "DP0.00113.001.02360.701.000.000", # VALVES 1 Could be Li840/G2131/L2130/validation 1/0
      "DP0.00113.001.02361.701.000.000", # VALVES 2 Could be Li840/G2131/L2130/validation 1/0
      "DP0.00113.001.02362.701.000.000", # VALVES 3 Could be Li840/G2131/L2130/validation 1/0
      "DP0.00113.001.02364.701.000.000", # VALVES 4 Could be Li840/G2131/L2130/validation 1/0
      "DP0.00113.001.02365.701.000.000", # VALVES 5 Could be Li840/G2131/L2130/validation 1/0
      "DP0.00113.001.02366.701.000.000", # VALVES 6 Could be Li840/G2131/L2130/validation 1/0
      "DP0.00113.001.02367.701.000.000", # VALVES 7 Could be Li840/G2131/L2130/validation 1/0
      "DP0.00113.001.02368.701.000.000"  # VALVES 8 Could be Li840/G2131/L2130/validation 1/0
    )
    ecte.valve.list <- c(
      "DP0.00011.001.02212", # ECTE hut qfGas 1
      "DP0.00011.001.02213", # ECTE hut qfGas 2
      "DP0.00011.001.02214", # ECTE hut qfGas 3
      "DP0.00011.001.02215", # ECTE hut qfGas 4
      "DP0.00011.001.02216", # ECTE hut qfGas 5
      "DP0.00009.001.02212", # ECTE encl qfGas 1
      "DP0.00009.001.02213", # ECTE encl qfGas 2
      "DP0.00009.001.02214", # ECTE encl qfGas 3
      "DP0.00009.001.02215", # ECTE encl qfGas 4
      "DP0.00009.001.02216"  # ECTE encl qfGas 5
    )

    # Limit Streams by EC related streams
    streams <- site_streams %>%
      dplyr::filter(DPJoin %in% ecList | DPcrispy %in% "DP0.00112.001.02351" | DPcrispy %in% ecte.valve.list) %>% # All Pump Voltages
      dplyr::distinct()

    streams <- base::as.vector(streams$streams)
    pull_2min_5hz(
      idDp = streams,
      dateBgn = start,
      dateEnd = stop,
      CredPsto = presto_creds,
      sensor_names = sensorNameStreams,
      everyMinute = 2,
      compression = 100
    )
  }

  start <- Sys.time()

  for(i in siteList$SiteID){
    start1 <- Sys.time()
    base::try(
      pull_min_ec_li840_valves(
        i     = i,
        start = pull_date,
        stop  = pull_date + 1
      )
    )
    message(paste0(Sys.time(), ": 100%: Completed Pull"))
    end1 <- Sys.time()
    message(paste0(Sys.time(), ": ", i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
  }
  end <- Sys.time()

  message(paste0(Sys.time(), ": Completed 2min 5hz pull in: ", round(difftime(end, start, units = "min"), 2), " minutes"))
}
