#' @title Save eddy files from pull_eddy_data.R
#' @author Kevin Styers `kstyers@battelleecology.org`
#' @description This function parses the provided data.table into site-sensor-timing specific files and saves them up to s3. This does require write creds to the s3 bucket.
#' @param data_to_save data.table; a data.table output from pull_eddy_data.R in the proper format
#' @param write_creds character; the secret writing key to the s3 bucket research-eddy-inquiry
#' @return Returns nothing, but does message out what files it save and at what time they were saved
#' @export
#' @examples
#'  eddycopipe::save_small_eddy_s3(data_to_save = data_in, write_creds = readRDS("/scratch/eddyco_pipeline/eddyInquiry/secret.key.RDS"))
#'
save_small_eddy_s3 = function(data_to_save = NULL, write_creds = NULL){

  if(is.null(write_creds) == TRUE){
    stop("Specify write creds for s3 bucket research-eddy-inquiry")
  }

  if(is.null(data_to_save) == FALSE){

    # bucket
    ei_bucket = "research-eddy-inquiry"

    # Add write creds
    eddycopipe::add_s3_creds(bucket = ei_bucket, creds = write_creds, quite = TRUE)

    # Separate for saving lists or data.tables
    if(class(data_to_save)[1] == "list"){

    } else if(class(data_to_save)[1] %in% "data.table") {
      # Add file_name
      data_to_save = data_to_save %>%
        tidyr::unite(col = "file_name", c(SiteID, date, Data_Product_Level, Data_Type, Data_Product, Averaging_Interval), sep = "_", remove = FALSE) %>%
        dplyr::mutate(file_name = ifelse(test = Data_Product == "co2TurbVali", yes = paste0(base::substr(file_name, start = 1, stop = 37), "_01m"), no = file_name)) %>%
        tidyr::separate(file_name, into = c("blah", "blah2", "blah3", "blah4", "blah5", "timing"), sep = "_", remove = FALSE) %>% dplyr::select(-blah, -blah2, -blah3, -blah4, -blah5)

      # Check Data and determine what needs to be saved
      naming_data_table = data_to_save %>%
        dplyr::select(file_name, timing, SiteID, date, Data_Product_Level, Data_Type, Data_Product, Averaging_Interval) %>%
        dplyr::distinct()

      # For each unique file, save it to its special place
      for(i in seq_along(naming_data_table$file_name)){

        # Filter to the unique files
        data_i = data_to_save %>%
          dplyr::filter(file_name == naming_data_table$file_name[i])

        # Create queriable file name
        object_name = paste0(
          "sae/",
          naming_data_table$Data_Product_Level[i], "/",
          naming_data_table$Data_Type[i], "/",
          naming_data_table$date[i], "/",
          naming_data_table$SiteID[i], "/",
          naming_data_table$SiteID[i], "_",
          naming_data_table$date[i], "_",
          naming_data_table$Data_Product[i], "_",
          naming_data_table$timing[i], ".RDS"
        )

        # TODO save as parquet files, i hear they are pretty snazzy
        message(paste0(Sys.time(), ": Saving ", object_name))

        # Save to S3
        aws.s3::s3saveRDS(x = data_i, object = object_name, bucket = ei_bucket)

        # Check file was saved
        if(aws.s3::object_exists(object = object_name, bucket = ei_bucket) == FALSE){
          stop("Rutroooo!")
        }
      }

    } else {
      stop("Unexpected class for data_to_save: ", class(data_to_save))
    }

  } else {
    message(paste0(Sys.time(), ": data in pull was null"))
  }
}
