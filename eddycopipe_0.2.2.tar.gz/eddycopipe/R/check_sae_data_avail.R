#' @title See how many sites have available data for a specific date
#' @description This function messages you how many sites were found for specific date
#' @param query_date string, date you'd like to query; '2020-02-09'.
#' @param data_product_level string, specification of which data product you'd like to query for available data
#' @param return_data logical, do you want the lookup table returned?
#' @export
#' @examples
#'  check_sae_data_avail(query_date = "2021-04-10", data_product_level = "IP4", return_data = TRUE)
check_sae_data_avail = function(query_date = NULL, data_product_level = NULL, return_data = NULL, quiet = TRUE){

  Sys.unsetenv("AWS_SECRET_ACCESS_KEY")
  Sys.unsetenv("AWS_ACCESS_KEY_ID")

  # S3 Connection
  Sys.setenv("AWS_ACCESS_KEY_ID"     = "neon-sae-files",
             "AWS_S3_ENDPOINT"       = "neonscience.org",
             "AWS_DEFAULT_REGION"    = "s3.data")

  if(is.null(query_date) == TRUE){
    stop("Please specify date...")
  }
  if(is.null(data_product_level) == TRUE){
    stop("Please specify the data product level. Ie 'IP0', 'IP4', or 'DP4'")
  }

  # Required Libraries
  folder_keys = aws.s3::get_bucket_df(prefix = paste0("ods/dataproducts/", data_product_level, "/", query_date),  bucket= "neon-sae-files")
  if(nrow(folder_keys) > 0) {
    available_sites = folder_keys %>%
      dplyr::select(Key, LastModified, Size) %>%
      tidyr::separate(col = Key, sep = "/", into = c("delete1", "delete2", "delete3", "date", "site", "file"), remove = FALSE) %>%
      dplyr::select(-delete1, -delete2, -delete3)

    num_of_avail_sites = length(unique(available_sites$site))
    if(quiet == FALSE){message(paste0("There are ", num_of_avail_sites, " sites in the ", query_date, " folder..."))}

    # list all the unique sites
    list_of_avail_sites = unique(available_sites$site)

    # Return available Keys
    if(return_data == TRUE){
      list_return = list(num_of_avail_sites, available_sites)
      return(list_return)
    }
  } else {
    # No data found in the folder
    if(quiet == FALSE){message(paste0("No data found for: ", query_date))}
    if(return_data == TRUE){

      num_of_avail_sites = data.table::data.table()
      available_sites = data.table::data.table()

      list_return = list(num_of_avail_sites, available_sites)
      return(list_return)
    }
  }
}
