##############################################################################################
#' @title GCS - Save `.fst` files to the cloud
#'
#' @author Kevin Styers
#' @description This function is passed to the googleCloudStorageR::gcs_upload argument `object_function` and assists in uploading `.fst` files to the cloud.
#'
#' @param input local object to be saved
#' @param ouput path in the bucket to where the local object shall be written
#'
#' @return NA
#'
#' @examples
#' # Upload some data as a `.fst` files
#' googleCloudStorageR::gcs_upload(file = mtcars, bucket = "neon-eddy-inquiry", name = "mtcars.fst", predefinedAcl = "bucketLevel", object_function = gcs_save_fst)
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-22)
#     original creation
##############################################################################################
neon_gcs_save_fst <- function(input, output){
  library(fst)
  fst::write_fst(x = input, path = output)
}
