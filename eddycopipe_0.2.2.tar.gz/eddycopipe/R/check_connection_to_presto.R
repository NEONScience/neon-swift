#' @title Function to test connection to NEON Presto DB
#' @description  Step 2 in Presto connection testing. This function determines if the database is accessible and allows for more logic to control the eddycopipe
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @export
#' @examples
#' check_connection_to_presto(CredPsto = "myusername;mypassword")
check_connection_to_presto = function(CredPsto = presto_creds, conn = NULL){

  if(is.null(CredPsto) == TRUE){
    stop("Specify CredPsto: 'myusername;mypassword'")
  }

  # message(paste0(Sys.time(), ": test connection"))

  # Required Libaries
  library(RPresto)
  library(DBI)

  # Build connection to Presto DB
  if(is.null(conn) == TRUE){
    con = build_presto_connection(CredPsto = CredPsto, destroy = TRUE)
  } else {
    con = conn
  }

  # Actually checking if we can connect to the DB or not
  connection_status = tryCatch(
    {
      RPresto::dbExistsTable(conn = con, name = "readouts")
    },
    # Handler when a warning occurs:
    warning = function(cond) {
      message("Warning")
      message(cond)
      return(FALSE)
    },

    # Handler when an error occurs:
    error = function(cond) {
      message("ERROR")
      message(cond)
      return(FALSE)
    },

    finally = {
    }
  )

  # Like a good neighbor
  DBI::dbDisconnect(con)

  # Return Connection Status Logical
  return(connection_status)

}
