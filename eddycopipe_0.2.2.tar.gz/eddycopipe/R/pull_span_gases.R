#' @title Function to pull mean daily span gas values
#' @description  This function pulls the mean daily value for all streams in pull
#' @param idDp string containing full data product ID for the validation data needed (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param presto_creds Character string; your preso credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' pull_span_gases(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
pull_span_gases = function(idDp, dateBgn, dateEnd, CredPsto = NULL, lookup = NULL) {

  # Required Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(tidyr)
  library(here)

  # Check that Date Range is only 1 day, if != 1, do not run!
  if(as.Date(dateEnd) - as.Date(dateBgn) == 1){

    # Determine the site
    site=unique(substr(idDp,10,13))

    # Build and test connection
    con = wrap_build_test_presto_connection(CredPsto = CredPsto)

    # Stream formatting:
    idDpChar=sapply(idDp, function(x) paste0("",x,"")) %>%
      paste0(collapse=",") %>%
      as.factor() %>%
      paste0(collapse=",")

    forLoopTimeStart = Sys.time()

    for(i in 1:1){ # Start `for` loop [ALL TIME INTERVALS]
      # SQL Query!
      typeData = 'readout_val_double'
      sql = glue::glue_sql("SELECT
                        MIN({`typeData`}) as minVal, AVG({`typeData`}) as meanVal, MAX({`typeData`}) as maxVal, STDDEV({`typeData`}) as stDevVal, meas_strm_name
                        FROM readouts
                        WHERE
                        meas_strm_name IN ({idDpChar}) and
                        ds between {dateBgn} and {dateEnd} and
                        site = {site} and
                        {`typeData`}> -100000000
                        GROUP BY meas_strm_name
                        ", .con = con) %>%
        gsub(pattern = "NEON",replacement = "'NEON") %>%
        gsub(pattern = "0,", replacement = "0',") %>%
        gsub(pattern = "1,", replacement = "1',") %>%
        gsub(pattern = "2,", replacement = "2',") %>%
        gsub(pattern = "3,", replacement = "3',") %>%
        gsub(pattern = "''", replacement = "'") %>%
        gsub(pattern = '""', replacement = '"') %>%
        gsub(pattern = '"approx', replacement = "approx") %>%
        gsub(pattern = '0.95),"', replacement = "0.95),")

      res = DBI::dbSendQuery(con, sql)
      message(paste0(Sys.time(),": ", site, " from ", dateBgn, " to ", dateEnd))
      mrg.rpt= DBI::dbFetch(res,-1)

      if(nrow(mrg.rpt) > 0){

        span.data = mrg.rpt %>%
          dplyr::mutate(SiteID = site) %>%
          dplyr::mutate(StartTime = dateBgn) %>%
          dplyr::mutate(FinalTime = dateEnd) %>%
          dplyr::select(meas_strm_name, minVal, meanVal, maxVal, stDevVal, SiteID, StartTime, FinalTime)

        rm(mrg.rpt)

        s3_object_name = paste0("spanGas/", site, "_", dateEnd, ".fst")


        # Write daily file to S3
        eddycopipe::wrap_neon_gcs_upload(x = span.data, object = s3_object_name, bucket = "neon-eddy-inquiry")
        s3_object_exists = eddycopipe::neon_gcs_object_exists(object_name = s3_object_name, bucket = "neon-eddy-inquiry")
        if(s3_object_exists == TRUE){ message(paste0(Sys.time(),": Saved ", s3_object_name, "..."))} else { stop(paste0(s3_object_name, " data failed to save properly")) }


        rm(span.data, s3_object_exists)

      }

    } # END FOR LOOP
    message(paste0(Sys.time(),": ", site, " total time: ", round(difftime(Sys.time(),forLoopTimeStart,units = "secs"),2)))
    #disconnect from the DB
    DBI::dbDisconnect(con)
  } else{
    # Date Range was != 1
    message(paste0(Sys.time(),": The Date Range is no equal to 1!!! Date Range:", as.Date(dateEnd)-as.Date(dateBgn)))
  }

}
