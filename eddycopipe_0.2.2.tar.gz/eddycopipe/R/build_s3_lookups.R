#' @title Function to quickly build S3 lookup tables!
#' @description A lot of eddyInquiry functionality depends on knowing what data is stored safely in the S3 bucket. This function builds summarized lookup tables for all these dependencies. The output is stored in the S3 bucket in the s3.lookup folder
#' @param s3_creds character string; S3 bucket write creds for research-eddy-inquiry...ie s3_creds = 'AsDF32FEwFOi42DMF23M'
#' @export
#' @examples
#' build_s3_lookups(s3_creds = 'AsDF32FEwFOi42DMF23M')
build_s3_lookups = function(){

  message(paste0(Sys.time(), ": starting s3 lookup build"))
  # Check Linux
  sys_check = Sys.info()[1]
  save_locally = sys_check == "Linux"

  s3_bucket = "neon-eddy-inquiry"

  # Required Libraries
  library(tidyr)
  library(dplyr)
  library(data.table)
  library(eddycopipe)

  eddycopipe::neon_gcs_connect_to_bucket()

  start_build_time = Sys.time()

  # Build 2Min...
  start_2min_time = Sys.time()

  s3_meta_2min_raw <- eddycopipe::neon_gcs_list_objects(s3_bucket, prefix = "2min/", max = Inf)
  s3_meta_2min = s3_meta_2min_raw %>%
    dplyr::rowwise() %>%
    tidyr::separate(col = Key, into = c("Dir","SubDir1","SubDir2"), sep = "/" , remove = FALSE) %>%
    dplyr::filter(Dir == "2min" & Size > 0) %>%
    tidyr::separate(col = SubDir2, into = c("SiteID","Date","Sensor"), sep = "_") %>%
    dplyr::mutate(Sensor = stringr::str_remove(string = Sensor, pattern = ".fst")) %>%
    dplyr::select(-SubDir1)

  end_2min_time = Sys.time()

  # Save out to the S3 Bucket and locally
  eddycopipe::wrap_neon_gcs_upload(x = s3_meta_2min, object = "s3.lookup/s3.2min.meta.RDS", bucket = s3_bucket)
  # if(save_locally == TRUE){  base::saveRDS(s3_meta_2min, here::here("data/lookup/s3.2min.meta.RDS"))  }

  # Tell us how long 2min build took
  total_2min_time = round( difftime(end_2min_time, start_2min_time, units = "mins"),0 )
  message(paste0(Sys.time(), ": ", total_2min_time, " minutes to build 2min..."))

  # Build CnC...
  start_cnc_time = Sys.time()

  s3_meta_cnc_raw = eddycopipe::neon_gcs_list_objects(s3_bucket, prefix = "CnC/", max = Inf)
  s3_meta_cnc = s3_meta_cnc_raw %>%
    dplyr::rowwise() %>%
    dplyr::filter(stringr::str_detect(string = Key, pattern = "HourlyECPull") == FALSE) %>%
    tidyr::separate(col = Key, into = c("Dir","SubDir1"), sep = "/" , remove = FALSE) %>%
    dplyr::filter(Dir == "CnC" & Size > 0) %>%
    tidyr::separate(col = SubDir1, into = c("Site","Sensor"), sep = "_") %>%
    dplyr::mutate(Sensor = stringr::str_remove(string = Sensor, pattern = ".fst"))

  end_cnc_time = Sys.time()

  # Save out to the S3 Bucket and locally
  eddycopipe::wrap_neon_gcs_upload(x = s3_meta_cnc, object = "s3.lookup/s3.cnc.meta.RDS", bucket = s3_bucket)
  # if(save_locally == TRUE){  base::saveRDS(s3_meta_cnc, here::here("data/lookup/s3.cnc.meta.RDS"))  }
  # Tell us how long CnC build took
  total_cnc_time = round( difftime(end_cnc_time, start_cnc_time, units = "secs"),0 )
  message(paste0(Sys.time(), ": ", total_cnc_time, " seconds to build CnC..."))

  # Build spanGas...
  start_span_time = Sys.time()

  s3_meta_span_raw = eddycopipe::neon_gcs_list_objects(s3_bucket, prefix = "spanGas/", max = Inf)
  s3_meta_span = s3_meta_span_raw %>%
    dplyr::rowwise() %>%
    tidyr::separate(col = Key, into = c("Dir","SubDir1"), sep = "/" , remove = FALSE) %>%
    dplyr::filter(Dir == "spanGas" & Size >= 0) %>%
    tidyr::separate(col = SubDir1, into = c("Site", "Date"), sep = "_") %>%
    dplyr::filter(is.na(Date) == FALSE) %>%
    dplyr::mutate(Date = stringr::str_remove(string = Date, pattern = ".fst"))

  end_span_time = Sys.time()

  # Save out to the S3 Bucket and locally
  eddycopipe::wrap_neon_gcs_upload(x = s3_meta_span, object = "s3.lookup/s3.spanGas.meta.RDS", bucket = s3_bucket)
  # if(save_locally == TRUE){  base::saveRDS(s3_meta_span, here::here("data/lookup/s3.spanGas.meta.RDS"))  }
  # Tell us how long span build took
  total_span_time = round( difftime(end_span_time, start_span_time, units = "secs"),0 )
  message(paste0(Sys.time(), ": ", total_span_time, " seconds to build spanGas..."))


  # Build cval...
  start_cval_time = Sys.time()

  s3_meta_cval_raw = eddycopipe::neon_gcs_list_objects(s3_bucket, prefix = "cval/", max = Inf)
  s3_meta_cval = s3_meta_cval_raw %>%
    dplyr::filter(stringr::str_detect(string = Key, pattern = "cvals.data/") == TRUE) %>%
    dplyr::select(Key, Size) %>%
    dplyr::mutate(Key1 = base::substr(Key, start = 22 , stop = 800)) %>%
    tidyr::separate(col = Key1, into = c("Site", "Sensor", "StartDate", "StartTime", "EndDate", "EndTime"), sep = "_") %>%
    tidyr::unite(col = "StartDateTime", c(StartDate, StartTime), sep = " ") %>%
    tidyr::unite(col = "EndDateTime", c(EndDate, EndTime), sep = " ") %>%
    dplyr::filter(EndDateTime != "NA NA")

  end_cval_time = Sys.time()

  # Save out to the S3 Bucket and locally
  eddycopipe::wrap_neon_gcs_upload(x = s3_meta_cval, object = "s3.lookup/s3.cval.lookup.RDS", bucket = s3_bucket)
  # if(save_locally == TRUE){  base::saveRDS(s3_meta_cval, here::here("data/lookup/s3.cval.lookup.RDS"))  }
  # Tell us how long cval build took
  total_cval_time = round( difftime(end_cval_time, start_cval_time, units = "secs"),0 )
  message(paste0(Sys.time(), ": ", total_cval_time, " seconds to build cval..."))

  # Build cval stats...
  start_cvalstats_time = Sys.time()

  s3_meta_cvalstats = s3_meta_cval_raw %>%
    dplyr::filter(stringr::str_detect(string = Key, pattern = ".stats/") == TRUE) %>%
    dplyr::select(Key, Size) %>%
    dplyr::mutate(Key1 = base::substr(Key, start = 19 , stop = 800)) %>%
    tidyr::separate(col = Key1, into = c("Site", "Sensor", "StartDate", "StartTime", "EndDate", "EndTime"), sep = "_") %>%
    tidyr::unite(col = "StartDateTime", c(StartDate, StartTime), sep = " ") %>%
    tidyr::unite(col = "EndDateTime", c(EndDate, EndTime), sep = " ") %>%
    dplyr::filter(EndDateTime != "NA NA")

  end_cvalstats_time = Sys.time()

  # Save out to the S3 Bucket and locally
  eddycopipe::wrap_neon_gcs_upload(x = s3_meta_cvalstats, object = "s3.lookup/s3.cval.stats.lookup.RDS", bucket = s3_bucket)
  # if(save_locally == TRUE){  base::saveRDS(s3_meta_cvalstats, here::here("data/lookup/s3.cval.stats.lookup.RDS"))  }
  # Tell us how long cval build took
  total_cvalstats_time = round( difftime(end_cvalstats_time, start_cvalstats_time, units = "secs"),0 )
  message(paste0(Sys.time(), ": ", total_cvalstats_time, " seconds to build cval stats..."))

  # Build cval periods...
  start_cvalperiods_time = Sys.time()

  s3_meta_cvalperiods = s3_meta_cval_raw %>%
    dplyr::filter(stringr::str_detect(string = Key, pattern = "periods.data") == TRUE) %>%
    dplyr::select(Key, Size) %>%
    dplyr::filter(Size != 0) %>%
    tidyr::separate(col = Key, into = c("root", "subsystem", "file"), sep = "/", remove = FALSE) %>%
    dplyr::select(-root) %>%
    dplyr::mutate(subsystem = ifelse(test = subsystem == "ecse.cval.periods.data", yes = "ecse", no = "ecte")) %>%
    tidyr::separate(col = file, into = c("SiteID", "NumberOfCVALs", "StartDate", "EndDate"), sep = "_") %>%
    dplyr::mutate(EndDate = gsub(pattern = ".RDS", replacement = "", x = EndDate)) %>%
    dplyr::mutate(EndDate = lubridate::ymd(EndDate)) %>%
    dplyr::mutate(StartDate = lubridate::ymd(StartDate))

  end_cvalperiods_time = Sys.time()

  # Save out to the S3 Bucket
  ecte.cval.periods.meta = s3_meta_cvalperiods %>%  dplyr::filter(subsystem == "ecte")
  eddycopipe::wrap_neon_gcs_upload(x = ecte.cval.periods.meta, object = "s3.lookup/ecte.cval.periods.meta.RDS", bucket = s3_bucket)
  ecse.cval.periods.meta = s3_meta_cvalperiods %>%  dplyr::filter(subsystem == "ecse")
  eddycopipe::wrap_neon_gcs_upload(x = ecse.cval.periods.meta, object = "s3.lookup/ecse.cval.periods.meta.RDS", bucket = s3_bucket)
  # Tell us how long cval build took
  total_cvalperiods_time = round( difftime(end_cvalperiods_time, start_cvalperiods_time, units = "secs"),0 )
  message(paste0(Sys.time(), ": ", total_cvalperiods_time, " seconds to build cval periods..."))


  ### Wet dep build
  # Build 2Min...
  start_2min_time = Sys.time()

  s3_meta_wet_dep_raw <- eddycopipe::neon_gcs_list_objects(s3_bucket, prefix = "wet_dep/", max = Inf)
  s3_meta_wet_dep = s3_meta_wet_dep_raw %>%
    dplyr::rowwise() %>%
    tidyr::separate(col = Key, into = c("Dir","SubDir1","SubDir2"), sep = "/" , remove = FALSE) %>%
    dplyr::filter(Dir == "wet_dep" & Size > 0) %>%
    tidyr::separate(col = SubDir2, into = c("SiteID","Date","Sensor"), sep = "_") %>%
    dplyr::mutate(Sensor = stringr::str_remove(string = Sensor, pattern = ".fst")) %>%
    dplyr::select(-SubDir1)

  eddycopipe::wrap_neon_gcs_upload(x = s3_meta_wet_dep, object = "s3.lookup/s3_meta_wet_dep.RDS", bucket = s3_bucket)

  end_wet_dep_time = Sys.time()

  end_build_time = Sys.time()

  message(paste0(Sys.time(), ": Build took ", round(difftime(end_build_time, start_build_time, units = "mins"), 2), " minutes..."))
}
