#' @title Converts Bits to Ints
#' @description
#' @param x character, bits
#' @export
#' @examples
#' bitsToInt()
bitsToInt<-function(x) {
  base::packBits(base::rev(c(base::rep(FALSE, 32-length(x)%%32), as.logical(x))), "integer")
}
