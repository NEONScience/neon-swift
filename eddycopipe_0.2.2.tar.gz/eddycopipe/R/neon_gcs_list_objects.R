##############################################################################################
#' @title GCS - List objects in a bucket
#'
#' @author Kevin Styers
#' @description This function wraps googleCloudStorageR::gcs_list_objects
#'
#' @param bucket the name of the bucket
#' @param detail Set level of detail: c("summary", "more", "full")
#' @param prefix filter results to objects whose names begin with this prefix
#' @param delimiter Use to list objects like a directory listing.
#' @param max This is just here so we don't have to update this line on hundreds of aws.s3 calls
#'
#' @return a data.frame of the objects
#'
#' @examples
#' gcs_get_fst(object_name = "mtcars.fst")
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-22)
#     original creation
##############################################################################################
neon_gcs_list_objects = function(bucket = NULL, detail = c("summary", "more", "full"), prefix = NULL, delimiter = NULL, max = NULL){

  if(is.null(bucket)){
    stop("Please specify bucket")
  }

  library(dplyr)
  library(tidyr)

  gcs_objects = googleCloudStorageR::gcs_list_objects(bucket = bucket, prefix = prefix, detail = detail, delimiter = delimiter)

  # Rename name to Key and keep everything else
  if(nrow(gcs_objects) > 0){
    gcs_objects = gcs_objects %>% dplyr::select(Key = name, Size = size, tidyr::everything())
  }



  return(gcs_objects)

}
