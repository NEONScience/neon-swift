##############################################################################################
#' @title GCS EZ n Swift S3 Lookup Tables
#'
#' @author Kevin Styers
#' @description This function assists neon_read_eddy_inquiry in reading in data a bit faster. Typically we would read in the entire bucket lookup table (>600k rows) and this was time consuming. Now will download into a temp directory and the code will check if it's there, and use it instead of downloading it everytime. There is additional logic that make sure it is up to date. If it is out of date, then it downloads the latest version.
#'
#' @details It typically takes 1.3749 second to read in the table from the cloud, while it takes 1.27905 seconds to read from local, resulting in an astonishing 0.09585 second gain.
#'
#' @param object the name of the object (or the path) in the cloud to read
#' @param bucket the name of the bucket
#'
#' @return the specified lookup table
#'
#' @examples NULL
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-03-02)
#     original creation
##############################################################################################
neon_get_s3_lookup = function(object = NULL, bucket = NULL){

  if(is.null(object) | is.null(bucket)){
    stop(paste0(Sys.time(), ": args not specified, please specify both object and bucket"))
  }

  # Specify local s3 table path
  lcl_s3_lkup_path = paste0(tempdir(), "/tmp_", base::basename(object))

  # Check if local table exists
  lcl_s3_fl_exts = file.exists(lcl_s3_lkup_path)


  # The file will not exist if the session is new and has now yet downloaded, this is a pretty common case
  if(!lcl_s3_fl_exts) {
    # Download the file
    s3_lkup <- eddycopipe::neon_gcs_get_rds(object = object, bucket = bucket)
    # Save the file
    base::saveRDS(s3_lkup, lcl_s3_lkup_path)
  } else {
  # Check if latest S3 Table is newer
    # Convert local file modified time to UTC
    lcl_s3_lkup_mtime = file.info(lcl_s3_lkup_path)$mtime
    attr(lcl_s3_lkup_mtime, "tzone") <- "UTC"

    # Convert UTC timestamp that R thinks is MST. ONLY changing MST to UTC, not adding hours as the imported time is correct, but the tz specification is wrong.
    gcs_s3_lkup_mtime_raw = eddycopipe::neon_gcs_list_objects(bucket = bucket, prefix = object)$updated
    gcs_s3_lkup_mtime = lubridate::ymd_hms(gcs_s3_lkup_mtime_raw, tz = "UTC")

    # Compare the two, if the GCS version was updated more recently than the local version; ie GCS > Local, then download the latest data.
    gcs_has_updated = lcl_s3_lkup_mtime < gcs_s3_lkup_mtime

  # Choose what to do
    # If GCS has newer version download it
    if(gcs_has_updated){
      # Download the file
      s3_lkup <- eddycopipe::neon_gcs_get_rds(object = object, bucket = bucket)
      # Save the file
      base::saveRDS(s3_lkup, lcl_s3_lkup_path)
    } else {
    # Else read in the local one
      s3_lkup = base::readRDS(lcl_s3_lkup_path)
    }
  }

  # Return table
  return(s3_lkup)
}
