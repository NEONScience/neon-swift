#' @title Wrapper to pull all L0 heater data for analysis
#' @description  This function pairs with pull_heater.R to pull data from Presto and save it to S3
#' @param site Character string; siteid code
#' @param start Start date
#' @param end End date
#' @param write_creds character of the write creds
#' @export
#' @examples
#' wrap_pull_ecse_co2(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
wrap_pull_ecse_co2 = function(site, start, end, write_creds = NULL){

  # Check for write creds
  if(is.null(write_creds) == TRUE){
    stop("Specify write creds for s3 bucket research-eddy-inquiry")
  }

  # Since we
  # dps = c("co2Stor", "isoCo2", "soni", "co2Turb", "h2oTurb", "presBaro", "radiNet", `"tempAirLvl", "tempAirTop", "tempSoil")
  dps = c("co2Stor", "h2oStor", "isoCo2", "isoH2o", "co2Turb", "h2oTurb", "soni", "amrs",  "presBaro", "radiNet", "tempAirLvl", "tempAirTop", "co2StorVali", "co2TurbVali", "isoCo2Vali", "isoH2oVali")
  # dps = c("amrs")

  data_in = pull_eddy_data(
    siteid       = site,
    start        = start,
    end          = end,
    dp_ver       = "DP4",
    type         = "expanded",
    avg_interval = "30m",
    dp           = dps,
    dp_level     = "dp01",
    data_type    = "data",
    over_write   =  TRUE
  )

  # Run eddycopipe saving routine, view the function for more details
  if(is.null(data_in) == FALSE){
    if(nrow(data_in) > 0){
      # This function parses the data pulled by pull_eddy_data into dp_level (DP4), type (data vs qfqm), date, site, and dp (co2Stor vs h2oTurb) and saves it to s3
      save_small_eddy_s3(data_to_save = data_in, write_creds = write_creds)
    } else {
      message(paste0(Sys.time(), ": ", site, ": ", start, " to ", end, " already have data or no data was found for: ", paste0(dps, collapse = ", "),". Not saving data"))
    }
  } else {
    message(paste0(Sys.time(), ": ", site, ": ", start, " to ", end, " no data was found for: ", paste0(dps, collapse = ", ")))
  }
}
