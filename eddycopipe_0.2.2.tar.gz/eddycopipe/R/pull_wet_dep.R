#' @title Wet dep prt data pull
#' @description  Pull all wet dep prt data for all TIS/AIS sites that have them
#' @param idDp string containing full data product ID (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param dateBgn date; start of data pull
#' @param dateEnd date; end of data pull
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param everyMinute numeric; you want data every 2 min, 2. Every 5 min, 5. etc
#' @param compression specify compression for files saved to S3
#' @export
#' @examples
#' pull_wet_dep()
pull_wet_dep = function(idDp, dateBgn, dateEnd, CredPsto = NULL, everyMinute = 2, compression = 50) {

  # Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(tidyr)
  library(here)


  # Check that Date Range is only 1 day, if != 1, do not run!
  if(as.Date(dateEnd) - as.Date(dateBgn) < 507){

    # Determine the site
    site = unique(substr(idDp,10,13))

    # Build and test connection
    con = wrap_build_test_presto_connection(CredPsto = CredPsto)

    # Stream formatting:
    idDpChar = sapply(idDp, function(x) paste0("",x,"")) %>% paste0(collapse=",") %>% as.factor() %>% paste0(collapse=",")

    sql = glue::glue_sql("SELECT
                            meas_strm_name, readout_time, readout_val_double
                           FROM
                            readouts
                           WHERE
                            site = {site} and
                            meas_strm_name IN ({idDpChar}) and
                            ds between {dateBgn} and {dateEnd} and
                            MINUTE(readout_time) % {everyMinute} = 0 and SECOND(readout_time) = 0
                           ",
                          .con = con
    ) %>%
      # The stuff below is some magic to format the string of streams juuust right
      gsub(pattern = "NEON",replacement = "'NEON") %>%
      gsub(pattern = "0,", replacement = "0',") %>%
      gsub(pattern = "1,", replacement = "1',") %>%
      gsub(pattern = "2,", replacement = "2',") %>%
      gsub(pattern = "3,", replacement = "3',") %>%
      gsub(pattern = "''", replacement = "'") %>%
      gsub(pattern = '""', replacement = '"') %>%
      gsub(pattern = '"approx', replacement = "approx") %>%
      gsub(pattern = '0.95),"', replacement = "0.95),")

    start = Sys.time()

    # Send the Query
    res = DBI::dbSendQuery(con, sql)
    message(paste0(Sys.time(), ": 14%:  ",site, " from ", dateBgn, " to ", dateEnd))
    # Actually grab the data from the query
    mrg.rpt= DBI::dbFetch(res,-1)

    base::message(paste0(Sys.time(), ": 21%:  Pull finished..."))
    # Disconnect from the DB like a good neighbor
    DBI::dbDisconnect(con)
    base::message(paste0(Sys.time(), ": 28%:  Disconnected from Presto..."))

    # Time calculations
    end = Sys.time()
    elapsed = difftime(end, start, units = "secs")
    message(paste0(Sys.time(), ": 37%:  Pull lasted: ",round(elapsed,3)," seconds..."))

    # If there is data in the pull tidy the data a little, and then save it appropriately
    if(nrow(mrg.rpt) > 0){

      # Load in the Sensor Names to DPID lookup table
      sensorNameStreams =  eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = "neon-eddy-inquiry") %>%
        dplyr::mutate(DPID = base::trimws(DPID, which = "both"))

      # Clean up table
      mrg.rpt = data.table::as.data.table(mrg.rpt) %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name, start = 15, stop = 100)) %>% # Create a mutual column to join the Sensor Names lookup table to
        dplyr::mutate(DPID = base::trimws(DPID, which = "both")) %>%
        dplyr::mutate(SiteID = site)

      # Join the lookup table and raw 2 minute data, giving all the streams human readible names
      mrg.rpt.out = dplyr::left_join(x = mrg.rpt, y = sensorNameStreams, by = "DPID")
      rm(mrg.rpt)

      # Formating the df
      mrg.rpt.distinct = mrg.rpt.out  %>%
        dplyr::mutate(readout_time = lubridate::ymd_hms(readout_time)) %>%
        dplyr::distinct(readout_time,strm_name, .keep_all = TRUE) %>%
        dplyr::select(SiteID,DPID,strm_name,readout_time,readout_val_double)
      rm(mrg.rpt.out)

      # Get a list of all the unique data streams we just pulled
      listOfStreamNames = as.data.frame(sort(unique(mrg.rpt.distinct$strm_name)))
      names(listOfStreamNames) = "strm_name"

      # Create lists for file saves!
      ei.wet_dep = listOfStreamNames %>% dplyr::filter(strm_name %in% c("prt_wet_dep_C", "prt_single_ml3", "prt_single_ml4", "prt_single_ml5", "prt_single_ml6", "prt_single_ml7", "prt_met_station"))

      ### Wet Dep streams
      if(nrow(ei.wet_dep) > 0){

        # there are raw temp prt streams here that have to be fixed
        wet_dep_raw_streams = c("prt_single_ml3", "prt_single_ml4", "prt_single_ml5", "prt_single_ml6", "prt_single_ml7", "prt_met_station")

        wet_dep_data = mrg.rpt.distinct %>%  dplyr::filter(strm_name %in% c("prt_wet_dep_C", "prt_single_ml3", "prt_single_ml4", "prt_single_ml5", "prt_single_ml6", "prt_single_ml7", "prt_met_station")) %>%
          dplyr::mutate(readout_temp = ifelse(test = strm_name %in% wet_dep_raw_streams & readout_val_double >= 100, yes =  ((readout_val_double/100)-1)/.00385,
                                  no = ifelse(test = strm_name %in% wet_dep_raw_streams & readout_val_double <  100, yes =  (readout_val_double -100) / (.00392 *100),
                                  no = ifelse(test = strm_name == "prt_wet_dep_C", yes = readout_val_double, no = NA)))) %>%
          dplyr::mutate(strm_name = ifelse(test = stringr::str_detect(string = strm_name, pattern = "_single_") == TRUE, yes = "prt_single_asperated_C", no = strm_name))

        ei_save_S3(prefix = "wet_dep", file_extension = "_wet.dep.fst", dataTable = wet_dep_data, site = site, dateBgn = dateBgn, percentage = "44.44", compression = compression)
      } else {
        message(paste0(Sys.time(), ": No data in pull..."))
      }
    } else {
      message(paste0(Sys.time(), ": No data in pull..."))
    }
  } else {
    message(paste0(Sys.time(), ": The Date Range is greater than 11!!! Date Range:", as.Date(dateEnd) - as.Date(dateBgn)))
  }
}
