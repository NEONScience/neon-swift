#' @title Wrapper to pull all L0 heater data for analysis
#' @description  This function pairs with pull_heater.R to pull data from Presto and save it to S3
#' @param presto_creds Character string; your preso credentials 'username;password'
#' @param s3_creds Character string; research-eddy-inquiry write credentials
#' @param pull_date Date; date to pull data
#' @param sites Vector of sites you want to pull, defaults to 'ALL'
#' @export
#' @examples
#' wrap_heater_pull(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
wrap_heater_pull = function(presto_creds = NULL, s3_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(s3_creds) == TRUE){
    stop("Please specify s3_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify s3_creds: 'username;password'")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)

  ei_bucket = "research-eddy-inquiry"

  siteList = get_sites_and_set_creds(
    s3_creds = s3_creds
  )

  # Heater Sites
  sites = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket)

  matrix = aws.s3::s3readRDS(object = "lookup/matrix_nr01_heater.RDS", bucket = ei_bucket)

  pull_heater_data = function(i, start, stop){

    # Get L0 matrix for site
    site_streams = compose_L0_matrix(
      site = i, matrix =  matrix
    )

    streams = base::as.vector(site_streams$streams)
    try(
      pull_heater(
        idDp        = streams,
        dateBgn     = start,
        dateEnd     = stop,
        CredPsto    = presto_creds,
        CredS3      = s3_creds,
        everyMinute = 2,
        compression = 100
      )
    )
  }

  time_data <- base::system.time(
    for(i in sites$SiteID){
      start1 <- Sys.time()
      base::try(
        pull_heater_data(i = i, start = pull_date, stop = pull_date + 1)
      )
      message(paste0(Sys.time(), ": 100%: Completed Pull"))
      end1 <- Sys.time()
      message(paste0(Sys.time(), ": ", i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
    }
  )
  message(paste0(Sys.time(), ": Completed Wet Dep Temp pull in: ", round(time_data[3]/60,1), " minutes"))
}
