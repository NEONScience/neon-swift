##############################################################################################
#' @title GCS - Read `.fst` files directly from the cloud
#'
#' @author Kevin Styers
#' @description This function wraps googleCloudStorageR::gcs_get_object to download the file, read it in, delete the file from memory, then return the values
#'
#' @param object the name of the object (or the path) in the cloud to read
#' @param bucket the name of the bucket
#'
#' @return the .fst table in the cloud
#'
#' @examples
#' neon_gcs_get_fst(object = "mtcars.fst")
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-22)
#     original creation
##############################################################################################
neon_gcs_get_fst = function(object = NULL, bucket = NULL){

  # Logic
  if(is.null(object) | is.null(bucket)){
    stop(paste0(Sys.time(), ": args not specified, please specify both object and bucket"))
  }

  # Libraries
  library(fst)
  library(googleCloudStorageR)

  # Check if object exists
  object_exists = eddycopipe::neon_gcs_object_exists(bucket = bucket, object_name = object)

  if(object_exists){
    # Specify temp location
    tmp_file_location = paste0(tempdir(), "/temp_fst_file", Sys.time(),".fst")
    # Download the file
    googleCloudStorageR::gcs_get_object(object_name = object, bucket = bucket, saveToDisk = tmp_file_location)
    # Read file
    fst_file = fst::read_fst(path = tmp_file_location, as.data.table = TRUE)
    # Remove file
    base::unlink(tmp_file_location)
  } else {
    fst_file = data.table::data.table()
  }

  return(fst_file)

}
