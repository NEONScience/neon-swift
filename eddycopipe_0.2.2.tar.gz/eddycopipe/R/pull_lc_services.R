#' @title Pull all LC Services data from Dan's DB
#' @description  This script pulls data from an SQL database maintained by Dan Allen, if this code breaks, maybe the DB is gone :/
#' @export
#' @examples
#' pull_lc_services()
pull_lc_services = function(){

  `%notin%` = Negate(`%in%`)

  TotalTime <- Sys.time()
  # Update LC Services data
  library(RMySQL)
  library(dplyr)
  library(stringr)
  library(fst)
  library(ggplot2)
  library(DBI)
  # This data is stored in Dan Allen's SoH database

  # Grab CnC data
  # Set result to grab data from ServicesLog table with Columns LCNumber, Name, cnc, rtu, TimeStamp
  mysqlconnection = DBI::dbConnect(RMySQL::MySQL(), user='reader', password='redaer', dbname='myDB', host = 'soh.ci.neoninternal.org')
  result <- DBI::dbSendQuery(mysqlconnection, "Select LCNumber, Name, cnc, rtu, hornetq,TimeStamp from ServicesLog
                                        WHERE
                                        TimeStamp >= '2017-01-01T21:36:01+00:00'
                      ")

  message(paste0(Sys.time(), ": collecting LC Serivces data"))
  # Grabbing the data with all of the results
  data.frame = DBI::fetch(result, n = Inf)

  # Disconnecting from the database to limit connections
  DBI::dbDisconnect(mysqlconnection)

  # Adding Date variable up front before writing to save time during RMD creation
  data.frame$date <- as.Date(data.frame$TimeStamp, "%Y-%m-%d")

  # Reformat dates
  data.frame$TimeStamp = substr(data.frame$TimeStamp,1,nchar(data.frame$TimeStamp)-6)
  data.frame$TimeStamp <- stringr::str_replace(data.frame$TimeStamp, "[T]", " ")
  data.frame$TimeStamp <- as.POSIXct(data.frame$TimeStamp, format = "%Y-%m-%d %H:%M:%S", tz = "GMT")
  data.frame$Name <- as.factor(data.frame$Name)

  data.frame <- data.frame %>%
    dplyr::arrange(dplyr::desc(date))

  # Take Main CnC file and spread it across for each site
  swft.full.site.lookup <- eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = "neon-eddy-inquiry")

  for(i in swft.full.site.lookup$SiteID){
    message(paste0(Sys.time(), ": ", i, " saved"))
    site.cnc.data <- data.frame %>%
      dplyr::filter(Name == i)
    eddycopipe::wrap_neon_gcs_upload(x = site.cnc.data, object = paste0("CnC/", i, "_CnC.fst"), bucket = "neon-eddy-inquiry")
  }

  # Pre-gen summary plots of past so many days
  # Read in site domain metadata

  tis.list <- swft.full.site.lookup %>%
    dplyr::filter(Type == "TIS")

  ais.list <- swft.full.site.lookup %>%
    dplyr::filter(Type == "AIS")

  swft.recent.lc.services <- data.frame %>%
    dplyr::filter(date > Sys.Date() - 14) %>%
    dplyr::mutate(SiteID = Name) %>%
    dplyr::select(-Name)

  swft.recent.lc.services$SiteID <- factor(swft.recent.lc.services$SiteID, levels = c("BART","HARV","HOPB","BLAN","SCBI","SERC",'LEWI','POSE',"OSBS","DSNY","JERC",'FLNT','BARC','SUGG',"GUAN","LAJA",'CUPE','GUIL',"UNDE","STEI","TREE",'LIRO','CRAM',"KONZ","UKFS","KONA",'MCDI','KING',"ORNL","MLBS","GRSM",'LECO','WALK',"TALL","LENO","DELA",'BLWA','TOMB','MAYF',"WOOD","DCFS","NOGP",'PRPO','PRLA',"STER","CPER","RMNP","NIWO",'ARIK','COMO', 'WLOU',"CLBJ","OAES",'PRIN','BLUE',"YELL","MOAB","ONAQ", "BLDE","REDB","SRER","JORN",'SYCA',"WREF","ABBY",'MCRA','MART',"SJER","SOAP","TEAK",'BIGC','TECR',"TOOL","BARR","BONA","DEJU","HEAL",'OKSR','TOOK','CARI',"PUUM"))


  # LENO BONA PUUM UNDE have CnC running on multiple LCs UGGGGHHH Will have to manually assign these...
  # They are likely all on 1 based upon the data....
  swft.recent.lc.services.tis <- swft.recent.lc.services %>%
    dplyr::left_join(y = swft.full.site.lookup, by = "SiteID") %>%
    dplyr::filter(Type == "TIS") %>%
    dplyr::group_by(SiteID, LCNumber) %>%
    dplyr::summarise(.groups = "drop",
      Type                  = Type[1],
      start.date            = min(date, na.rm = TRUE),
      end.date              = max(date, na.rm = TRUE),
      cnc.hours.on          = sum(cnc ==  1, na.rm = TRUE),
      cnc.hours.unavail     = sum(cnc ==  0, na.rm = TRUE),
      cnc.hours.off         = sum(cnc == -1, na.rm = TRUE),
      rtu.hours.on          = sum(rtu ==  1, na.rm = TRUE),
      rtu.hours.unavail     = sum(rtu ==  0, na.rm = TRUE),
      rtu.hours.off         = sum(rtu == -1, na.rm = TRUE),
      hornetq.hours.on      = sum(hornetq ==  1, na.rm = TRUE),
      hornetq.hours.unavail = sum(hornetq ==  0, na.rm = TRUE),
      hornetq.hours.off     = sum(hornetq == -1, na.rm = TRUE),
      hours.total   = length(SiteID)
    ) %>%
    dplyr::filter(cnc.hours.on > 0) %>%
    dplyr::mutate(cnc.Uptime       = 100 * cnc.hours.on/hours.total) %>%
    dplyr::mutate(cnc.Downtime     = 100 * cnc.hours.off/hours.total) %>%
    dplyr::mutate(cnc.NoComms      = 100 * cnc.hours.unavail/hours.total) %>%
    dplyr::mutate(rtu.Uptime       = 100 * rtu.hours.on/hours.total) %>%
    dplyr::mutate(rtu.Downtime     = 100 * rtu.hours.off/hours.total) %>%
    dplyr::mutate(rtu.NoComms      = 100 * rtu.hours.unavail/hours.total) %>%
    dplyr::mutate(hornetq.Uptime   = 100 * hornetq.hours.on/hours.total) %>%
    dplyr::mutate(hornetq.Downtime = 100 * hornetq.hours.off/hours.total) %>%
    dplyr::mutate(hornetq.NoComms  = 100 * hornetq.hours.unavail/hours.total) %>%
    dplyr::select(SiteID, LCNumber, start.date, end.date, cnc.Uptime, cnc.Downtime, cnc.NoComms,
                  rtu.Uptime, rtu.Downtime, rtu.NoComms,
                  hornetq.Uptime, hornetq.Downtime, hornetq.NoComms) %>%
    tidyr::unite(col = "SiteID_LC", c(SiteID, LCNumber), remove = FALSE) %>%
    dplyr::filter(SiteID_LC %notin% c("LENO_2", "PUUM_2", "UNDE_2", "BONA_2")) %>%
    dplyr::select(-SiteID_LC) %>%
    reshape2::melt(id.vars = c("SiteID", "LCNumber", "start.date", "end.date")) %>%
    tidyr::separate(col = "variable", into = c("Service","Statistic")) %>%
    dplyr::mutate(value = round(value, 2))

  swft.recent.lc.services.tis$SiteID <- factor(swft.recent.lc.services.tis$SiteID, levels =  c("BART","HARV","BLAN","SCBI","SERC","OSBS","DSNY","JERC","GUAN","LAJA",
                                                                                               "UNDE","STEI","TREE","KONZ","UKFS","KONA","ORNL","MLBS","GRSM",
                                                                                               "TALL","LENO","DELA","WOOD","DCFS","NOGP","STER","CPER","RMNP","NIWO",
                                                                                               "CLBJ","OAES","YELL","MOAB","ONAQ","SRER","JORN","WREF","ABBY",
                                                                                               "SJER","SOAP","TEAK","TOOL","BARR","BONA","DEJU","HEAL","PUUM"))

  swft.recent.lc.services.ais <- swft.recent.lc.services %>%
    dplyr::left_join(y = swft.full.site.lookup, by = "SiteID") %>%
    dplyr::filter(Type == "AIS") %>%
    dplyr::group_by(SiteID, LCNumber) %>%
    dplyr::summarise(.groups = "drop",
      Type          = Type[1],
      start.date    = min(date, na.rm = TRUE),
      end.date      = max(date, na.rm = TRUE),
      cnc.hours.on      = sum(cnc ==  1, na.rm = TRUE),
      cnc.hours.unavail = sum(cnc ==  0, na.rm = TRUE),
      cnc.hours.off     = sum(cnc == -1, na.rm = TRUE),
      rtu.hours.on      = sum(rtu ==  1, na.rm = TRUE),
      rtu.hours.unavail = sum(rtu ==  0, na.rm = TRUE),
      rtu.hours.off     = sum(rtu == -1, na.rm = TRUE),
      hornetq.hours.on      = sum(hornetq ==  1, na.rm = TRUE),
      hornetq.hours.unavail = sum(hornetq ==  0, na.rm = TRUE),
      hornetq.hours.off     = sum(hornetq == -1, na.rm = TRUE),
      hours.total   = length(SiteID)
    ) %>%
    dplyr::filter(cnc.hours.on > 0) %>%
    dplyr::mutate(cnc.Uptime       = 100 * cnc.hours.on/hours.total) %>%
    dplyr::mutate(cnc.Downtime     = 100 * cnc.hours.off/hours.total) %>%
    dplyr::mutate(cnc.NoComms      = 100 * cnc.hours.unavail/hours.total) %>%
    dplyr::mutate(rtu.Uptime       = 100 * rtu.hours.on/hours.total) %>%
    dplyr::mutate(rtu.Downtime     = 100 * rtu.hours.off/hours.total) %>%
    dplyr::mutate(rtu.NoComms      = 100 * rtu.hours.unavail/hours.total) %>%
    dplyr::mutate(hornetq.Uptime   = 100 * hornetq.hours.on/hours.total) %>%
    dplyr::mutate(hornetq.Downtime = 100 * hornetq.hours.off/hours.total) %>%
    dplyr::mutate(hornetq.NoComms  = 100 * hornetq.hours.unavail/hours.total) %>%
    dplyr::select(SiteID, LCNumber, start.date, end.date, cnc.Uptime, cnc.Downtime, cnc.NoComms,
                  rtu.Uptime, rtu.Downtime, rtu.NoComms,
                  hornetq.Uptime, hornetq.Downtime, hornetq.NoComms) %>%
    reshape2::melt(id.vars = c("SiteID", "LCNumber", "start.date", "end.date")) %>%
    tidyr::separate(col = "variable", into = c("Service","Statistic"))


  swft.recent.lc.services.ais$SiteID <- factor(swft.recent.lc.services.ais$SiteID, levels =   c("HOPB",'LEWI','POSE','FLNT','BARC','SUGG','CUPE','GUIL','LIRO',
                                                                                                'CRAM','MCDI','KING','LECO','WALK','BLWA','TOMB','MAYF','PRPO',
                                                                                                'PRLA','ARIK','PRIN','BLUE','WLOU','COMO','BLDE','SYCA','REDB','MCRA',
                                                                                                'MART','BIGC','TECR','OKSR','TOOK','CARI'))

  minCncDate <- min(swft.recent.lc.services$date)
  maxCncDate <- max(swft.recent.lc.services$date)

  swft.lcservices.fills <- c("Uptime" = "#00cc00",
                             "Downtime" = "red",
                             "NoComms" = "#696969")


  swft.tis.cnc.plot <- ggplot(swft.recent.lc.services.tis %>% dplyr::filter(Service == "cnc"), aes(x = SiteID, y = value, fill = Statistic)) +
    geom_col() +
    scale_fill_manual(values = swft.lcservices.fills) +
    theme(axis.text.x = element_text(angle = 270)) +
    lims(y = c(0,100)) +
    labs(title = paste0("NEON Observatory TIS CnC Serivce Uptime Overview: ", minCncDate," to ", maxCncDate),
         y = "Percentage", x = "SiteID")
  swft.tis.rtu.plot <- ggplot(swft.recent.lc.services.tis %>% dplyr::filter(Service == "rtu"), aes(x = SiteID, y = value, fill = Statistic)) +
    geom_col() +
    scale_fill_manual(values = swft.lcservices.fills) +
    theme(axis.text.x = element_text(angle = 270)) +
    lims(y = c(0,100)) +

    labs(title = paste0("NEON Observatory TIS RTU Serivce Uptime Overview: ", minCncDate," to ", maxCncDate),
         y = "Percentage", x = "SiteID")
  swft.tis.hornetq.plot <- ggplot(swft.recent.lc.services.tis %>% dplyr::filter(Service == "hornetq"), aes(x = SiteID, y = value, fill = Statistic)) +
    geom_col() +
    scale_fill_manual(values = swft.lcservices.fills) +
    theme(axis.text.x = element_text(angle = 270)) +
    lims(y = c(0,100)) +
    labs(title = paste0("NEON Observatory TIS HornetQ Serivce Uptime Overview: ", minCncDate," to ", maxCncDate),
         y = "Percentage", x = "SiteID")

  eddycopipe::wrap_neon_gcs_upload(x = swft.tis.cnc.plot, object = "CnC/plots/swft.tis.cnc.plot.RDS", bucket = "neon-eddy-inquiry")
  eddycopipe::wrap_neon_gcs_upload(x = swft.tis.rtu.plot, object = "CnC/plots/swft.tis.rtu.plot.RDS", bucket = "neon-eddy-inquiry")
  eddycopipe::wrap_neon_gcs_upload(x = swft.tis.hornetq.plot, object = "CnC/plots/swft.tis.hornetq.plot.RDS", bucket = "neon-eddy-inquiry")

  swft.ais.cnc.plot <- ggplot(swft.recent.lc.services.ais %>% dplyr::filter(Service == "cnc"), aes(x = SiteID, y = value, fill = Statistic)) +
    geom_col() +
    scale_fill_manual(values = swft.lcservices.fills) +
    theme(axis.text.x = element_text(angle = 270)) +
    lims(y = c(0,100)) +
    labs(title = paste0("NEON Observatory AIS CnC Serivce Uptime Overview: ", minCncDate," to ", maxCncDate),
         y = "Percentage", x = "SiteID")
  swft.ais.rtu.plot <- ggplot(swft.recent.lc.services.ais %>% dplyr::filter(Service == "rtu"), aes(x = SiteID, y = value, fill = Statistic)) +
    geom_col() +
    scale_fill_manual(values = swft.lcservices.fills) +
    theme(axis.text.x = element_text(angle = 270)) +
    lims(y = c(0,100)) +
    labs(title = paste0("NEON Observatory AIS RTU Serivce Uptime Overview: ", minCncDate," to ", maxCncDate),
         y = "Percentage", x = "SiteID")
  swft.ais.hornetq.plot <- ggplot(swft.recent.lc.services.ais %>% dplyr::filter(Service == "hornetq"), aes(x = SiteID, y = value, fill = Statistic)) +
    geom_col() +
    scale_fill_manual(values = swft.lcservices.fills) +
    theme(axis.text.x = element_text(angle = 270)) +
    lims(y = c(0,100)) +
    labs(title = paste0("NEON Observatory AIS HornetQ Serivce Uptime Overview: ", minCncDate," to ", maxCncDate),
         y = "Percentage", x = "SiteID")

  eddycopipe::wrap_neon_gcs_upload(x = swft.ais.cnc.plot, object = "CnC/plots/swft.ais.cnc.plot.RDS", bucket = "neon-eddy-inquiry")
  eddycopipe::wrap_neon_gcs_upload(x = swft.ais.rtu.plot, object = "CnC/plots/swft.ais.rtu.plot.RDS", bucket = "neon-eddy-inquiry")
  eddycopipe::wrap_neon_gcs_upload(x = swft.ais.hornetq.plot, object = "CnC/plots/swft.ais.hornetq.plot.RDS", bucket = "neon-eddy-inquiry")

  TotalTime <- (Sys.time()-TotalTime)
  message(Sys.time(), ": LC Service pull lasted ", round(TotalTime), " seconds")
}
