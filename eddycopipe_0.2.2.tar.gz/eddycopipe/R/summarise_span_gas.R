#' @title Function to summarize gas data
#' @description *Must occur after S3 Lookups are refreshed* This function summarize span gas data. This is slower because no data is saved locally, all data is loaded and saved from S3. Reason? Mission to remove as much data from the Home drive, and remove any dependencies on local file storage.
#' @param recreate_master Logical; if you need to recreate the master files for each site use TRUE (takes about an hour). Otherwise, the script will take the pull ammend the most recent file to the master and re-write the master.
#' @export
#' @examples
#' summarise_span_gas(presto_creds = NULL,)
summarise_span_gas = function( recreate_master = FALSE){

  # Required Libraries
  library(dplyr)
  library(data.table)

  ei_bucket = "neon-eddy-inquiry"
  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")

  master_s3 = data.table::as.data.table(eddycopipe::neon_gcs_list_objects(bucket = ei_bucket, prefix = "spanGas/master/"))

  message(paste0(Sys.time(), ": Building fresh S3 span gas lookup"))
  span_file_s3 <- data.table::as.data.table(eddycopipe::neon_gcs_list_objects(bucket = ei_bucket, prefix = "spanGas/", max = Inf)) %>%
    dplyr::rowwise() %>%
    tidyr::separate(col = Key, into = c("Dir","SubDir1"), sep = "/" , remove = FALSE) %>%
    dplyr::filter(Dir == "spanGas" & Size >= 0) %>%
    tidyr::separate(col = SubDir1, into = c("Site", "Date"), sep = "_") %>%
    dplyr::filter(is.na(Date) == FALSE) %>%
    dplyr::mutate(Date = stringr::str_remove(string = Date, pattern = ".fst"))

  if(recreate_master == TRUE){
    message(paste0(Sys.time(), ": Recreating master file from scratch! Sit back and relax..."))
    for(i in siteList$SiteID){
      sites.files = span_file_s3 %>%
        dplyr::filter(Site == i)

      pb <- txtProgressBar(min = 0, max = length(sites.files$Key), style = 3, label = paste0(i))

      data.out = data.table::data.table()
      for(file in seq_along(sites.files$Key)){
        setTxtProgressBar(pb, file)

        data.in = eddycopipe::neon_gcs_get_fst(object = sites.files$Key[file], bucket = ei_bucket)
        data.out = data.table::rbindlist(l = list(data.out, data.in))
      }
      # Save Master Site File
      s3_object_name = paste0("spanGas/master/", i, ".RDS")
      eddycopipe::wrap_neon_gcs_upload(x = data.out, object = s3_object_name, bucket = "neon-eddy-inquiry")
      s3_object_exists = eddycopipe::neon_gcs_object_exists(object_name = s3_object_name, bucket = "neon-eddy-inquiry")
      if(s3_object_exists == TRUE){ message(paste0(Sys.time(), ": \tSaved ", s3_object_name, "..."))} else { stop(paste0(s3_object_name, " data failed to save properly")) }
    }
  }

  if(recreate_master == FALSE){
    message(paste0(Sys.time(), ": Summarising recent data!"))
    for(i in siteList$SiteID){
      # Identify when the last time the site's master RDS was written
      site_s3 = master_s3 %>%
        dplyr::filter(stringr::str_detect(string = Key, pattern = paste0("spanGas/master/", i, ".RDS")) == TRUE)

      last_modified = site_s3$updated

      # Identify the most recent file
      span_site_meta = span_file_s3 %>%
        dplyr::filter(Site == i) %>%
        dplyr::filter(updated > last_modified)

      if(nrow(span_site_meta) >= 1){

        recent_data = data.table::data.table()
        for(Key in base::seq_along(span_site_meta$Key)){
          # Read in the most recent standalone day files
          data_in = eddycopipe::neon_gcs_get_fst(object = span_site_meta$Key[Key], bucket = ei_bucket)

          recent_data = data.table::rbindlist(l = list(recent_data, data_in))
        }
        # Read in the master file
        master_data = eddycopipe::neon_gcs_get_rds(object = paste0("spanGas/master/", i, ".RDS"), bucket = ei_bucket)
        # Combine them together
        master_new = data.table::rbindlist(l = list(master_data, recent_data))
        # Check data
        data_check = nrow(master_new) == nrow(master_data) + nrow(recent_data)

        if(data_check == TRUE){
          # Save the data :)
          message(paste0(Sys.time(), ": Saving ", i))
          eddycopipe::wrap_neon_gcs_upload(x = master_new, object = paste0("spanGas/master/", i, ".RDS"), bucket = "neon-eddy-inquiry")
        } else {
          stop("DATA CHECK FAILED!!!")
        }
      } else {
        message(paste0(Sys.time(), ": ", i, " has no data that needs to be updated."))
      }
    }
  }
}
