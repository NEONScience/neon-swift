#' @title Function to data from S3 bucket
#' @description  This function deletes any object specified in the object field
#' @param object path to object that shall be deleted
#' @param bucket bucket of the object
#' @param s3_creds Character string; research-eddy-inquiry write credentials
#' @export
#' @examples
#' s3_delete(object = "This/Object.fst", bucket = "research-eddy-inquiry", s3_creds = "crazytext17jasldkfj0")
s3_delete = function(object, bucket, s3_creds){

  # S3 Connection
  Sys.setenv("AWS_ACCESS_KEY_ID"     = "research-eddy-inquiry",
             "AWS_SECRET_ACCESS_KEY" = s3_creds,
             "AWS_S3_ENDPOINT"       = "neonscience.org",
             "AWS_DEFAULT_REGION"    = "s3.data")

  does_exist = aws.s3::object_exists(object = object, bucket = bucket)

  if(does_exist == TRUE){
    message(paste0(object, " exists..."))

    aws.s3::delete_object(object = object, bucket = bucket)

    did_delete = aws.s3::object_exists(object = object, bucket = bucket)

    if(did_delete != TRUE){
      message(paste0(object, " deleted..."))
    } else{
      stop(paste0(object, " failed to delete...?"))
    }
  }
}
