# wrap.check_ecte_validation = function(startdate = Sys.Date() - 15, enddate = Sys.Date()){
#   # Required Libaries
#   base::library(dplyr)
#   base::library(data.table)
#
#   available_data = query_avail_sae_data(startdate = startdate, enddate = enddate)
#
#   # Progress bar
#   message(paste0("\nChecking ecte valdations..."))
#   # pb = utils::txtProgressBar(1, nrow(available_data), style = 3)
#   # Empty data table to join to in the for loop :)
#   data_all_out = data.table::data.table()
#   for(i in 1:nrow(available_data)){
#     # utils::setTxtProgressBar(pb, i)
#     data_all_in = check_ecte_validation(query_date = available_data$date[i], siteID = available_data$sites[i], s3_creds = base::readRDS(file = "~/eddy/eddyInquiry/secret.key.RDS"))
#     if(nrow(data_all_in) > 0){
#       data_all_out = data.table::rbindlist(l = list(data_all_out, data_all_in))
#     }
#   }
#   return(data_all_out)
# }
#
#
# system.time(
#   ecte_vali_data_out <- wrap.check_ecte_validation(startdate = Sys.Date()-30, enddate = Sys.Date()-5)
# )
#
# bad_data = test %>% dplyr::filter(thrshPass == FALSE)
# library(ggplot2)
# ggplot(bad_data, aes(x = SiteID, fill = SiteID)) +
#   geom_histogram(stat = "count", position = "stack") +
#   facet_grid(SiteID~Date) +
#   theme(axis.text.x = element_text(colour = "white"))
#
#
# # Filter the good data down to just the bad sites
# bad_sites = unique(as.character(bad_data$SiteID))
#
# bad_sites_data = test %>%
#   dplyr::filter(SiteID %in% bad_sites) %>%
#   dplyr::group_by(SiteID) %>%
#   dplyr::summarise(
#     start_date = min(Date),
#     end_date = max(Date),
#     vali_pass = sum(thrshPass),
#     vali_attemps = length(thrshPass),
#     vali_fail_rate =  round( (vali_attemps - vali_pass) / vali_attemps, 2 ) * 100
#   )
#
#
# # How many days are in the month that do not have a validation within the 9-day planar fit window
# # Plotting for loop for search windows, 1-day, 3-day, 5-day, etc
