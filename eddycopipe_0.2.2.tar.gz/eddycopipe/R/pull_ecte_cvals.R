#' @title Function to pull ecte cvals based upon the ecte cval periods.
#' @description  This function saves ecte cval data and statistics to S3.
#' @param idDp string containing full data product ID for the validation data needed (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param dateBgn date; start of data pull
#' @param dateEnd date; end of data pull
#' @param cval.file file
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param lookup lookup table containing all the sensor names and their dpids
#' @export
#' @examples
#' pull_ecte_cvals()
pull_ecte_cvals = function(idDp, startTime, endTime, CredPsto = NULL, cval.file = NULL, lookup = NULL) {

  # Required Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(tidyr)
  library(here)

  streams = idDp

  # Create site variable
  site = base::substr(streams$streams[1],10,13)

  con = wrap_build_test_presto_connection(CredPsto = CredPsto)

  cval.file = cval.file %>%
    dplyr::distinct()

  for(row in 1:base::nrow(cval.file)){

    message(base::paste0(base::Sys.time(), ": ", site, ":\t", row,"/", base::nrow(cval.file) ," Sensor: ", cval.file$strm_name[row], " ", cval.file$startTime[row]))

    # Create date objects to narrow sql query and also check to see if the data is not corrupt in some way
    dateBgn = base::as.Date(cval.file$startTime[row], format = "%Y-%m-%d")
    dateEnd = base::as.Date(cval.file$endTime[row], format = "%Y-%m-%d")

    # Don't pull data if the dates are not real
    if(is.na(dateBgn) == FALSE & is.na(dateEnd) == FALSE){

      # Code magic to tidy the list of streams into the sql query
      idDpChar=sapply(streams$streams, function(x) paste0("",x,"")) %>%
        paste0(collapse=",") %>%
        as.factor() %>%
        paste0(collapse=",")

      sql = glue::glue_sql("SELECT meas_strm_name, readout_time, readout_val_double
                             FROM readouts
                             WHERE site = {site} and meas_strm_name IN ({idDpChar}) and
                              ds between {dateBgn} and {dateEnd} and
                              readout_time between timestamp {cval.file$startTime[row]} and timestamp {cval.file$endTime[row]}
                             ",
                             .con = con
                             ) %>%

        # This is code magic that painstakingly places all the commas and quotes in the right places
          gsub(pattern = "NEON",replacement = "'NEON") %>%
          gsub(pattern = "0,", replacement = "0',") %>%
          gsub(pattern = "1,", replacement = "1',") %>%
          gsub(pattern = "2,", replacement = "2',") %>%
          gsub(pattern = "3,", replacement = "3',") %>%
          gsub(pattern = "''", replacement = "'") %>%
          gsub(pattern = '""', replacement = '"') %>%
          gsub(pattern = '"approx', replacement = "approx") %>%
          gsub(pattern = '0.95),"', replacement = "0.95),")

      # Form the Query and Send
      res = DBI::dbSendQuery(con, sql)
      mrg.rpt = DBI::dbFetch(res,-1)

      # Join lookup table and summarize data
      daily.ecte.cval = mrg.rpt %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name,15,33)) %>%
        dplyr::left_join(y = lookup, by = "DPID") %>%
        dplyr::mutate(timestamp = lubridate::ymd_hms(readout_time))%>%
        dplyr::group_by(strm_name, timestamp) %>%
        dplyr::summarise(.groups = "drop",
          mean = mean(readout_val_double)
        )

      if(nrow(daily.ecte.cval) > 0){

        s3_object_name = paste0("cval/ecte.cvals.data/", site, "_", "Li7200_", cval.file$startTime[row], "_", cval.file$endTime[row], ".fst") %>% base::gsub(pattern = " ", replacement = "_"  )
        eddycopipe::wrap_neon_gcs_upload(x = daily.ecte.cval, object = s3_object_name, bucket = "neon-eddy-inquiry")
        s3_object_exists = eddycopipe::neon_gcs_object_exists(object_name = s3_object_name, bucket = "neon-eddy-inquiry")
        # Now make stats file
        cval.time.est = daily.ecte.cval %>%
          dplyr::filter(strm_name %in% c("Li7200_MFCValiFlow")) %>%
          dplyr::filter(mean > 1.3) %>%
          dplyr::filter(timestamp %in% c(min(timestamp,na.rm = FALSE),(min(timestamp,na.rm = FALSE)+300), (min(timestamp,na.rm = FALSE)+600),(min(timestamp,na.rm = FALSE)+900),(min(timestamp,na.rm = FALSE)+1200))) %>%
          tibble::rowid_to_column() %>%
          dplyr::mutate(vali_componet = if_else(rowid %in% c(1), "Zero", if_else(rowid %in% c(2), "Low", if_else(rowid %in% c(3), "Int", if_else(rowid %in% c(4), "High", "NA")))))

        zero.start = cval.time.est$timestamp[1]
        low.start = cval.time.est$timestamp[2]
        int.start = cval.time.est$timestamp[3]
        high.start = cval.time.est$timestamp[4]

        swiftCylAssay = eddycopipe::neon_gcs_get_fst(object = "lookup/spanGasConc.fst", bucket = "neon-eddy-inquiry") %>%
          reshape2::dcast(date + siteID ~ name, value.var = "conc") %>%
          dplyr::select(date,siteID,`ECSE-LOW`,`ECSE-MEDIUM`,`ECSE-HIGH`,`ECSE-Archive`,`ECTE-LOW`,`ECTE-MEDIUM`,`ECTE-HIGH`,`ECTE-Archive`) %>%
          dplyr::filter(siteID == site) %>%
          dplyr::filter(date == max(date, na.rm = TRUE))

        cval.zero.co2 = daily.ecte.cval %>%
          dplyr::filter(timestamp > zero.start + 150 & timestamp < low.start) %>%
          dplyr::filter(strm_name == "Li7200_CO2") %>%
          dplyr::summarise(
            vali.comp = "Zero",
            date = zero.start,
            mean.co2 = mean(mean, na.rm = TRUE),
            expected = 0,
            diff.from.expected = abs(expected - mean.co2)
          )

        cval.low.co2 = daily.ecte.cval %>%
          dplyr::filter(timestamp > low.start + 150 & timestamp < int.start) %>%
          dplyr::filter(strm_name == "Li7200_CO2") %>%
          dplyr::summarise(
            vali.comp = "Low",
            date = zero.start,
            mean.co2 = mean(mean, na.rm = TRUE),
            expected = swiftCylAssay$`ECTE-LOW`,
            diff.from.expected = abs(expected - mean.co2)
          )

        cval.int.co2 = daily.ecte.cval %>%
          dplyr::filter(timestamp > int.start + 150 & timestamp < high.start) %>%
          dplyr::filter(strm_name == "Li7200_CO2") %>%
          dplyr::summarise(
            vali.comp = "Int",
            date = zero.start,
            mean.co2 = mean(mean, na.rm = TRUE),
            expected = swiftCylAssay$`ECTE-MEDIUM`,
            diff.from.expected = abs(expected - mean.co2)
          )

        cval.high.co2 = daily.ecte.cval %>%
          dplyr::filter(timestamp > high.start + 150 & timestamp < high.start + 300) %>%
          dplyr::filter(strm_name == "Li7200_CO2") %>%
          dplyr::summarise(
            vali.comp = "High",
            date = zero.start,
            mean.co2 = mean(mean, na.rm = TRUE),
            expected = swiftCylAssay$`ECTE-HIGH`,
            diff.from.expected = abs(expected - mean.co2)
          )

        cval.comps = data.table::rbindlist(l = list(cval.zero.co2, cval.low.co2, cval.int.co2, cval.high.co2))

        s3.stats.file = s3_object_name %>% gsub(pattern = ".fst", replacement = ".RDS") %>% gsub(pattern = "ecte.cvals.data", replacement = "li7200.stats")
        eddycopipe::wrap_neon_gcs_upload(x = cval.comps, object = s3.stats.file, bucket = "neon-eddy-inquiry")
        s3_object_exists = eddycopipe::neon_gcs_object_exists(object_name = s3.stats.file, bucket = "neon-eddy-inquiry")
        if(s3_object_exists == TRUE){} else { message(paste0(Sys.time(), ": ", site, " file failed!"))}

      } else {
        message(paste0(Sys.time(), ": no rows..."))
      }
    } else {
      message(paste0(Sys.time(), ": date bad"))
    }
  }
  DBI::dbDisconnect(con)
}
