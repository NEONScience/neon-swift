#' @title Wrapper function to pull all ecse cval periods.
#' @description  This function pulls ecse cval period data based upon validation valves status.
#' @param presto_creds Character string; your presto credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' wrap.ecse.cval.periods()
wrap_ecse_cval_periods = function(presto_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify s3_creds: Sys.Date()-1")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)

  ei_bucket = "neon-eddy-inquiry"
  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
      dplyr::filter(Type == "TIS")

  wrap_pull_ecse_cval_periods <- function(i, start, stop){

    sensor_names = eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket) %>%
      dplyr::filter(strm_name %in% c("G2131_Validation_Valve","L2130_Validation_Valve","Li840_Validation_Valve")) %>%
      dplyr::mutate(DPID = base::trimws(base::substr(DPID, 1, 19)))

    site_streams = compose_L0_matrix(site = i)

    valve_list = c(
      "DP0.00113.001.02368.703.000.000", # L2130i Validation Valve, only opens (1) when analyzer is validating.
      "DP0.00114.001.02361.700.000.000", # G2131i Validation Valve
      "DP0.00114.001.02364.700.000.000"  # Li-840 Validation Valve
    )

    # Limit Streams by EC related streams
    streams <- site_streams %>%
      dplyr::filter(DPJoin %in% valve_list)

    pull_ecse_cval_periods(
      idDp           = streams,
      dateBgn        = start,
      dateEnd        = stop + 1,
      CredPsto       = presto_creds,
      sensor_names   = sensor_names
    )
  }

  start <- Sys.time()
  for(i in siteList$SiteID){
    start1 <- Sys.time()
    try(
      wrap_pull_ecse_cval_periods(
        i     = i,
        start = pull_date,
        stop  = pull_date
      )
    )
    end1 <- Sys.time()
    message(paste0(Sys.time(), ": ", i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
  }
  end <- Sys.time()

  message(paste0(Sys.time(), ": Total ecse cval period pull  time ", round(difftime(end, start, units = "min"),2), " minutes"))
}
