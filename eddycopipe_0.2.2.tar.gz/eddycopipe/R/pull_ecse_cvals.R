#' @title Function to pull ecse cvals based upon the ecse cval periods.
#' @description  This function saves ecse cval data and statistics to S3.
#' @param idDp string containing full data product ID for the validation data needed (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param dateBgn date; start of data pull
#' @param dateEnd date; end of data pull
#' @param cval.file file
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param lookup lookup table containing all the sensor names and their dpids
#' @export
#' @examples
#' pull_ecse_cvals()
pull_ecse_cvals = function(idDp, startTime, endTime, CredPsto = NULL, cval.file = NULL, lookup = NULL) {

  # Required Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(tidyr)
  library(here)

  streams = idDp

  # Create site variable
  site = base::substr(streams$streams[1],10,13)

  idDp = base::as.vector(idDp$streams)

  con = wrap_build_test_presto_connection(CredPsto = CredPsto)

  # Stream formatting:
  idDpChar=sapply(idDp, function(x) paste0("",x,"")) %>%
    paste0(collapse=",") %>%
    as.factor() %>%
    paste0(collapse=",")


  cval.file.copy = cval.file

  for(row in 1:nrow(cval.file)){

    message(paste0(Sys.time(),": ", site, ":\t", row,"/",nrow(cval.file) ," Sensor: ", cval.file.copy$strm_name[row]," ",cval.file.copy$startTime[row]))

    if(cval.file.copy$strm_name[row] == "Li840_Validation_Valve"){
        # Filter down the steams based upon the validation/calibration we are pulling
      streams.pull = streams %>%
        dplyr::filter(DPJoin %in% c("DP0.00107.001.01951.700.000.000", # ECSE Vali MFC
                                    "DP0.00106.001.01951.700.000.000", # Li-840 Samp MFC
                                    "DP0.00105.001.02316.700.000.000", # Li-840 Co2
                                    "DP0.00105.001.02348.700.000.000", # Li-840 H2o
                                    "DP0.00105.001.02350.700.000.000", # Li-840 Cell Pressure
                                    "DP0.00105.001.02349.700.000.000", # Li-840 Cell Temperature
                                    "DP0.00102.001.02316.700.000.000", # G2131i Co2 fwmole
                                    "DP0.00114.001.02361.700.000.000", # G2131 Validation Valve
                                    "DP0.00114.001.02364.700.000.000", # Li840 Validation Valve
                                    "DP0.00114.001.02362.700.000.000", # Li840 Vent Valve
                                    "DP0.00113.001.02361.703.000.000", # ECSE Low
                                    "DP0.00113.001.02362.703.000.000", # ECSE Med
                                    "DP0.00113.001.02364.703.000.000", # ECSE High
                                    "DP0.00113.001.02365.703.000.000", # ECSE Archive
                                    "DP0.00113.001.02366.703.000.000"  # ECSE Co2 Zero
                                    ))

      # Create a portion of file name for later
      file.name = "Li840A"

      # Li840's need a 10 minute buffer
      cval.file = cval.file.copy %>%
        dplyr::mutate(startTime = startTime - 360) %>%
        dplyr::mutate(endTime = endTime + 360)
    }
    if(cval.file.copy$strm_name[row] == "G2131_Validation_Valve"){
      # Filter down the steams based upon the validation/calibration we are pulling
      streams.pull = streams %>%
        dplyr::filter(DPJoin %in% c("DP0.00107.001.01951.700.000.000", # ECSE Vali MFC
                                    "DP0.00102.001.02316.700.000.000", # G2131i Co2 wet
                                    "DP0.00102.001.02317.700.000.000", # G2131i 12Co2 wet
                                    "DP0.00102.001.02319.700.000.000", # G2121i 13Co2 wet
                                    "DP0.00105.001.02316.700.000.000", # Li-840 Co2
                                    "DP0.00114.001.02361.700.000.000", # G2131 Validation Valve
                                    "DP0.00114.001.02364.700.000.000", # Li840 Validation Valve
                                    "DP0.00113.001.02361.703.000.000", # ECSE Low
                                    "DP0.00113.001.02362.703.000.000", # ECSE Med
                                    "DP0.00113.001.02364.703.000.000", # ECSE High
                                    "DP0.00113.001.02365.703.000.000", # ECSE Archive
                                    "DP0.00113.001.02366.703.000.000"  # ECSE Co2 Zero
                                  ))

      # Create a portion of file name for later
      file.name = "G2131i"

      # G2131's need a 10 minute buffer
      cval.file = cval.file.copy %>%
        dplyr::mutate(startTime = startTime - 360) %>%
        dplyr::mutate(endTime = endTime + 360)
    }
    if(cval.file.copy$strm_name[row] == "L2130_Validation_Valve"){
      # Filter down the steams based upon the validation/calibration we are pulling
      streams.pull = streams %>%
        dplyr::filter(DPJoin %in% c("DP0.00107.001.01951.700.000.000", # ECSE Vali MFC
                                    "DP0.00103.001.02369.700.000.000", # L2130i d18OWater
                                    "DP0.00103.001.02370.700.000.000", # L2130i d2HWater
                                    "DP0.00103.001.02339.700.000.000", # L2130i h2o ppt
                                    "DP0.00113.001.02368.703.000.000"  # L2130i Zero Air Valve Status
        )
        )

      # Create a portion of file name for later
      file.name = "L2130i"

      # Li2130's have a 60 minute buffer
      cval.file = cval.file.copy %>%
        dplyr::mutate(startTime = startTime - 3600) %>%
        dplyr::mutate(endTime = endTime + 3600)

    }

    # Create date objects to narrow sql query and also check to see if the data is not corrupt in some way
    dateBgn = as.Date(cval.file$startTime[row], format = "%Y-%m-%d")
    dateEnd = as.Date(cval.file$endTime[row], format = "%Y-%m-%d")

    # Don't pull data if the dates are not real
    if(is.na(dateBgn) == FALSE & is.na(dateEnd) == FALSE){

      # Code magic to tidy the list of streams into the sql query
      idDpChar=sapply(streams.pull$streams, function(x) paste0("",x,"")) %>%
        paste0(collapse=",") %>%
        as.factor() %>%
        paste0(collapse=",")

      sql = glue::glue_sql("SELECT meas_strm_name, readout_time, readout_val_double
                           FROM readouts
                           WHERE site = {site} and meas_strm_name IN ({idDpChar}) and
                            ds between {dateBgn} and {dateEnd} and
                            readout_time between timestamp {cval.file$startTime[row]} and timestamp {cval.file$endTime[row]}
                           ",
                           .con = con
      ) %>%
        # This is code magic that painstakingly places all the commas and quotes in the right places
        gsub(pattern = "NEON",replacement = "'NEON") %>%
        #add single quotation before coma:
        gsub(pattern = "0,", replacement = "0',") %>%
        gsub(pattern = "1,", replacement = "1',") %>%
        gsub(pattern = "2,", replacement = "2',") %>%
        gsub(pattern = "3,", replacement = "3',") %>%
        #replace the initial dbl, single quote at the start of the meas_strm_name IN:
        gsub(pattern = "''", replacement = "'") %>%
        gsub(pattern = '""', replacement = '"') %>%
        gsub(pattern = '"approx', replacement = "approx") %>%
        gsub(pattern = '0.95),"', replacement = "0.95),")

      # Form the Query
      res = DBI::dbSendQuery(con, sql)
      # Actually pull the data
      mrg.rpt= DBI::dbFetch(res,-1)

      # Join lookup table and summarize data
      daily.ecse.cval = mrg.rpt %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name,15,550)) %>%
        dplyr::left_join(y = lookup, by = "DPID")
      rm(mrg.rpt)

      if(nrow(daily.ecse.cval) > 0){

        s3_object_name = paste0("cval/ecse.cvals.data/", site, "_", file.name, "_", cval.file$startTime[row], "_", cval.file$endTime[row], ".fst") %>% base::gsub(pattern = " ", replacement = "_"  )

        eddycopipe::wrap_neon_gcs_upload(x = daily.ecse.cval, object = s3_object_name, bucket = "neon-eddy-inquiry")
        s3_object_exists = eddycopipe::neon_gcs_object_exists(object_name = s3_object_name, bucket = "neon-eddy-inquiry")

        if(s3_object_exists == TRUE){} else { message(paste0(Sys.time(), ": ", site, " file failed!"))}

      } else {
        message(paste0(Sys.time(),": no rows..."))
      }
      rm(file.name)
    } else {
      message(paste0(Sys.time(),": date bad"))
    }
  }
  DBI::dbDisconnect(con)
}
