#' @title Function that takes a data.table and a file path and then saves it to S3
#' @description tdb
#' @export
#' @examples
#'  tbd
ei_save_S3 = function(prefix = "2min", file_extension = FALSE, dataTable = FALSE, site = FALSE, dateBgn = FALSE, percentage = FALSE, compression = compression){
  s3_object_name <- paste0(prefix,"/", site, "/", site, "_", dateBgn, file_extension)
  eddycopipe::wrap_neon_gcs_upload(x = dataTable, object = s3_object_name, bucket = "neon-eddy-inquiry")
  s3_object_exists = eddycopipe::neon_gcs_object_exists(object_name = s3_object_name, bucket = "neon-eddy-inquiry")
  if(s3_object_exists == TRUE){ message(paste0(Sys.time(),": ", percentage,"%:  Saved ", s3_object_name, "..."))} else { stop(paste0(s3_object_name, " data failed to save properly")) }
}
