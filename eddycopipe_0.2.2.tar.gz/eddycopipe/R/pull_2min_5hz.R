#' @title Pull all 5hz 2min eddyInquiry Data
#' @description  Presto Pull for 2 minute data points
#' @param idDp string containing full data product ID (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param dateBgn date; start of data pull
#' @param dateEnd date; end of data pull
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param CredS3 character; vector containing your s3 credentials, randomlettersandnumbers
#' @param everyMinute numeric; you want data every 2 min, 2. Every 5 min, 5. etc
#' @param compression specify compression for files saved to S3
#' @export
#' @examples
#' wrap.2min.1hz()
pull_2min_5hz = function(idDp, dateBgn, dateEnd, CredPsto = NULL, sensor_names = NULL, everyMinute = 2, compression = 50) {

  # Required Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(tidyr)
  library(here)

  # Check that Date Range is only 1 day, if != 1, do not run!
  if(as.Date(dateEnd) - as.Date(dateBgn) < 507){

    # Determine the site
    site=unique(substr(idDp,10,13))

    # Build and test connection
    con = wrap_build_test_presto_connection(CredPsto = CredPsto)

    # Stream formatting:
    idDpChar=sapply(idDp, function(x) paste0("",x,"")) %>%
      paste0(collapse=",") %>%
      as.factor() %>%
      paste0(collapse=",")

    # Sql query
    sql = glue::glue_sql("SELECT
                            meas_strm_name, readout_time, readout_val_double
                           FROM
                            readouts
                           WHERE
                            site = {site} and
                            meas_strm_name IN ({idDpChar}) and
                            ds between {dateBgn} and {dateEnd} and
                            MINUTE(readout_time) % {everyMinute} = 0 and SECOND(readout_time) <= 9
                           ",
                           .con = con
                           )%>%
        # The stuff below is some magic to format the string of streams juuust right
        gsub(pattern = "NEON",replacement = "'NEON") %>%
        gsub(pattern = "0,", replacement = "0',") %>%
        gsub(pattern = "1,", replacement = "1',") %>%
        gsub(pattern = "2,", replacement = "2',") %>%
        gsub(pattern = "3,", replacement = "3',") %>%
        gsub(pattern = "''", replacement = "'") %>%
        gsub(pattern = '""', replacement = '"') %>%
        gsub(pattern = '"approx', replacement = "approx") %>%
        gsub(pattern = '0.95),"', replacement = "0.95),")

    start=Sys.time()

    # Send the Query
    res = DBI::dbSendQuery(con, sql)
    message(paste0(Sys.time(), ": 14%: ",site, " from ", dateBgn, " to ", dateEnd))
    # Actually grab the data from the query
    mrg.rpt= DBI::dbFetch(res,-1)

    base::message(Sys.time(), ": 21%: Pull finished...")
    # Disconnect from the DB like a good neighbor
    DBI::dbDisconnect(con)
    base::message(Sys.time(), ": 28%: Disconnected from Presto...")

    # Time calculations
    end = Sys.time()
    elapsed = difftime(end, start, units = "secs")
    message(paste0(Sys.time(), ": 37%: Pull lasted: ",round(elapsed,3)," seconds..."))

    # If there is data in the pull tidy the data a little, and then save it appropriately
    if(nrow(mrg.rpt) > 0){

      mrg.rpt = data.table::as.data.table(mrg.rpt) %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name, start = 15, stop = 100)) %>% # Create a mutual column to join the Sensor Names lookup table to
        dplyr::mutate(DPID = base::trimws(DPID, which = "both")) %>%
        dplyr::mutate(SiteID = site)

      # Join the lookup table and raw 2 minute data, giving all the streams human readible names
      mrg.rpt.out = dplyr::left_join(x = mrg.rpt, y = sensor_names, by = "DPID")
      rm(mrg.rpt)

      # Turn into a data.table for faster processing
      mrg.rpt.distinct = mrg.rpt.out

      rm(mrg.rpt.out)
      # Get a list of all the unique data streams we just pulled
      listOfStreamNames = as.data.frame(sort(unique(mrg.rpt.distinct$strm_name)))
      names(listOfStreamNames) = "strm_name"

      # Li840
      if(nrow(mrg.rpt.distinct) > 0){

        # Create lists for file saves!
        ecse.li840.streams  = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "840") == TRUE)
        ecse.pump.streams   = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "PumpVoltage") == TRUE)
        ecte.valves.streams = listOfStreamNames %>% dplyr::filter(stringr::str_detect(strm_name, pattern = "ECTE_") == TRUE)

        # ECSE Pumps
        if(nrow(ecse.pump.streams) > 0){
          ecse.pump.data = mrg.rpt.distinct %>%
            dplyr::filter(stringr::str_detect(strm_name, pattern = "PumpVoltage") == TRUE) %>%
            dplyr::mutate(by15 = cut(readout_time, breaks = "2 min")) %>%
            dplyr::group_by(SiteID, strm_name, by15) %>%
            dplyr::summarise(.groups = "drop",
              mean = mean(readout_val_double, na.rm = TRUE)
            ) %>%
            dplyr::mutate(by15 = lubridate::ymd_hms(by15))

          # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
          ei_save_S3(file_extension = "_ecse.voltage.fst", dataTable = ecse.pump.data, site = site, dateBgn = dateBgn, percentage = "49", compression = compression)
          rm(ecse.pump.data)

        } else {
          message(paste0(Sys.time(), ": 49%: Not Saving ECSE Pump Voltage Data..."))
        }
        # Li840a Valves
        if(nrow(ecse.li840.streams) > 0){
          li840.valve.data = mrg.rpt.distinct %>%
            dplyr::filter(stringr::str_detect(strm_name, pattern = "840") == TRUE) %>%
            dplyr::filter(stringr::str_detect(strm_name, pattern = "Valve") == TRUE)

          if(nrow(li840.valve.data) > 100){
            li840_valve_data = li840.valve.data %>%
              dplyr::mutate(readout_time = cut(readout_time, breaks = "2 min")) %>%
              dplyr::group_by(SiteID, DPID, strm_name, readout_time) %>%
              dplyr::summarise(.groups = "drop",
                readout_val_double = mean(readout_val_double, na.rm = TRUE)
              ) %>%
              dplyr::mutate(readout_time = lubridate::ymd_hms(readout_time))

            # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
            ei_save_S3(file_extension = "_Li840.valves.fst", dataTable = li840_valve_data, site = site, dateBgn = dateBgn, percentage = "63", compression = compression)
            rm(li840_valve_data)
          } else {
            message(paste0(Sys.time(), ": 63%: Not Saving Li840 Valve Data..."))
          }
          # Remove data
          rm(li840.valve.data)
        } else {
          message(paste0(Sys.time(), ": 63%: Not Saving Li840 Valve Data..."))
        }
        # ECTE Valves
        if(nrow(ecte.valves.streams) > 0){

          ecte.valves.data = mrg.rpt.distinct %>%
            dplyr::filter(stringr::str_detect(strm_name, pattern = "ECTE_") == TRUE)

          if(nrow(ecte.valves.data) > 100){
            ecte_valves_data = ecte.valves.data %>%
              dplyr::mutate(readout_time = cut(readout_time, breaks = "2 min")) %>%
              dplyr::group_by(SiteID, DPID, strm_name, readout_time) %>%
              dplyr::summarise(.groups = "drop",
                readout_val_double = mean(readout_val_double, na.rm = TRUE)
              ) %>%
              dplyr::mutate(readout_time = lubridate::ymd_hms(readout_time))

            # Create s3 object name, save data to S3, rm from local enviro to clear up RAM
            ei_save_S3(file_extension = "_Li7200.valves.fst", dataTable = ecte_valves_data, site = site, dateBgn = dateBgn, percentage = "84", compression = compression)
            rm(ecte_valves_data)

          } else {
            message(paste0(Sys.time(), ": 84%: Not Saving Li7200 Valve Data..."))
          }
          # Remove data
          rm(ecte.valves.data)
        } else {
          message(paste0(Sys.time(), ": 84%: Not Saving Li7200 Valve Data..."))
        }

      } else {
        message(paste0(Sys.time(), ": No data in pull after distinction: ", site))
      }
    } else {
      message(paste0(Sys.time(), ": No data in pull before distinction: ", site))
    }
  } else{
    message(paste0(Sys.time(), ": The Date Range is greater than 11!!! Date Range:", as.Date(dateEnd)-as.Date(dateBgn)))
  }
}
