#' @title Wrapper to pull a day's ecte cvals
#' @description  This function pairs with pull.ecte.cvals to pull data from Presto and save it to S3
#' @param presto_creds Character string; your preso credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' wrap_ecte_cvals(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
wrap_ecte_cvals = function(presto_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify pull_date: Sys.Date()-1")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)
  library(here)

  ei_bucket = "neon-eddy-inquiry"

  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")

  # Sensor Names, This list is used to limit streams to only DPID's I have named in this SensorNames Lookup table
  sensor_names <- eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket) %>%
    dplyr::mutate(DPID = base::trimws(base::substr(DPID, 1, 19)))

  wrap.pull.ecte.cvals <- function(site, start, stop, sensor_names){

    site_streams = compose_L0_matrix(
      site = i
    )

    # If we're on the prod linux server (ie linux) we will pull the period data from local storage (very small files so no worries on excessive storage issues)
    system_os_type = Sys.info()['sysname']
    if(system_os_type == "Linux"){
      list.periods = data.table::data.table(files = list.files(path = "~/eddyInquiry/data/cval/ecte.cval.periods.data/", pattern = site, full.names = TRUE)) %>%
        tidyr::separate(col = files, into = c("1","2","3","4","5","6","7","8","9","10"), sep = "/", remove = FALSE) %>% dplyr::select(files, `10`) %>%
        tidyr::separate(col = `10`, into = c("site","num","start","stop"), sep = "_") %>% dplyr::select(files, start) %>%
        dplyr::filter(start == pull_date)

      if(nrow(list.periods) == 0){
        list.periods = eddycopipe::neon_gcs_get_rds(object = "s3.lookup/ecte.cval.periods.meta.RDS", bucket = ei_bucket) %>%
          dplyr::filter(StartDate == pull_date) %>%
          dplyr::filter(SiteID == site)
          system_os_type = "Windows"
      }

    } else if(system_os_type == "Windows"){
      # Read in all the cvals periods for site
      list.periods = eddycopipe::neon_gcs_get_rds(object = "s3.lookup/ecte.cval.periods.meta.RDS", bucket = ei_bucket) %>%
        dplyr::filter(StartDate == pull_date) %>%
        dplyr::filter(SiteID == site)
    } else {
      wrong_system = system_os_type
      stop(paste0("Sys.info()['sysname'] = ", wrong_system,", was not recognized [1]..."))
    }

    if(nrow(list.periods) > 0){

      ecte.period.dt = data.table::data.table()
      if(system_os_type == "Linux"){
        for(i in 1:length(list.periods$files)){
          data.in = readRDS(file = list.periods$files[i])
          ecte.period.dt = data.table::rbindlist(l = list(ecte.period.dt, data.in))
        }
      } else if(system_os_type == "Windows"){
        for(i in 1:length(list.periods$Key)){
          data.in = eddycopipe::neon_gcs_get_rds(object = list.periods$Key[i], bucket = ei_bucket)
          ecte.period.dt = data.table::rbindlist(l = list(ecte.period.dt, data.in))
        }
      } else {
        wrong_system = system_os_type
        stop(paste0("Sys.info()['sysname'] = ", wrong_system,", was not recognized [2]..."))
      }

      streams.list <- c("DP0.00012.001.01951", # Li-7200 Vali MFC Flow
                        "DP0.00015.001.01951", # Li-7200 Vali MFC Flow
                        "DP0.00016.001.02181", # Li-7200 Pressure Diff
                        "DP0.00016.001.02191", # Li-7200 Co2
                        "DP0.00008.001.02199"  # Li-7200 Leak Check Valve
      )

      # Limit Streams by EC related streams
      streams <- site_streams %>%
        dplyr::filter(DPcrispy %in% streams.list)%>%
        dplyr::distinct()

      if(nrow(ecte.period.dt) > 0){

        try(
          pull_ecte_cvals(
            cval.file = ecte.period.dt,
            idDp      = streams,
            startTime = start,
            endTime   = stop,
            CredPsto  = presto_creds,
            lookup    = sensor_names
          )
        )
      } else {
        message(paste0(Sys.time(), ": ", i, " has no cval data for date(s): ", start, " - ",stop))
      }
    } else {
      message(paste0(Sys.time(), ": ", i, " has no cval data for date(s): ", start, " - ",stop))
    }
  }

  start <- Sys.time()
  for(i in siteList$SiteID){
    start1 <- Sys.time()
    wrap.pull.ecte.cvals(site = i, start = pull_date, stop = pull_date + 1, sensor_names = sensor_names)
    end1 <- Sys.time()
    message(paste0(Sys.time(), ": ",i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
  }
  end <- Sys.time()
  message(paste0(Sys.time(), ": Total ecte calval pull time ", round(difftime(end,start,units = "min"),2), " minutes"))
}
