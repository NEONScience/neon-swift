#' @title Get the latest Fulcrum Data for the TIS Maintenance App
#' @description WARNING this is not pretty
#' @param supersecreturl character string; url to fulcrum share
#' @param sites vector of sites or "ALL"
#' @export
#' @examples
#' clean_span_gas_data(s3_creds = 'AsDF32FEwFOi42DMF23M')
get_latest_fulcrum_data = function(supersecreturl = "https://web.fulcrumapp.com/shares/829c6b0796341089.csv",sites = "ALL"){
  if(is.null(supersecreturl) == TRUE){
    stop("Please specify the super secret url to the TIS maintenance app (hint: Fulcrum data shares)")
  }

  # Libraries
  library(utils)
  library(data.table)
  library(dplyr)

  ei_bucket = "neon-eddy-inquiry"
  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")

  # Download File
  utils::download.file(url = supersecreturl, destfile = paste0(tempdir(),"/data.csv"), quiet = TRUE)
  # Read Data from File
  data = data.table::fread(paste0(tempdir(),"/data.csv"))
  # Remove File
  base::file.remove(paste0(tempdir(),"/data.csv"))
  # Save to S3
  eddycopipe::wrap_neon_gcs_upload(x = data, object = "maintenance_app/all_data.fst", bucket = "neon-eddy-inquiry")
}
