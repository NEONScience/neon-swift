#' @title Check ecte validation slopes
#' @description tdb
#' @param query_date string, date of validation you'd liike to check, format: YYYY-MM-DD
#' @export
#' @examples
#'  tbd
get_avg_eddy_bundled = function(query_date = NULL, siteID = NULL, s3_creds = NULL, lookup = NULL){

  # Check args are proper
  if(is.null(query_date) == TRUE){
    stop("Please specify date... ie. '2021-02-09'")
  }
  if(is.null(siteID) == TRUE){
    stop("Please specify site... ie. 'CPER' ")
  }
  if(is.null(s3_creds) == TRUE){
    stop("Please s3 write creds to research-eddy-inquiry... ")
  }
  if(is.null(lookup) == TRUE){
    stop("Please give us this s3 file: lookup/swft.full.site.lookup.RDS  ")
  }

  # Location to download and unzip files for reading in
  if(Sys.info()["sysname"] == "Windows" & Sys.info()["user"] == "kstyers"){
    save_dir = "C:/Users/kstyers/AppData/Local/Temp/"
  } else if(Sys.info()["sysname"] == "Linux"){
    save_dir = "/tmp/"
  } else {
    stop("If you are using windows, you can not run this funtion. Otherwise you'll have to debug :)")
  }

  # Required Libraries
  base::library(aws.s3)
  base::library(aws.signature)
  base::library(dplyr)
  base::library(data.table)
  base::library(rhdf5)

  # Create domain variable
  domain_dt = lookup %>%
    dplyr::filter(SiteID == siteID)
  domain = domain_dt$Domain

  # Check for data availability given the date entered
  # base::source(here::here("R/check_sae_data_avail.R"))
  data_available = check_sae_data_avail(query_date = query_date, data_product_level = "IP4", return_data = TRUE)

  keys_available = data_available[[2]]

  if(nrow(keys_available) > 0){
    site_data_available = keys_available %>%
      dplyr::filter(site == siteID)

    if(nrow(site_data_available) > 0){
      site_ecte_exp_available = site_data_available %>%
        dplyr::filter(file == paste0("NEON.", domain,".", siteID, ".IP4.00200.001.ecse.", query_date,".expanded.h5.gz"))

      if(nrow(site_ecte_exp_available) == 1){

        # Check if the file has already been downloaded
        file_name.h5.gz = paste0(save_dir, base::substr(site_ecte_exp_available$Key[1], 38, 100)) # Create file name
        if(base::file.exists(file_name.h5.gz) == FALSE){
          # Download expanded file to temp dir
          utils::download.file(url = paste0("https://neon-sae-files.s3.data.neonscience.org/", site_ecte_exp_available$Key[1]),
                               destfile = file_name.h5.gz, quiet = TRUE)
        }

        # Check if the file's already been unzipped
        file_name.h5 = base::gsub(x = file_name.h5.gz, pattern = ".gz", replacement = "") # Create file name
        if(base::file.exists(file_name.h5) == FALSE){
          # Unzip the file
          R.utils::gunzip(file_name.h5.gz)
        }

        # List all the data available in the file we downloaded
        saved_file.ls = rhdf5::h5ls(file = file_name.h5, datasetinfo = FALSE)

        # Create list of variables we need to pull
        groups_to_save = c(paste0("/", siteID, "/dp01/data/isoCo2/000_010_30m"), paste0("/", siteID, "/dp01/data/isoH2o/000_010_30m"))
        names_to_save = c("rtioMoleWetH2o", "rhEnvHut", "tempEnvHut")

        # Filter the list of available data to just the streams we need
        streams_to_save = saved_file.ls %>%
          dplyr::filter(group %in% groups_to_save) %>%
          dplyr::filter(name %in% names_to_save) %>%
          tidyr::unite(col = "h5_path", c("group", "name"), sep = "/")

        # Pull out and join the data we need from the h5 file
        data_out = data.table::data.table()
        for(streams in 1:nrow(streams_to_save)){
          # Grab the units
          units = rhdf5::h5readAttributes(file = file_name.h5, name = streams_to_save$h5_path[streams])
          # Grab the data
          data_in = rhdf5::h5read(file = file_name.h5, name = streams_to_save$h5_path[streams]) %>%
            dplyr::mutate(full_path = streams_to_save$h5_path[streams]) %>%
            dplyr::select(full_path, timeBgn, mean, numSamp) %>%
            dplyr::mutate(timeBgn = lubridate::ymd_hms(timeBgn)) %>%
            dplyr::mutate(units = units$unit[1])
          # Join the data together
          data_out = data.table::rbindlist(l = list(data_out, data_in))
        }

        # Delete zip and  unzipped files
        base::file.remove(file_name.h5)

        # Reset S3 Connection access
        Sys.unsetenv("AWS_SECRET_ACCESS_KEY")
        # S3 Connection
        Sys.setenv("AWS_ACCESS_KEY_ID"     = "research-eddy-inquiry",
                   "AWS_SECRET_ACCESS_KEY" = s3_creds,
                   "AWS_S3_ENDPOINT"       = "neonscience.org",
                   "AWS_DEFAULT_REGION"    = "s3.data")

        # Export file to S3
        aws.s3::s3saveRDS(x = data_out, object = paste0("hut_temp_investigation/eddy_data/", siteID, "/", siteID, "_", query_date, ".RDS"), bucket = "research-eddy-inquiry" )
        message(paste0("Saving file: ", paste0("hut_temp_investigation/eddy_data/", siteID, "/", siteID, "_", query_date, ".RDS")))
        base::rm(data_out, data_in)

      } else {
        message(paste0(siteID, "'s expanded ecte files not found"))
      }
    } else {
      message(paste0(siteID, "'s did not return any data"))
    }
  } else {
    message("Data was not found for any site!!!")
  }
}



