##############################################################################################
#' @title GCS - upload any file to the Google Cloud
#'
#' @author Kevin Styers
#'
#' @description This takes your R object and saves it up to the cloud. Currently supports `.rds` and `.fst`
#'
#' @details To accomplish this functions goals it relies on helper functions to properly store the data: gcs_save_rds and gcs_save_fst
#'
#' @param x an R object to upload
#' @param bucket the name of the bucket to upload to
#' @param object the name of the object (or the path) in the cloud to read
#'
#' @return the .fst table in the cloud
#'
#' @examples
#' test_data = mtcars
#' wrap_neon_gcs_upload(x = test_data, bucket = "myCoolBucket", object = "mtcars.fst")
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-24)
#     original creation
##############################################################################################
wrap_neon_gcs_upload = function(x = NULL, bucket = NULL, object = NULL){

  if(base::is.null(x) | base::is.null(bucket) | base::is.null(object)){
    stop("One of the required args is not specified, please check our code and try again.")
  }

  # Required Libraries
  library(tools)
  library(googleCloudStorageR)

  # Check what type of file
  file_type = base::tolower(tools::file_ext(object))

  if(file_type == "rds"){
    object_function = eddycopipe::neon_gcs_save_rds
  } else if(file_type == "fst"){
    object_function = eddycopipe::neon_gcs_save_fst
  } else if(file_type == "r"){
    base::stop("not method for R files")
  } else {
    base::stop(base::paste0("File type not supported: ", file_type))
  }

  # Upload object
  base::try(
    googleCloudStorageR::gcs_upload(file = x, bucket = bucket, name = object, predefinedAcl = "bucketLevel", object_function = object_function)
  )

}
