#' @title Wrapper to pull published eddy and save it to S3
#' @description This function utlizes pull_eddy_data and save_small_eddy_s3
#' @param start character or date; start date for your query, format = YYYY-MM-DD
#' @param end character or date; end date for your query, format = YYYY-MM-DD
#' @param s3_creds character your s3 write creds for research-eddy-inquiry
#' @param overwrite logical should we overwrite the s3 data
#' @return Returns nothing, but does message a bit
#' @export
#' @examples
#' wrap_eddy_pull(start = "2021-01-01, end = "2021-01-07, s3_creds = base::readRDS("path/to/my/creds.RDS"))
wrap_eddy_pull = function(start, end, prod, s3_creds, overwrite){
  if(is.null(s3_creds) == TRUE){stop("specify s3 creds to write to research-eddy-inquiry")}
  library(eddycopipe)
  library(dplyr)
  start = as.Date(start, origin = "1970-01-01")
  end = as.Date(end, origin = "1970-01-01")
  date_range = seq.Date(from = start, to = end, by = "1 day")
  site_list = eddycopipe::get_site_list(type = "TIS")
  for(i in seq_along(date_range)){
    for(j in seq_along(site_list$SiteID)){
      data_in = pull_eddy_data(
        siteid = site_list$SiteID[j],
        start = date_range[i],
        end = date_range[i],
        dp_ver = "DP4",
        data_type = "data",
        type = "basic",
        dp = c("co2Stor", "h2oStor", "isoCo2", "isoH2o", "co2Turb", "h2oTurb", "soni", "amrs",
               "presBaro", "radiNet", "tempAirLvl", "tempAirTop", "co2StorVali", "co2TurbVali",
               "isoCo2Vali", "isoH2oVali"),
        dp_level = "dp01",
        over_write = overwrite
      )
      browser()
      if(is.null(data_in) == FALSE){
        if(nrow(data_in) > 0){
          if(prod == TRUE){
            save_small_eddy_s3(
              data_to_save = data_in,
              write_creds = s3_creds
            )
          } else {
            message(paste0(Sys.time(), ": Not saving, prod is set to FALSE"))
          }
        } else {
          message(paste0(Sys.time(), ": ", site_list$SiteID[j], " - ", date_range[i], " data already exists"))
        }
      } else {
        message(paste0(Sys.time(), ": ", site_list$SiteID[j], " - ", date_range[i], " no data found"))
      }
      rm(data_in)
      gc()
    }
  }
}
