#' @title Converts number to binary
#' @description  Presto Pull for 2 minute data points
#' @param number numeric - number to be converted to binary
#' @param noBits numeric - the number of bits
#' @export
#' @examples
#' number2binary()
number2binary = function(number, noBits) {
  binary_vector = rev(as.numeric(base::intToBits(number)))
  if(missing(noBits)) {
    return(binary_vector)
  } else {
    binary_vector[-(1:(length(binary_vector) - noBits))]
  }
}
