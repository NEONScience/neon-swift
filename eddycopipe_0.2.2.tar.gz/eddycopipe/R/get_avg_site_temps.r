#' @title Function to summarise a site's aat values
#' @description Function was designed to answer hut temperature investigations, and it pulls all available portal data, and saves it S3 located here: hut_temp_investigation/aat_data/
#' @param s3_creds Character string; research-eddy-inquiry write credentials
#' @param site Chracter; four letter site code. ie "STER"
#' @export
#' @examples
#' get_avg_site_temps(site = NULL, s3_creds = NULL)
get_avg_site_temps = function(SiteID = NULL, s3_creds = NULL){

  if(is.null(SiteID) == TRUE){
    stop("Please specify a site")
  }
  if(is.null(s3_creds) == TRUE){
    stop("Please specify a write creds to research-eddy-inquiry s3 bucket")
  }

  # Required Libraries
  library(neonUtilities)
  library(dplyr)
  library(tidyr)
  library(data.table)
  library(lubridate)
  library(ggplot2)

  # First read in, clean, and summarise the triple aat
  data_3_in = neonUtilities::loadByProduct(dpID = "DP1.00003.001",
                               site = SiteID,
                               package = "basic",
                               timeIndex = "30",
                               check.size = "FALSE",
                               token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiJ9.eyJhdWQiOiJodHRwczovL2RhdGEubmVvbnNjaWVuY2Uub3JnL2FwaS92MC8iLCJzdWIiOiJrc3R5ZXJzQGJhdHRlbGxlZWNvbG9neS5vcmciLCJzY29wZSI6InJhdGU6cHVibGljIiwiaXNzIjoiaHR0cHM6Ly9kYXRhLm5lb25zY2llbmNlLm9yZy8iLCJleHAiOjE3NzY2NDE2ODMsImlhdCI6MTYxODk2MTY4MywiZW1haWwiOiJrc3R5ZXJzQGJhdHRlbGxlZWNvbG9neS5vcmcifQ.PQd8Dgo3D9IIU4IAcA47yQhylwtSrhhvMqxYxDr3CdjUD5Z1M8-_rmpRLXrzXU202yevgMhKPfUlMxnI4rcvBw"
  )

  temp_3_data = data_3_in$TAAT_30min %>%
    dplyr::select(-horizontalPosition, -verticalPosition,
                  -tempTripleVariance, -tempTripleNumPts,
                  -tempTripleExpUncert, -tempTripleStdErMean, -release)

  # Remove intermediate data
  rm(data_3_in)

  ### Back to cleaning
  # We want min/max for each month
  temp_3_data_summary = temp_3_data %>%
    dplyr::filter(finalQF == 0) %>%
    dplyr::mutate(month = base::substr(startDateTime, 0, 7)) %>%
    dplyr::mutate(sensor = "tower_top_aat") %>%
    dplyr::group_by(domainID, siteID, month, sensor) %>%
    dplyr::summarise(.groups = "drop",
      mid_min =  round(min(tempTripleMean, na.rm = TRUE), 2),
      mid_mean = round(mean(tempTripleMean, na.rm = TRUE), 2),
      mid_max =  round(max(tempTripleMean, na.rm = TRUE), 2)
    ) %>%
    dplyr::mutate(month = lubridate::ym(month))
  rm(temp_3_data)

  # Fill in gaps with NA
  possible_months = seq.Date(from = min(temp_3_data_summary$month), to = max(temp_3_data_summary$month), by = "1 month")
  for(m in possible_months){
    m = as.Date(m, origin = "1970-01-01")

    if(m %in% temp_3_data_summary$month){
      # do nothing
    } else {
      # Add NA'd month to data.table
      data_add = data.table::data.table("domainID" = temp_3_data_summary$domainID[1], "siteID" = temp_3_data_summary$siteID[1], "month" = m, "sensor" = "tower_top_aat",  "mid_min"  = NA,  "mid_mean" = NA, "mid_max" = NA )

      temp_3_data_summary = data.table::rbindlist(l = list(temp_3_data_summary, data_add))
      rm(data_add)
    }
  }
  rm(possible_months, m)


  # Now read in the ML1 aat data
  data_1_in = neonUtilities::loadByProduct(dpID = "DP1.00002.001",
                                           site = SiteID,
                                           package = "basic",
                                           timeIndex = "30",
                                           check.size = "FALSE",
                                           token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiJ9.eyJhdWQiOiJodHRwczovL2RhdGEubmVvbnNjaWVuY2Uub3JnL2FwaS92MC8iLCJzdWIiOiJrc3R5ZXJzQGJhdHRlbGxlZWNvbG9neS5vcmciLCJzY29wZSI6InJhdGU6cHVibGljIiwiaXNzIjoiaHR0cHM6Ly9kYXRhLm5lb25zY2llbmNlLm9yZy8iLCJleHAiOjE3NzY2NDE2ODMsImlhdCI6MTYxODk2MTY4MywiZW1haWwiOiJrc3R5ZXJzQGJhdHRlbGxlZWNvbG9neS5vcmcifQ.PQd8Dgo3D9IIU4IAcA47yQhylwtSrhhvMqxYxDr3CdjUD5Z1M8-_rmpRLXrzXU202yevgMhKPfUlMxnI4rcvBw"
  )

  temp_1_data_raw = data_1_in$SAAT_30min %>%
    dplyr::select(-horizontalPosition,
                  -tempSingleVariance, -tempSingleNumPts,
                  -tempSingleExpUncert, -tempSingleStdErMean, -release)

  max_ml = max(temp_1_data_raw$verticalPosition)
  temp_1_data = temp_1_data_raw %>%
    dplyr::filter(verticalPosition %in% c("010", "020", max_ml))
  rm(temp_1_data_raw)
  # Create naming lookup
  ml_lookup_table = data.table::data.table("verticalPosition" = c("010","020","030","040","050","060","070"),
                         "sensor" = c("tower_ml1_aat","tower_ml2_aat","tower_ml3_aat","tower_ml4_aat","tower_ml5_aat","tower_ml6_aat","tower_ml7_aat"))

  # Remove intermediate data
  rm(data_1_in)

  ### Back to cleaning
  # We want min/max for each month
  temp_1_data_summary = temp_1_data %>%
    dplyr::filter(finalQF == 0) %>%
    dplyr::mutate(month = base::substr(startDateTime, 0, 7)) %>%
    dplyr::left_join(y = ml_lookup_table, by = "verticalPosition") %>%
    dplyr::group_by(domainID, siteID, month, sensor) %>%
    dplyr::summarise(.groups = "drop",
                     mid_min =  round(min(tempSingleMean, na.rm = TRUE), 2),
                     mid_mean = round(mean(tempSingleMean, na.rm = TRUE), 2),
                     mid_max =  round(max(tempSingleMean, na.rm = TRUE), 2)
    ) %>%
    dplyr::mutate(month = lubridate::ym(month))
  rm(temp_1_data)

  # Fill in gaps with NA
  possible_months = seq.Date(from = min(temp_1_data_summary$month), to = max(temp_1_data_summary$month), by = "1 month")
  for(m in possible_months){
    m = as.Date(m, origin = "1970-01-01")

    if(m %in% temp_1_data_summary$month){
      # do nothing
    } else {
      # Add NA'd month to data.table
      data_add = data.table::data.table("domainID" = temp_1_data_summary$domainID[1], "siteID" = temp_1_data_summary$siteID[1], "month" = m, "sensor" = "tower_ml1_aat",  "mid_min"  = NA,  "mid_mean" = NA, "mid_max" = NA )

      temp_1_data_summary = data.table::rbindlist(l = list(temp_1_data_summary, data_add))
      rm(data_add)
    }
  }
  rm(possible_months, m)

  temp_out = data.table::rbindlist(l = list(temp_1_data_summary, temp_3_data_summary))




  # S3 Connection
  Sys.setenv("AWS_ACCESS_KEY_ID"     = "research-eddy-inquiry",
             "AWS_SECRET_ACCESS_KEY" = s3_creds,
             "AWS_S3_ENDPOINT"       = "neonscience.org",
             "AWS_DEFAULT_REGION"    = "s3.data")

  aws.s3::s3saveRDS(x = temp_out, object = paste0("hut_temp_investigation/aat_data/", SiteID, ".RDS"), bucket = "research-eddy-inquiry")
}
