#' @title Get basic site meta data
#' @description A function to quickly read in a list of sites and domains
#' @param type char - ALL, TIS, or AIS
#' @return Returns a data.table with all the data found or an empty table if no data is found
#' @export
#' @examples
#' get_site_list()
get_site_list = function(type = "ALL"){

  library(dplyr)
  library(aws.s3)

  ei_bucket = "research-eddy-inquiry"
  add_s3_creds(bucket = ei_bucket)

  if(type == "TIS"){

    site_list = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
      dplyr::filter(Type == type)

  } else if(type == "AIS"){

    site_list = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
      dplyr::filter(Type == type)

  } else if(type == "ALL"){

    site_list = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket)

  } else {

    stop(
      "improper type selected"
    )

  }

  return(site_list)

}
