#' @title Wrapper function to pull all ecte cval periods.
#' @description  This function pulls ecte cval period data based upon validation valves status.
#' @param presto_creds Character string; your presto credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' wrap_ecte_cval_periods()
wrap_ecte_cval_periods = function(presto_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify pull_date: Sys.Date()-1")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)

  ei_bucket = "neon-eddy-inquiry"
  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")

  sensor_names = eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket) %>%
    dplyr::filter(stringr::str_detect(string = DPID, pattern = "DP0.00009.001") == TRUE)

  wrap_pull_ecte_cval_periods = function(i, start, stop, sensor_names){

    site_streams = compose_L0_matrix(
      site = i
    )

    valve_list = c("DP0.00009.001") # Li-7200 Enclosure Validation Valve, only opens (1) when analyzer is validating.

    # Limit Streams by EC related streams
    streams = site_streams %>%
      dplyr::filter(stringr::str_detect(string = DPcrispy, pattern = valve_list) == TRUE)

    pull_ecte_cval_periods(
      idDp     = streams,
      dateBgn  = start,
      dateEnd  = stop,
      CredPsto = presto_creds,
      lookup   = sensor_names
    )
  }

  start = Sys.time()
  for(i in siteList$SiteID){
    start1 = Sys.time()
    try(
      wrap_pull_ecte_cval_periods(
        i = i,
        start = pull_date,
        stop = pull_date,
        sensor_names = sensor_names
      )
    )
    end1 = Sys.time()
    message(paste0(Sys.time(), ": ", i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
  }
  end = Sys.time()
  message(paste0(Sys.time(), ": Total ecte cval period pull time ", round(difftime(end,start,units = "min"), 2), " minutes"))
}
