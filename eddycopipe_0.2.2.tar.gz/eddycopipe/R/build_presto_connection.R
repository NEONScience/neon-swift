#' @title Function to build connection to the NEON Presto DB
#' @description  Step 1 in Presto connection testing. Precedes check_connection_to_presto.R. This function builds the connection the the NEON Presto DB
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @export
#' @examples
#' build_presto_connection(CredPsto = "myusername;mypassword")
#'
# Change log
# Kevin Styers (2022-01-30)
#   updated connection to direct to trino port 443
build_presto_connection = function(CredPsto = NULL, destroy = NULL){

  # message(paste0(Sys.time(), ": build connection"))
  if(is.null(CredPsto) == TRUE){
    stop("Specify CredPsto: 'myusername;mypassword'")
  }

  # Required Libaries
  library(RPresto)
  library(DBI)
  library(httr)

  # Variables for Preso Pull
  Srvr = c("https://trino1.gcp.neoninternal.org","https://trino1.gcp.neoninternal.org:443")[2]
  Type = c('numc','str')[1]

  if(is.null(destroy) == FALSE){
    Srvr = c("https://den-trino1.gcp.neoninternal.org:9999","https://trino1.gcp.neoninternal.org:9999")[2]
  }

  # Pull the port from the server name
  srvrSplt <- base::strsplit(Srvr,':')[[1]]
  numSplt <- base::length(srvrSplt)

  port <- utils::tail(srvrSplt,n=1)
  host <- base::paste0(srvrSplt[1:numSplt-1],':',collapse='')
  host <- base::substr(host,start=1,stop=base::nchar(host)-1)

  # Retrieve credientials
  if(base::is.null(CredPsto)){
    CredPsto <- base::unlist(base::strsplit(x=base::Sys.getenv(x='CRED_PSTO'),split=';',fixed=TRUE))
  } else {
    CredPsto <- base::unlist(base::strsplit(x=CredPsto,split=';',fixed=TRUE))
  }

  schm <- 'l0files'
  # Open the database connection & retrieve the data
  httr::set_config(httr::authenticate(CredPsto[1],CredPsto[2]))
  con <- DBI::dbConnect(
    RPresto::Presto(),
    use.trino.headers=TRUE,
    host=host,
    port=port,
    user=CredPsto[1],
    schema=schm,
    catalog='hive',
    source='R_presto',
    session.timezone='GMT'
  )

  return(con)
}
