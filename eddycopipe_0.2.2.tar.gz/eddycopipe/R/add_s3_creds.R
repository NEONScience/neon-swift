#' @title Sets S3 Environmental Credentials
#' @description Sets credentials for: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_S3_ENDPOINT, AWS_DEFAULT_REGION
#' @param bucket character, name of the s3 bucket
#' @param creds character, optional, credentials for writing to bucket
#' @param quite logical, should this function shout what it is doing?
#' @export
#' @examples
#' add_s3_creds()
add_s3_creds = function(bucket = NULL, creds = NULL, quite = TRUE){
  # Check bucket was specified
  if(is.null(bucket) == TRUE){
    stop("Please specify the bucket to set creds to")
  }

  # If no creds are provided, set read creds
  if(is.null(creds) == TRUE){
    if(quite == FALSE){message(paste0(Sys.time(), ": Read to ", bucket))}
    Sys.setenv(
      "AWS_ACCESS_KEY_ID"     = bucket,
      "AWS_S3_ENDPOINT"       = "neonscience.org",
      "AWS_DEFAULT_REGION"    = "s3.data"
    )
    # Else, set write creds
  } else {
    if(quite == FALSE){message(paste0(Sys.time(), ": Write to ", bucket))}
    Sys.setenv(
      "AWS_ACCESS_KEY_ID"     = bucket,
      "AWS_SECRET_ACCESS_KEY" = creds,
      "AWS_S3_ENDPOINT"       = "neonscience.org",
      "AWS_DEFAULT_REGION"    = "s3.data"
    )
  }
}
