#' @title GCS - Establish Connection to GCS
#'
#' @author Kevin Styers
#' @description This function checks for credentials and then establishes connection to GCP
#'
#' @param creds_json optional Path to JSON file
#'
#' @return NA
#'
#' @examples
#' gcs_get_fst(object_name = "mtcars.fst")
#'
#' @export
#'
# changelog and author contributions / copyrights
#   Kevin Styers (2022-02-22)
#     original creation
##############################################################################################
neon_gcs_connect_to_bucket = function(creds_json = NULL){

  if(is.null(creds_json) == TRUE){
    # Check if creds are in standard location
    if(file.exists("/scratch/eddyco_pipeline/no_creds_in_the_repo/service-auth.json")){
      creds_json = "/scratch/eddyco_pipeline/no_creds_in_the_repo/service-auth.json"
    } else {
      stop("Path to creds json was not found in standard location, please specifiy json location manually")
    }
  }

  googleCloudStorageR::gcs_auth(json_file = creds_json)

}
