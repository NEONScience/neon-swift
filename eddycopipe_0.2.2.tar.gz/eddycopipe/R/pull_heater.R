#' @title Wet dep prt data pull
#' @description  Pull all wet dep prt data for all TIS/AIS sites that have them
#' @param idDp string containing full data product ID (e.g. "NEON.DOM.SITE.DP0.00004.001.00474.000.035.000")
#' @param dateBgn date; start of data pull
#' @param dateEnd date; end of data pull
#' @param CredPsto character; vector containing your presto credentials, username;password
#' @param CredS3 character; vector containing your s3 credentials, randomlettersandnumbers
#' @param everyMinute numeric; you want data every 2 min, 2. Every 5 min, 5. etc
#' @param compression specify compression for files saved to S3
#' @export
#' @examples
#' pull_heater()
pull_heater = function(idDp, dateBgn, dateEnd, CredPsto = NULL, CredS3 = NULL, everyMinute = 2, compression = 50) {

  # Libraries
  library(RPresto)
  library(httr)
  library(glue)
  library(DBI)
  library(dplyr)
  library(fst)
  library(aws.s3)
  library(aws.signature)
  library(tidyr)
  library(here)


  # Check that Date Range is only 1 day, if != 1, do not run!
  if(as.Date(dateEnd) - as.Date(dateBgn) < 507){

    # Determine the site
    site = unique(substr(idDp,10,13))

    # Build and test connection
    con = wrap_build_test_presto_connection(CredPsto = CredPsto)

    # Stream formatting:
    idDpChar = sapply(idDp, function(x) paste0("",x,"")) %>% paste0(collapse=",") %>% as.factor() %>% paste0(collapse=",")

    sql = glue::glue_sql("SELECT
                            meas_strm_name, readout_time, readout_val_double
                           FROM
                            readouts
                           WHERE
                            site = {site} and
                            meas_strm_name IN ({idDpChar}) and
                            ds between {dateBgn} and {dateEnd} and
                            MINUTE(readout_time) % {everyMinute} = 0 and SECOND(readout_time) = 0
                           ",
                          .con = con
    ) %>%
      # The stuff below is some magic to format the string of streams juuust right
      gsub(pattern = "NEON",replacement = "'NEON") %>%
      gsub(pattern = "0,", replacement = "0',") %>%
      gsub(pattern = "1,", replacement = "1',") %>%
      gsub(pattern = "2,", replacement = "2',") %>%
      gsub(pattern = "3,", replacement = "3',") %>%
      gsub(pattern = "''", replacement = "'") %>%
      gsub(pattern = '""', replacement = '"') %>%
      gsub(pattern = '"approx', replacement = "approx") %>%
      gsub(pattern = '0.95),"', replacement = "0.95),")

    start = Sys.time()

    # Send the Query
    res = DBI::dbSendQuery(con, sql)
    message(paste0(Sys.time(), ": 14%:  ",site, " from ", dateBgn, " to ", dateEnd))
    # Actually grab the data from the query
    mrg.rpt= DBI::dbFetch(res,-1)

    base::message(paste0(Sys.time(), ": 21%:  Pull finished..."))
    # Disconnect from the DB like a good neighbor
    DBI::dbDisconnect(con)
    base::message(paste0(Sys.time(), ": 28%:  Disconnected from Presto..."))

    # Time calculations
    end = Sys.time()
    elapsed = difftime(end, start, units = "secs")
    message(paste0(Sys.time(), ": 37%:  Pull lasted: ",round(elapsed,3)," seconds..."))

    # If there is data in the pull tidy the data a little, and then save it appropriately
    if(nrow(mrg.rpt) > 0){

      # Load in the Sensor Names to DPID lookup table
      sensorNameStreams =  aws.s3::s3readRDS(object = "lookup/SensorNames.RDS", bucket = "research-eddy-inquiry") %>%
        dplyr::mutate(DPID = base::trimws(DPID, which = "both"))

      # Clean up table
      mrg.rpt = data.table::as.data.table(mrg.rpt) %>%
        dplyr::mutate(DPID = base::substr(meas_strm_name, start = 15, stop = 100)) %>% # Create a mutual column to join the Sensor Names lookup table to
        dplyr::mutate(DPID = base::trimws(DPID, which = "both")) %>%
        dplyr::mutate(SiteID = site)

      # Join the lookup table and raw 2 minute data, giving all the streams human readible names
      mrg.rpt.out = dplyr::left_join(x = mrg.rpt, y = sensorNameStreams, by = "DPID")
      rm(mrg.rpt)

      # Formating the df
      mrg.rpt.distinct = mrg.rpt.out  %>%
        dplyr::mutate(readout_time = lubridate::ymd_hms(readout_time)) %>%
        dplyr::distinct(readout_time,strm_name, .keep_all = TRUE) %>%
        dplyr::select(SiteID,DPID,strm_name,readout_time,readout_val_double)
      rm(mrg.rpt.out)

      ### Wet Dep streams
      if(nrow(mrg.rpt.distinct) > 0){

        heater_out = mrg.rpt.distinct %>%
          dplyr::select(SiteID, strm_name, readout_time, readout_val_double) %>%
          dplyr::arrange(readout_time)

        ei_save_S3(prefix = "heater", file_extension = "_heater.fst", dataTable = heater_out, site = site, dateBgn = dateBgn, percentage = "44.44", compression = compression)
      } else {
        message(paste0(Sys.time(), ": No data in pull..."))
        site_meta_data = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = "research-eddy-inquiry") %>%
          dplyr::filter(SiteID == site)

      if(site_meta_data$Type[1] == "TIS"){

        soil_na_data = data.table::data.table(
          "SiteID" = site,
          "strm_name" = "NR01_Soil_Heater",
          "readout_time" = seq.POSIXt(from = as.POSIXct(paste0(dateBgn, " 00:00:00")), to = as.POSIXct(paste0(dateEnd, " 00:00:00")), by = "2 min"),
          "readout_val_double" = NA
        )
        tower_na_data = data.table::data.table(
          "SiteID" = site,
          "strm_name" = "NR01_Tower_Heater",
          "readout_time" = seq.POSIXt(from = as.POSIXct(paste0(dateBgn, " 00:00:00")), to = as.POSIXct(paste0(dateEnd, " 00:00:00")), by = "2 min"),
          "readout_val_double" = NA
        )

        heater_data_out = data.table::rbindlist(l = list(soil_na_data, tower_na_data)) %>%
          dplyr::arrange(readout_time)

      } else if(site_meta_data$Type[1] == "AIS"){
        heater_data_out = data.table::data.table(
          "SiteID" = site,
          "strm_name" = "NR01_Soil_Heater",
          "readout_time" = seq.POSIXt(from = as.POSIXct(paste0(dateBgn, " 00:00:00")), to = as.POSIXct(paste0(dateEnd, " 00:00:00")), by = "2 min"),
          "readout_val_double" = NA
        )

      } else {
        stop("Site type not AIS/TIS")
      }

      ei_save_S3(prefix = "heater", file_extension = "_heater.fst", dataTable = data.table::data.table(), site = site, dateBgn = dateBgn, percentage = "44.44", compression = compression)

      }
    } else {

      message(paste0(Sys.time(), ": No data in pull..."))
      site_meta_data = aws.s3::s3readRDS(object = "lookup/swft.full.site.lookup.RDS", bucket = "research-eddy-inquiry") %>%
        dplyr::filter(SiteID == site)

      if(site_meta_data$Type[1] == "TIS"){

        soil_na_data = data.table::data.table(
          "SiteID" = site,
          "strm_name" = "NR01_Soil_Heater",
          "readout_time" = seq.POSIXt(from = as.POSIXct(paste0(dateBgn, " 00:00:00")), to = as.POSIXct(paste0(dateEnd, " 00:00:00")), by = "2 min"),
          "readout_val_double" = NA
        )
        tower_na_data = data.table::data.table(
          "SiteID" = site,
          "strm_name" = "NR01_Tower_Heater",
          "readout_time" = seq.POSIXt(from = as.POSIXct(paste0(dateBgn, " 00:00:00")), to = as.POSIXct(paste0(dateEnd, " 00:00:00")), by = "2 min"),
          "readout_val_double" = NA
        )

        heater_data_out = data.table::rbindlist(l = list(soil_na_data, tower_na_data)) %>%
          dplyr::arrange(readout_time)

      } else if(site_meta_data$Type[1] == "AIS"){
        heater_data_out = data.table::data.table(
          "SiteID" = site,
          "strm_name" = "NR01_Soil_Heater",
          "readout_time" = seq.POSIXt(from = as.POSIXct(paste0(dateBgn, " 00:00:00")), to = as.POSIXct(paste0(dateEnd, " 00:00:00")), by = "2 min"),
          "readout_val_double" = NA
        )

      } else {
        stop("Site type not AIS/TIS")
      }
      ei_save_S3(prefix = "heater", file_extension = "_heater.fst", dataTable = heater_data_out, site = site, dateBgn = dateBgn, percentage = "44.44", compression = compression)
    }
  } else {
    message(paste0(Sys.time(), ": The Date Range is greater than 11!!! Date Range:", as.Date(dateEnd) - as.Date(dateBgn)))
  }
}
