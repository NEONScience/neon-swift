#' @title Wrapper to pull all 1hz 2min eddyInquiry Data
#' @description  This function pairs with pull_2min_1hz.R to pull data from Presto and save it to S3, not the most beautiful :/
#' @param presto_creds Character string; your preso credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' wrap_2min_1hz(presto_creds = NULL, s3_creds = NULL, pull_date = NULL)
wrap_2min_1hz = function(presto_creds = NULL, pull_date = NULL, sites = "ALL"){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify pull_date: '2022-02-25'")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)
  library(here)

  ei_bucket = "neon-eddy-inquiry"

  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")

  pull_min_ec_data <- function(i, start, stop){

    # eddycopipe function
    site_streams = compose_L0_matrix(
      site = i
    )

    # Sensor Names, This list is used to limit streams to only DPID's I have named in this SensorNames Lookup table
    sensor_names = eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket) %>%
      dplyr::mutate(DPID = base::trimws(DPID, which = "both"))

    # Filter Data to just essential EC Streams
    ecList = c(
     "DP0.00105.001.02316", # Li840_CO2_fwMole
     "DP0.00105.001.02348", # Li840_H2O_fwMole
     "DP0.00106.001.01951", # Li840 MFC Flow Rate
     "DP0.00107.001.01951", # Li-840 Vali MFC
     "DP0.00105.001.02349", # Li-840 CellTemperature
     "DP0.00105.001.02350", # Li-840 Cell Pressure
     "DP0.00102.001.02316", # G2131_CO2
     "DP0.00102.001.02191", # G2131_H2O
     "DP0.00102.001.02324", # G2131_13C_fwMole
     "DP0.00102.001.02325", # G2131_percentFwMoleH2O
     "DP0.00102.001.02308", # G2131_tempCavi
     "DP0.00102.001.02313", # G2131_valvOutl
     "DP0.00016.001.02191", # Li7200_CO2
     "DP0.00016.001.02186", # Li7200_H2o
     "DP0.00012.001.01951", # Li7200 frt
     "DP0.00016.001.02194", # Li7200 CO2_Signal
     "DP0.00016.001.02195", # Li7200 H2O_Signal
     "DP0.00016.001.01931", # Li7200_diag
     "DP0.00016.001.02181", # Li7200_pdiff
     "DP0.00016.001.02178", # Li7200_cellTempIn
     "DP0.00016.001.02179", # Li7200_cellTempOut
     "DP0.00012.001.01951", # Li7200_MFCSampleTemp
     "DP0.00012.001.01948", # Li7200_MFCSamplePressure
     "DP0.00015.001.01949", # Li7200_MFCValiTemp
     "DP0.00116.001.02351", # Li7200_Pump
     "DP0.00103.001.02369", # L2130_18O
     "DP0.00103.001.02370", # L2130_2H
     "DP0.00103.001.02339", # L2130_H2O_fwMole
     "DP0.00103.001.02308", # L2130_tempCavi
     "DP0.00103.001.02313", # L2130_valvOutl
     "DP0.00108.001.01951", # ML`n`_MFM_FlowRate
     "DP0.00108.001.01948", # ML`n`_MFM_Pressure
     "DP0.00109.001.02196", # ML`n`_Inlet_Pressure
     "DP0.00113.001.02360", # VALVES 1 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00113.001.02361", # VALVES 2 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00113.001.02362", # VALVES 3 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00113.001.02364", # VALVES 4 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00113.001.02365", # VALVES 5 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00113.001.02366", # VALVES 6 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00113.001.02367", # VALVES 7 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00113.001.02368", # VALVES 8 Could be Li840/G2131/L2130/validation 1/0
     "DP0.00007.001.01927", # CSAT X
     "DP0.00007.001.01928", # CSAT Y
     "DP0.00007.001.01929", # CSAT Z
     "DP0.00007.001.02225", # CSAT Diagnostic
     "DP0.00007.001.03048", # CSAT Speed of Sound
     "DP0.00098.001.01309", # HMP155 Temp
     "DP0.00098.001.01357", # HMP155 RH
     "DP0.00098.001.01358", # HMP155 DewPoint
     "DP0.00106.001.01949", # ECSE Sample Temp
     "DP0.00106.001.01948", # ECSE Sample Pressure
     "DP0.00107.001.01949", # ECSE Valida Temp
     "DP0.00012.001.01949", # ECTE Sample Temp
     "DP0.00015.001.01949", # ECSE Valida Temp
     "DP0.00104.001.02344", # ECSE Hut Temp
     "DP0.00104.001.02347", # ECSE MixRatio
     "DP0.00010.001.02209", # AMRS_y
     "DP0.00010.001.02210", # AMRS_x
     "DP0.00010.001.02211", # AMRS_z
     "DP0.00010.001.02226"  # AMRS_diag
    )

    # Limit Streams by EC related streams
    streams <- site_streams %>%
      dplyr::filter(DPcrispy %in% ecList) %>%
      dplyr::distinct()

    streams <- base::as.vector(streams$streams)

    # eddycopipe function
    pull_2min_1hz(
      idDp         = streams,
      dateBgn      = start,
      dateEnd      = stop,
      CredPsto     = presto_creds,
      sensor_names = sensor_names,
      everyMinute  = 2,
      compression  = 100
    )
  }

  time_data <- base::system.time(
    for(i in siteList$SiteID){
      start1 <- Sys.time()
      base::try(
        pull_min_ec_data(
          i     = i,
          start = pull_date,
          stop  = pull_date + 1
        )
      )
      message(paste0(Sys.time(), ": 100%: Completed Pull"))
      end1 <- Sys.time()
      message(paste0(Sys.time(), ": ", i , " ", round(difftime(end1,start1,units = "secs"), 2)," seconds..."))
    }
  )
  message(paste0(Sys.time(), ": Completed 2min 1hz pull in: ", round(time_data[3]/60,1), " minutes"))
}
