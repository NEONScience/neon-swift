#' @title Wrapper to pull a day's span gas values
#' @description  This function pulls mean daily span gas pressures and delivery pressures
#' @param presto_creds Character string; your preso credentials 'username;password'
#' @param pull_date Date; date to pull data
#' @export
#' @examples
#' wrap_span_gases(presto_creds = NULL,pull_date = NULL)
wrap_span_gases = function(presto_creds = NULL, sites = "ALL", pull_date = NULL){

  if(is.null(presto_creds) == TRUE){
    stop("Please specify presto_creds: 'username;password'")
  }
  if(is.null(pull_date) == TRUE){
    stop("Please specify s3_creds: 'username;password'")
  }

  # Required Libraries
  library(reshape2)
  library(lubridate)
  library(ytBangerz)
  library(stringr)
  library(data.table)
  library(stringr)
  library(rlang)
  library(dplyr)
  library(fst)

  ei_bucket = "neon-eddy-inquiry"

  siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
    dplyr::filter(Type == "TIS")

  # Read in Hongyan's streams
  hongStreams = eddycopipe::neon_gcs_get_csv(object = "lookup/hongaynStreams.csv", bucket = ei_bucket)
  hongStreams$DPraw <- base::substr(hongStreams$`DP ID`,15,37) ## Create DPraw, containing just DP ID, no site info etc...
  hongStreams$DPcrispy <- base::substr(hongStreams$DPraw,1,13)

  pull_gas_ec_data <- function(i, start, stop, hongStreams){

    site_streams = compose_L0_matrix(
      site = i
    )

    # Sensor Names, This list is used to limit streams to only DPID's I have named in this SensorNames Lookup table
    sensor_names <-  eddycopipe::neon_gcs_get_rds(object = "lookup/SensorNames.RDS", bucket = ei_bucket) %>%
      dplyr::mutate(DPcrispy = base::substr(DPID,1,13))

    # optional
    smallList <- c("DP0.00110.001.02196.709",
                   "DP0.00110.001.02196.710",
                   "DP0.00110.001.02196.711",
                   "DP0.00110.001.02196.712",
                   "DP0.00110.001.02196.713",
                   "DP0.00110.001.02196.714",
                   "DP0.00111.001.02196.709",
                   "DP0.00111.001.02196.710",
                   "DP0.00111.001.02196.711",
                   "DP0.00111.001.02196.712",
                   "DP0.00111.001.02196.713",
                   "DP0.00111.001.02196.714",
                   "DP0.00035.001.02196.702",
                   "DP0.00035.001.02196.703",
                   "DP0.00035.001.02196.704",
                   "DP0.00035.001.02196.705",
                   "DP0.00035.001.02196.706",
                   "DP0.00034.001.02196.702",
                   "DP0.00034.001.02196.703",
                   "DP0.00034.001.02196.704",
                   "DP0.00034.001.02196.705",
                   "DP0.00034.001.02196.706"
    )

    # Limit Streams by EC related streams
    streams <- site_streams %>%
      dplyr::mutate(DPraw = substr(streams,15,37)) %>% ## Create DPraw, containing just DP ID, no site info etc...
      dplyr::mutate(DPcrispy = substr(DPraw,1,13)) %>%
      dplyr::filter(DPcrispy %in% hongStreams$DPcrispy | DPcrispy %in% sensor_names$DPcrispy)  %>%
      dplyr::filter(DPraw %in% smallList)

    streams <- base::as.vector(streams$streams)

    try(
      pull_span_gases(
        idDp = streams,
        dateBgn = start,
        dateEnd = stop,
        CredPsto = presto_creds,
        lookup = sensor_names
      )
    )
  }
  for(i in siteList$SiteID){
    pull_gas_ec_data(i = i, start = pull_date, stop = pull_date + 1, hongStreams = hongStreams)
  }

}
