eddycopipe::neon_gcs_connect_to_bucket()
eddycopipe::get_latest_fulcrum_data()

siteList = eddycopipe::neon_gcs_get_rds(object = "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
  dplyr::filter(Type == "TIS")

test_2min_Li7200_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "Li7200", silent = FALSE)
test_2min_amrs_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "amrs", silent = FALSE)
test_2min_HMP155_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "HMP155", silent = FALSE)
test_2min_CSAT3_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "CSAT3", silent = FALSE)
test_2min_G2131_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "G2131", silent = FALSE)
test_2min_Li840_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "UNDE", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "Li840", silent = FALSE)
test_2min_ecse.mfm_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "ecse.mfm", silent = FALSE)
test_2min_ecse.mfm.pressures_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "ecse.mfm.pressures", silent = FALSE)
test_2min_ecse.sample.mfc_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "ecse.sample.mfc", silent = FALSE)
test_2min_ec.temps_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "ec.temps", silent = FALSE)
test_2min_ecse.voltage_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "ecse.voltage", silent = FALSE)
test_2min_Li840.valves_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "Li840.valves", silent = FALSE)
test_2min_L2130_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "UNDE", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "L2130", silent = FALSE)
test_2min_Li7200.valves_read = eddycopipe::neon_read_eddy_inquiry(dataType = "2min", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "Li7200.valves", silent = FALSE)




test_cval_li7200_read = eddycopipe::neon_read_eddy_inquiry(dataType = "cval", siteID = "UNDE", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "Li7200", silent = FALSE)
test_cval_g2131_read = eddycopipe::neon_read_eddy_inquiry(dataType = "cval", siteID = "UNDE", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "G2131i", silent = FALSE)
test_cval_li840_read = eddycopipe::neon_read_eddy_inquiry(dataType = "cval", siteID = "UNDE", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "Li840A", silent = FALSE)
test_cval_l2130_read = eddycopipe::neon_read_eddy_inquiry(dataType = "cval", siteID = "UNDE", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "L2130i", silent = FALSE)

test_CnC_read = eddycopipe::neon_read_eddy_inquiry(dataType = "CnC", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), silent = FALSE)
test_cval.stats_read = eddycopipe::neon_read_eddy_inquiry(dataType = "cval.stats", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), sensor = "Li7200", silent = FALSE)
test_spanGas_read = eddycopipe::neon_read_eddy_inquiry(dataType = "spanGas", siteID = "BART", startDate = Sys.Date()-14, endDate = Sys.Date(), silent = FALSE)
test_wet_dep_read = eddycopipe::neon_read_eddy_inquiry(dataType = "wet_dep", siteID = "CPER", startDate = Sys.Date()-14, endDate = Sys.Date(), silent = FALSE)

