test_data = read_sae_s3(
  siteid = "UNDE",
  term = c("co2Stor_30m"),
  start = Sys.Date()-120,
  end = Sys.Date()
)

length(unique(test_data$date))

library(ggplot2)

ggplot(test_data %>% dplyr::filter(Stream == "rtioMoleDryCo2"), aes(x = timeBgn, y = mean, color = Measurement_Level))+
  geom_point(shape = 1, alpha = .5) +
  ggdark::dark_theme_bw()


data = read_sae_s3(
  siteid = "UNDE",
  start = "2021-07-15",
  end = "2021-07-18",
  term =  c("co2Stor_30m", "isoCo2_30m")
)


library(ggplot2)

data_times_4 = data %>%
  dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
  dplyr::filter(stringr::str_detect(string = timeBgn, pattern = "04:30:00") | stringr::str_detect(string = timeBgn, pattern = "04:00:00") | stringr::str_detect(string = timeBgn, pattern = "03:30:00")) %>%
  dplyr::mutate(time_int = "04:00") %>%
  dplyr::filter(Stream == "rtioMoleDryCo2") %>%
  dplyr::group_by(SiteID, date, Measurement_Level, time_int, Data_Product) %>%
  dplyr::summarise(
    mean = mean(mean, na.rm = TRUE)
  )
data_times_12 = data %>%
  dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
  dplyr::filter(stringr::str_detect(stringr::str_detect(string = timeBgn, pattern = "12:30:00") | string = timeBgn, pattern = "12:00:00")| stringr::str_detect(string = timeBgn, pattern = "11:30:00")) %>%
  dplyr::mutate(time_int = "12:00") %>%
  dplyr::filter(Stream == "rtioMoleDryCo2")%>%
  dplyr::group_by(SiteID, date, Measurement_Level, time_int, Data_Product) %>%
  dplyr::summarise(
    mean = mean(mean, na.rm = TRUE)
  )
data_times_20 = data %>%
  dplyr::mutate(date = as.Date(timeBgn, origin = "1970-01-01")) %>%
  dplyr::filter(stringr::str_detect(string = timeBgn, pattern = "20:30:00")| stringr::str_detect(string = timeBgn, pattern = "20:00:00")| stringr::str_detect(string = timeBgn, pattern = "19:30:00")) %>%
  dplyr::mutate(time_int = "20:00") %>%
  dplyr::filter(Stream == "rtioMoleDryCo2")%>%
  dplyr::group_by(SiteID, date, Measurement_Level, time_int, Data_Product) %>%
  dplyr::summarise(
    mean = mean(mean, na.rm = TRUE)
  )

date_times = data.table::rbindlist(l = list(data_times_4, data_times_12, data_times_20))

ggplot(date_times, aes(x = Measurement_Level, y = mean, color = time_int, group = time_int)) +
  geom_point(size = 3) +
  geom_line() +
  ggplot2::coord_flip() +
  labs(
    title = base::paste0(date_times$SiteID[1], ": CO2 Profile"),
    y = "CO2 (ppm)",
    x = "Measurement Level",
    color = "Hour") +
  ggdark::dark_theme_bw() +
  facet_grid(Data_Product~date)




## PULL DATA
library(eddycopipe)
library(dplyr)

date_range = seq.Date(
  from = Sys.Date()-46, to = Sys.Date()-1, by = "1 day"
)

site_list = eddycopipe::get_site_list(type = "TIS")

for(i in seq_along(date_range)){

  for(j in seq_along(site_list$SiteID)){

    data_in = pull_eddy_data(
      siteid = site_list$SiteID[j],
      start = date_range[i],
      end = date_range[i],
      dp_ver = "DP4",
      data_type = "data",
      type = "basic",
      dp = c("co2Stor", "h2oStor", "isoCo2", "isoH2o", "co2Turb", "h2oTurb", "soni", "amrs",
             "presBaro", "radiNet", "tempAirLvl", "tempAirTop", "co2StorVali", "co2TurbVali",
             "isoCo2Vali", "isoH2oVali"),
      dp_level = "dp01",
      over_write = FALSE
    )

    if(is.null(data_in) == FALSE){

      if(nrow(data_in) > 0){

        save_small_eddy_s3(
          data_to_save = data_in,
          write_creds = base::readRDS("~/GitHub/eddyInquiry/secret.key.RDS")
        )

      } else {

        message(paste0(Sys.time(), ": ", site_list$SiteID[j], " - ", date_range[i], " data already exists"))

      }

    } else {

      message(paste0(Sys.time(), ": ", site_list$SiteID[j], " - ", date_range[i], " no data found"))

    }

    rm(data_in)
    gc()

  }

}

