# "Unit test" of the eddyco_pipeline
# Samples 5 random sites (~10% of sites) for each part of the pipeline

message(paste0(Sys.time(), ": Starting main_R"))

# library(eddycopipe)
library(dplyr)
library(aws.s3)
library(aws.signature)

base_dir = "~/eddyInquiry/"

ei_bucket = "research-eddy-inquiry"
Sys.setenv(
  "AWS_ACCESS_KEY_ID"     = "research-eddy-inquiry",
   "AWS_S3_ENDPOINT"       = "neonscience.org",
   "AWS_DEFAULT_REGION"    = "s3.data"
)

site_list = aws.s3::s3readRDS(object= "lookup/swft.full.site.lookup.RDS", bucket = ei_bucket) %>%
  dplyr::filter(Type == "TIS")

main = function(pull_sites = "ALL", pull_dates = Sys.Date()-1){

  for(pull_date in pull_dates){

    pull_date = as.Date(pull_date, origin = "1970-01-01")
    message(pull_date)

    # Pull wet dep data from Presto
    # eddycopipe::wrap_wet_dep_pull(
    #   presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
    #   s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
    #   pull_date    = pull_date,
    #   sites = sample(site_list$SiteID, size = 5)
    #
    # )
    # Pull Span Gase pressures from Presto
    eddycopipe::wrap_span_gases(
      presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
      s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
      pull_date    = pull_date,
      sites = "MD01"
      # sites = sample(site_list$SiteID, size = 5)
    )

    # Pull EC Streams both 1hz and 5hz
    eddycopipe::wrap_2min_1hz(
      presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
      s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
      pull_date    = pull_date,
      sites = "MD01"
      # sites = sample(site_list$SiteID, size = 5)
    )
    eddycopipe::wrap_2min_5hz(
      presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
      s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
      pull_date    = pull_date,
      sites = "MD01"
      # sites = sample(site_list$SiteID, size = 5)
    )

    # Pull all ecse/ecte cval periods
    eddycopipe::wrap_ecse_cval_periods(
      presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
      s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
      pull_date    = pull_date,
      sites = "MD01"
      # sites = sample(site_list$SiteID, size = 5)
    )
    # eddycopipe::wrap_ecte_cval_periods(
    #   presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
    #   s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
    #   pull_date    = pull_date,
    #   sites = sample(site_list$SiteID, size = 5)
    # )

    # Pull all ecse/ecte cvals based upon ecse/ecte cval period data
    eddycopipe::wrap_ecse_cvals(
      presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
      s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
      pull_date    = pull_date,
      sites = "MD01"
      # sites = sample(site_list$SiteID, size = 5)
    )
    # eddycopipe::wrap_ecte_cvals(
    #   presto_creds = readRDS(paste0(base_dir, "presto_creds.RDS")),
    #   s3_creds     = readRDS(paste0(base_dir, "secret.key.RDS")),
    #   pull_date    = pull_date,
    #   sites = sample(site_list$SiteID, size = 5)
    # )
  }

  # # Build Master Span Gas files
  # eddycopipe::summarise_span_gas(
  #   s3_creds = readRDS(paste0(base_dir, "secret.key.RDS")),
  #   recreate_master = FALSE
  # )
  # eddycopipe::clean_span_gas_data(
  #  s3_creds = readRDS(paste0(base_dir, "secret.key.RDS"))
  # )
  #
  # # Pull LC Services data
  # eddycopipe::pull_lc_services(
  #   s3_creds = readRDS(paste0(base_dir, "secret.key.RDS"))
  # )
  #
  # # Get the latest Fulcrum data
  # eddycopipe::get_latest_fulcrum_data(
  #   s3_creds = readRDS(paste0(base_dir, "secret.key.RDS"))
  # )

}

# Run main
main(pull_sites = NULL, pull_dates = seq.Date(from = Sys.Date()-14, Sys.Date()-13, by = "1 day"))

# Push new source package to aws.s3
#aws.s3::put_object(file = paste0(base_dir, "pkg/eddycopipe_0.1.4.tar.gz"), object = "eddycopipe/eddycopipe_0.1.4.tar.gz", bucket = ei_bucket)
#aws.s3::put_folder(folder = "eddycopipe/", bucket = ei_bucket)
